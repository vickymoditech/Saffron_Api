import React from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {Provider} from 'react-redux';
import {createStore, applyMiddleware} from 'redux';
import {Router, Route, browserHistory, IndexRoute} from 'react-router';
import {composeWithDevTools} from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import decode from 'jwt-decode';

import rootReducer from './reducers';
import App from './components/app';
import initialState from '../src/reducers/initialState';
import Home from '../src/components/Home';
import Login from '../src/components/Login';
import StoreConfiguration from '../src/components/StoreConfiguration';
import StoreUserConfiguration from '../src/components/StoreUserConfiguration';
import ForgotPassword from '../src/components/ForgotPassword';
import ResetPassword from '../src/components/ResetPassword';
import NotFound from '../src/components/NotFound';
import {GyGLog} from '../src/Logging/GyGLog';
import Analytics from './components/Analytics';
import ChatApp from './components/ChatApp';

const composeEnhancers = composeWithDevTools({});
const store = createStore(rootReducer, initialState, composeEnhancers(applyMiddleware(thunk)));

function requireAuth(nextState, replace) {
    if (!isLoggedIn()) {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("userProfile");
        replace({
            pathname: '/login',
            state: {nextPathname: nextState.location.pathname}
        })
    }

    // const accessToken = localStorage.getItem('accessToken');
    // const userProfile = JSON.parse(localStorage.getItem('userProfile'));
    // const userRole = userProfile && userProfile.role;
    // if (!accessToken) {
    //     localStorage.removeItem("accessToken");
    //     localStorage.removeItem("userProfile");
    //     replace({
    //         pathname: '/login',
    //         state: {nextPathname: nextState.location.pathname}
    //     })
    // }
    // else if(accessToken && userRole==="admin"){
    //     replace({
    //         pathname: '/store-config',
    //         state: {nextPathname: nextState.location.pathname}
    //     })
    // }
}

window.onerror = (message, file, line, column) => {
    const errMessage = "Error Message:" + message + "  " + "File Name:" + file + "  " + "Line Number :" + line + "  " + "Column :" + column + "  ";
    GyGLog('debug', 'DDS Log global error' + errMessage);
    // localStorage.removeItem("accessToken");
    // localStorage.removeItem("userProfile");
};

export function getAccessToken() {
    return localStorage.getItem("accessToken");
}

export function clearAccessToken() {
    localStorage.removeItem("accessToken");
}

export function isLoggedIn() {
    const accessToken = getAccessToken();
    return !!accessToken && !isTokenExpired(accessToken);
}

function checkLoggedIn(nextState, replace) {
    const accessToken = getAccessToken();
    if (accessToken) {
        try {
            const decodedToken = decode(accessToken);
            if (decodedToken) {
                replace({
                    pathname: '',
                    state: {nextPathname: nextState.location.pathname}
                });
            }
        } catch (error) {
        }
    }
}

function getTokenExpirationDate(encodedToken) {
    try {
        const token = decode(encodedToken);
        if (!token.exp) {
            return null;
        }
        const date = new Date(0);
        date.setUTCSeconds(token.exp);
        return date;
    } catch (error) {
        return null
    }
}

function getUserProfile(token) {
    return decode(token);
}

function isTokenExpired(token) {
    const expirationDate = getTokenExpirationDate(token);
    if (expirationDate < new Date()) {
        clearAccessToken();
    }
    return expirationDate < new Date();
}

function checkAdmin(nextState, replace) {
    const accessToken = localStorage.getItem('accessToken');
    const userProfile = accessToken && getUserProfile(accessToken);
    const userRole = userProfile && userProfile.roleOrder;
    if (isLoggedIn() && userRole !== 1) {
        replace({
            pathname: '',
            state: {nextPathname: nextState.location.pathname}
        })
    } else if (!isLoggedIn()) {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("userProfile");
        replace({
            pathname: '/login',
            state: {nextPathname: nextState.location.pathname}
        })
    }
}

function checkStoreAdmin(nextState, replace) {
    const accessToken = localStorage.getItem('accessToken');
    const userProfile = accessToken && getUserProfile(accessToken);
    const userRole = userProfile && userProfile.roleOrder;
    if (isLoggedIn() && (userRole !== 1 && userRole !== 2)) {
        replace({
            pathname: '',
            state: {nextPathname: nextState.location.pathname}
        })
    } else if (!isLoggedIn()) {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("userProfile");
        replace({
            pathname: '/login',
            state: {nextPathname: nextState.location.pathname}
        })
    }
}

function isLoggedInCheck(nextState, replace) {
    if (!isLoggedIn()) {
        replace({
            pathname: '/login',
            state: {nextPathname: nextState.location.pathname}
        })
    }
}

ReactDOM.render(<Provider store={store}>
    <MuiThemeProvider>
        <Router history={browserHistory}>
            <Route component={App} path="/" onEnter={requireAuth}>
                <IndexRoute component={Home} onEnter={requireAuth}/>
                <Route path="/home(/:store)" component={Home} onEnter={requireAuth}/>
            </Route>
            <Route path="/store-config" component={StoreConfiguration} onEnter={checkAdmin}/>
            <Route path="/analytics" component={Analytics} onEnter={checkStoreAdmin}/>
            <Route path="/store-user-config" component={StoreUserConfiguration} onEnter={checkStoreAdmin}/>
            <Route path="/login" component={Login} onEnter={checkLoggedIn}/>
            <Route path="/forgot-password" component={ForgotPassword}/>
            <Route path="/reset-password" component={ResetPassword}/>
            <Route path="/chat-app" component={ChatApp} onEnter={isLoggedInCheck}/>
            <Route path="*" component={NotFound} exact={true}/>
        </Router>
    </MuiThemeProvider>
</Provider>, document.getElementById('root'));
