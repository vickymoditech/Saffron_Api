import axios from 'axios';

import ENVIRONMENT_VARIABLES from '../environment.config'
export const GyGLog = (logLevel,message) => {
    try{
        const token = 'Bearer ' + localStorage.getItem('accessToken');
        const api = {
            method: 'post',
            url: ENVIRONMENT_VARIABLES.API_URL + "/dds/writeLog",
            data:{
                logLevel:logLevel,
                message:message
            },
            headers: {'Authorization': token}
        };
        // axios(api).then(function(response){
        // }).catch(function (error) {
        // });
    }catch(error){
        console.log(error);
    }
};