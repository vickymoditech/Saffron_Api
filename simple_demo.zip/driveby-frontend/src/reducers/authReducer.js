import {browserHistory} from 'react-router';
import _ from 'lodash';

import {
    IS_AUTHENTICATED,
    INVALID_USER,
    UNAUTHORIZED_USER,
    AUTHENTICATION_INPROGRESS,
    PASSWORD_CHANGE_SUCCESS,
    PASSWORD_CHANGE_INPROGRESS,
    PASSWORD_CHANGE_NOT_SUCCESS,
    STORE_USER_AVATAR_UPLOAD_SUCCESS,
    FORGOT_PASSWORD_START,
    FORGOT_PASSWORD_SUCCESS,
    FORGOT_PASSWORD_ERROR,
    FORGOT_PASSWORD_COMPLETE,
    ERROR_UPLOAD_USER_AVATAR,
    CHECK_FORGOT_PASSWORD_SUCCESS,
    CHECK_FORGOT_PASSWORD_ERROR,
    RESET_PASSWORD_SUCCESS
} from '../constants/actionTypes'
import initialState from './initialState';

export default function authReducer(state = initialState.authReducer, action) {
    switch (action.type) {
        case IS_AUTHENTICATED:
            localStorage.setItem("accessToken", action.data.accessToken);
            localStorage.setItem("userProfile", JSON.stringify(action.data.userProfile));
            localStorage.setItem("userAvatar",action.data.userProfile.userAvatar);
            let isAuthenticated = _.cloneDeep({
                isAuthenticated: true,
                loading: false,
                userProfile: action.data.userProfile,
                userAvatar:action.data.userProfile.userAvatar
            });
            const userRole = action.data.userProfile.role;
            return Object.assign({}, state, isAuthenticated);
        case INVALID_USER:
            return Object.assign({}, state, {invalidUser: true, loading: false, error_msg: action.data.error_msg});
        case UNAUTHORIZED_USER:
            localStorage.removeItem('accessToken');
            localStorage.removeItem('userProfile');
            localStorage.removeItem('userAvatar');
            browserHistory.push('/login');
            return Object.assign({}, initialState, {loading: false});
        case AUTHENTICATION_INPROGRESS:
            return Object.assign({}, state, {invalidUser: false, loading: true});
        case PASSWORD_CHANGE_INPROGRESS:
            return Object.assign({}, state, {changePasswordLoading: true});
        case PASSWORD_CHANGE_SUCCESS:
            return Object.assign({}, state, {
                isPasswordChanged: true,
                successMsg: action.data.message,
                changePasswordLoading: false
            });
        case PASSWORD_CHANGE_NOT_SUCCESS:
            return Object.assign({}, state, {
                isPasswordChanged: false,
                errMsg: action.data.user_msg,
                changePasswordLoading: false
            });
        case STORE_USER_AVATAR_UPLOAD_SUCCESS:
            localStorage.setItem("userAvatar",action.data.appUserAvatar);
            return Object.assign({}, state, {userAvatar:action.data.appUserAvatar,fileUploadSuccess:true});
        case ERROR_UPLOAD_USER_AVATAR:
            return Object.assign({}, state, {isErrorFileUpload:true});
        case FORGOT_PASSWORD_START:
            return Object.assign({},state,{loading:true});
        case FORGOT_PASSWORD_SUCCESS:
            return Object.assign({}, state,{success:action.data.success,success_msg:action.data.success_msg,loading:false});
        case FORGOT_PASSWORD_ERROR:
            return Object.assign({},state,{is_Error:true,error_msg:action.data.error_msg,loading:false});
        case FORGOT_PASSWORD_COMPLETE:
            return Object.assign({},state,{is_Error:false,success:false});
        case CHECK_FORGOT_PASSWORD_SUCCESS:
            return Object.assign({},state,{status:action.data.status,message:action.data.message,userInfo:action.data.userInfo,loading:false});
        case CHECK_FORGOT_PASSWORD_ERROR:
            return Object.assign({},state,{isErrorCheckPassword:action.data.isErrorResetPassword,errorMsgCheckPassword:action.data.errorMsgCheckPassword,loading:false});
        case RESET_PASSWORD_SUCCESS:
            return Object.assign({},state,{resetPasswordStatus:action.data.status,resetPasswordMessage:action.data.message,loading:false});
        default:
            return state;
    }
};
