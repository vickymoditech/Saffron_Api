import {combineReducers} from 'redux';
import {routerReducer} from 'react-router-redux';

import authReducer from './authReducer';
import ddsStartupReducer from './ddsStartupReducer';
import storeConfigurationReducer from './storeConfigurationReducer';
import analyticsReducer from './analyticsReducer';

const rootReducer = combineReducers({
    authReducer,
    ddsStartupReducer,
    storeConfigurationReducer,
    analyticsReducer,
    routing: routerReducer
});

export default rootReducer;
