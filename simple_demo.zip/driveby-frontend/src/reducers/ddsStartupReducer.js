import {
    DDS_STARTUP_DATA,
    NETWORK_ERROR,
    ORDER_DETAIL,
    INITIAL_ORDER_DETAIL,
    ORDER_NOT_FOUND,
    NOT_FOUND,
    RECENT_ORDERS,
    LOAD_RECENT_ORDERS,
    DATA_RECEIVED,
    LOAD_DDS_DATA,
    LOAD_DDS_DATA_SUCCESS,
    LOAD_CHAT_DATA,
    LOAD_CHAT_DATA_SUCCESS,
    CHAT_STARTUP_DATA,
    CHAT_DETAIL,
    INITIAL_CHAT_DETAIL,
    CHAT_NOT_FOUND
} from '../constants/actionTypes'
import initialState from './initialState';

export default function ddsStartupReducer(state = initialState.ddsStartupReducer, action) {
    switch (action.type) {
        case LOAD_DDS_DATA:
            return Object.assign({}, state, {startLoadDDSData: true, loading: true});
        // case LOAD_DDS_DATA_SUCCESS:
        //     return Object.assign({}, state, {startLoadDDSData:false});
        case DDS_STARTUP_DATA:
            return Object.assign({}, state, {DDSStartupData: action.data, loading: false, startLoadDDSData: false});
        case NETWORK_ERROR:
            return Object.assign({}, state, {networkError: true});
        case ORDER_DETAIL:
            return Object.assign({}, state, {currentOrderDetail: action.data});
        case INITIAL_ORDER_DETAIL:
            return Object.assign({}, state, {currentOrderDetail: {}});
        case ORDER_NOT_FOUND:
            return Object.assign({}, state, {orderNotFound: true});
        case NOT_FOUND:
            return Object.assign({}, state, {storeNotFound: true});
        case RECENT_ORDERS:
            return Object.assign({}, state, {recentOrders: action.data.recentOrders, loadRecentOrder: false});
        case LOAD_RECENT_ORDERS:
            return Object.assign({}, state, {loadRecentOrder: true});
        case DATA_RECEIVED:
            return Object.assign({}, state, {loadRecentOrder: false});
        case LOAD_CHAT_DATA:
            return Object.assign({}, state, {chatDetailsLoading:true});
        case LOAD_CHAT_DATA_SUCCESS:
            return Object.assign({}, state, {chatDetailsLoading:false});
        case CHAT_STARTUP_DATA:
            return Object.assign({}, state, {chatDetailsLoading:false,chatStartupData:action.data});
        case CHAT_DETAIL:
            return Object.assign({}, state, {currentOrderChatDetail: action.data,getChatData:true});
        case INITIAL_CHAT_DETAIL:
            return Object.assign({}, state, {currentOrderChatDetail: {},getChatData:false});
        case CHAT_NOT_FOUND:
            return Object.assign({}, state, {chatDetailsNotFound: true,getChatData:true});
        default:
            return state;
    }
};