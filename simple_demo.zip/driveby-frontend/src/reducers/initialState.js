import decode from 'jwt-decode';
let accessToken = localStorage.getItem('accessToken');
let userProfile;

if(accessToken){
    try{
        userProfile = decode(accessToken);
    }catch (error){
        userProfile = []
    }
}

export default {
    authReducer:{
        loading:false,
        userProfile:userProfile || [],
        userAvatar:localStorage.getItem('userAvatar')
    },
    ddsStartupReducer:"",
    storeConfigurationReducer:"",
    analyticsReducer:{
        loading:false,
        reportData:[],
        loadingAllStore:false,
        reportDataAllStore:[],
        loadingAvgWitTime:false,
        reportDataAvgWaitTime:[],
        loadingRating:false,
        reportDataRating:[],
        loadingTransport:false,
        reportDataTransport:[],
        loadingTicketStats:false,
        reportDataTicketStats:[],
        loadingRequestByHours:false,
        reportDataRequestByHours:[],
        loadingRequestLocationTracking:false,
        reportDataRequestLocationTracking:[],
        loadingReRequestedOrder:false,
        reportDataReRequestedOrder:[],
        loadingCancelledRequest:false,
        reportDataCancelledRequest:[],
        loadingTransportTypeByDate:false,
        reportDataTransportTypeByDate:[],
        loadingMostActiveCustomers:false,
        reportDataMostActiveCustomers:[],
        loadingMostActiveCustomersAllStore:false,
        reportDataMostActiveCustomersAllStore:[]
    }
}
