import {
    STORE_CONFIGURE_SUCCESS,
    ERROR_CONFIGURE_STORE,
    LOADING_ALL_STORES,
    GET_ALL_STORES,
    STORE_EDITED_SUCCESS,
    ERROR_EDITED_STORE,
    USER_CONFIGURE_SUCCESS,
    ERROR_USER_CONFIGURE_STORE,
    GET_ALL_USER_ROLES,
    ERROR_GET_USER_ROLES,
    GET_ALL_USERS,
    ERROR_GET_ALL_USERS,
    USER_EDITED_SUCCESS,
    ERROR_EDITING_USER,
    LOADING_USER,
    CHANGE_VALUE_ERROR
} from '../constants/actionTypes'
import initialState from './initialState';

export default function storeConfigurationReducer(state = initialState.storeConfigurationReducer, action) {
    switch (action.type) {
        case STORE_CONFIGURE_SUCCESS:
            let allStores = [...state.allStores,action.data.newRecord];
            return Object.assign({}, state, {allStores:allStores,storeConfigSuccess: true,loading:false});
        case STORE_EDITED_SUCCESS:
            let stores = state.allStores;
            let allStoresEdited = stores && stores.map((value)=>{
                if(value.storeId === action.data.editedRecord.storeId){
                    return action.data.editedRecord;
                }else return value;
            });
            return Object.assign({}, state, {allStores:allStoresEdited,storeEditedSuccess: true,loading:false});
        case ERROR_CONFIGURE_STORE:
            return Object.assign({},state, {errors:action.data.user_msg,loading:false});
        case ERROR_EDITED_STORE:
            return Object.assign({},state, {errorsEditing:action.data.user_msg,loading:false});
        case LOADING_ALL_STORES:
            return Object.assign({},state,{loading:action.data.loading});
        case GET_ALL_STORES:
            return Object.assign({},state,{loading:action.data.loading,allStores:action.data.allStores});
        case USER_CONFIGURE_SUCCESS:
            let allUsers = state.allUsers;
            allUsers.users = allUsers.users.length ? [...state.allUsers.users,action.data.newRecord] : [action.data.newRecord];
            return Object.assign({},state,{userConfigureSuccess:true,loading:false,allUsers:allUsers});
        case ERROR_USER_CONFIGURE_STORE:
            return Object.assign({},state,{errorsAddUser:action.data.user_msg,loading:false});
        case GET_ALL_USER_ROLES:
            return Object.assign({},state,{allRoles:action.data.allRoles.roles,loading:false});
        case ERROR_GET_USER_ROLES:
            return Object.assign({},state,{errorsGetRoles:action.data.user_msg,loading:false});
        case LOADING_USER:
            return Object.assign({},state,{loadingGetUsers:true});
        case GET_ALL_USERS:
            return Object.assign({},state,{allUsers:action.data.allUsers,getAllUserSuccess:false,loadingGetUsers:false});
        case ERROR_GET_ALL_USERS:
            return Object.assign({},state,{errorGetAllUsers:action.data.user_msg,loadingGetUsers:false});
        case USER_EDITED_SUCCESS:
            let allUser = state.allUsers.users;
            let allUserEdited = allUser && allUser.map((value)=>{
                    if(value.userName === action.data.editedRecord.userName){
                        return action.data.editedRecord;
                    }else return value;
                });
            let allUserNew = {
                storeId:state.storeId,
                users:allUserEdited
            };
            return Object.assign({},state,{allUsers:allUserNew,userEditedSuccess: true,loading:false});
        case ERROR_EDITING_USER:
            return Object.assign({},state,{errorEditUser:action.data.user_msg,loading:false});
        case CHANGE_VALUE_ERROR:
            return Object.assign({},state,{
                storeConfigSuccess:false,storeEditedSuccess:false,userConfigureSuccess:false,getAllUserSuccess:false,userEditedSuccess:false,errors:false,
                errorsGetRoles:false,errorsAddUser:false,errorGetAllUsers:false,errorEditUser:false
            });
        default:
            return state;
    }
}
