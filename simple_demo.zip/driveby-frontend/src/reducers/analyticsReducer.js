import {
    GET_ANALYTICS_DATA,
    GET_ANALYTICS_DATA_SUCCESS,
    GET_ANALYTICS_DATA_ERROR,
    GET_ANALYTICS_DATA_ALL_STORE,
    GET_ANALYTICS_DATA_SUCCESS_ALL_STORE,
    GET_ANALYTICS_DATA_ERROR_ALL_STORE,
    GET_ANALYTICS_DATA_AVG_WAIT_TIME,
    GET_ANALYTICS_DATA_SUCCESS_AVG_WAIT_TIME,
    GET_ANALYTICS_DATA_ERROR_AVG_WAIT_TIME,
    GET_ANALYTICS_DATA_RATING,
    GET_ANALYTICS_DATA_SUCCESS_RATING,
    GET_ANALYTICS_DATA_ERROR_RATING,
    GET_ANALYTICS_DATA_TRANSPORT,
    GET_ANALYTICS_DATA_SUCCESS_TRANSPORT,
    GET_ANALYTICS_DATA_ERROR_TRANSPORT,
    GET_ANALYTICS_DATA_TICKET_STATS,
    GET_ANALYTICS_DATA_SUCCESS_TICKET_STATS,
    GET_ANALYTICS_DATA_ERROR_TICKET_STATS,
    GET_ANALYTICS_DATA_REQUEST_BY_HOURS,
    GET_ANALYTICS_DATA_SUCCESS_REQUEST_BY_HOURS,
    GET_ANALYTICS_DATA_ERROR_REQUEST_BY_HOURS,
    GET_ANALYTICS_DATA_REQUEST_LOCATION_TRACKING,
    GET_ANALYTICS_DATA_SUCCESS_REQUEST_LOCATION_TRACKING,
    GET_ANALYTICS_DATA_ERROR_REQUEST_LOCATION_TRACKING,
    GET_ANALYTICS_DATA_REREQUEST_ORDER,
    GET_ANALYTICS_DATA_SUCCESS_REREQUEST_ORDER,
    GET_ANALYTICS_DATA_ERROR_REREQUEST_ORDER,
    GET_ANALYTICS_DATA_CANCELLED_REQUESTS,
    GET_ANALYTICS_DATA_SUCCESS_CANCELLED_REQUESTS,
    GET_ANALYTICS_DATA_ERROR_CANCELLED_REQUESTS,
    GET_ANALYTICS_DATA_TRANSPORT_TYPE_BY_DATE,
    GET_ANALYTICS_DATA_SUCCESS_TRANSPORT_TYPE_BY_DATE,
    GET_ANALYTICS_DATA_ERROR_TRANSPORT_TYPE_BY_DATE,
    GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS,
    GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS,
    GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS,
    GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS_ALL_STORES,
    GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS_ALL_STORES,
    GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS_ALL_STORES
}
    from  '../constants/actionTypes'
import initialState from './initialState';
export default function authReducer(state = initialState.analyticsReducer, action) {
    switch (action.type) {
        case GET_ANALYTICS_DATA:
            return Object.assign({}, state, {loading: true});
        case GET_ANALYTICS_DATA_SUCCESS:
            return Object.assign({}, state, {loading: false, reportData: action.data});
        case GET_ANALYTICS_DATA_ERROR:
            return Object.assign({}, state, {loading: false});
        case GET_ANALYTICS_DATA_ALL_STORE:
            return Object.assign({}, state, {loadingAllStore: true});
        case GET_ANALYTICS_DATA_SUCCESS_ALL_STORE:
            return Object.assign({}, state, {loadingAllStore: false, reportDataAllStore: action.data});
        case GET_ANALYTICS_DATA_ERROR_ALL_STORE:
            return Object.assign({}, state, {loadingAllStore: false});
        case GET_ANALYTICS_DATA_AVG_WAIT_TIME:
            return Object.assign({}, state, {loadingAvgWitTime: true});
        case GET_ANALYTICS_DATA_SUCCESS_AVG_WAIT_TIME:
            return Object.assign({}, state, {loadingAvgWitTime: false, reportDataAvgWaitTime: action.data});
        case GET_ANALYTICS_DATA_ERROR_AVG_WAIT_TIME:
            return Object.assign({}, state, {loadingAvgWitTime: false});
        case GET_ANALYTICS_DATA_RATING:
            return Object.assign({}, state, {loadingRating: true});
        case GET_ANALYTICS_DATA_SUCCESS_RATING:
            return Object.assign({}, state, {loadingRating: false, reportDataRating: action.data});
        case GET_ANALYTICS_DATA_ERROR_RATING:
            return Object.assign({}, state, {loadingRating: false});
        case GET_ANALYTICS_DATA_TRANSPORT:
            return Object.assign({}, state, {loadingTransport: true});
        case GET_ANALYTICS_DATA_SUCCESS_TRANSPORT:
            return Object.assign({}, state, {loadingTransport: false, reportDataTransport: action.data});
        case GET_ANALYTICS_DATA_ERROR_TRANSPORT:
            return Object.assign({}, state, {loadingTransport: false});
        case GET_ANALYTICS_DATA_TICKET_STATS:
            return Object.assign({}, state, {loadingTicketStats: true});
        case GET_ANALYTICS_DATA_SUCCESS_TICKET_STATS:
            return Object.assign({}, state, {loadingTicketStats: false, reportDataTicketStats: action.data});
        case GET_ANALYTICS_DATA_ERROR_TICKET_STATS:
            return Object.assign({}, state, {loadingTicketStats: false});
        case GET_ANALYTICS_DATA_REQUEST_BY_HOURS:
            return Object.assign({}, state, {loadingRequestByHours: true});
        case GET_ANALYTICS_DATA_SUCCESS_REQUEST_BY_HOURS:
            return Object.assign({}, state, {loadingRequestByHours: false, reportDataRequestByHours: action.data});
        case GET_ANALYTICS_DATA_ERROR_REQUEST_BY_HOURS:
            return Object.assign({}, state, {loadingRequestByHours: false});
        case GET_ANALYTICS_DATA_REQUEST_LOCATION_TRACKING:
            return Object.assign({}, state, {loadingRequestLocationTracking: true});
        case GET_ANALYTICS_DATA_SUCCESS_REQUEST_LOCATION_TRACKING:
            return Object.assign({}, state, {
                loadingRequestLocationTracking: false,
                reportDataRequestLocationTracking: action.data
            });
        case GET_ANALYTICS_DATA_ERROR_REQUEST_LOCATION_TRACKING:
            return Object.assign({}, state, {loadingRequestLocationTracking: false});
        case GET_ANALYTICS_DATA_REREQUEST_ORDER:
            return Object.assign({}, state, {loadingReRequestedOrder: true});
        case GET_ANALYTICS_DATA_SUCCESS_REREQUEST_ORDER:
            return Object.assign({}, state, {
                loadingReRequestedOrder: false,
                reportDataReRequestedOrder: action.data
            });
        case GET_ANALYTICS_DATA_ERROR_REREQUEST_ORDER:
            return Object.assign({}, state, {loadingReRequestedOrder: false});
        case GET_ANALYTICS_DATA_CANCELLED_REQUESTS:
            return Object.assign({}, state, {loadingCancelledRequest: true});
        case GET_ANALYTICS_DATA_SUCCESS_CANCELLED_REQUESTS:
            return Object.assign({}, state, {
                loadingCancelledRequest: false,
                reportDataCancelledRequest: action.data
            });
        case GET_ANALYTICS_DATA_ERROR_CANCELLED_REQUESTS:
            return Object.assign({}, state, {loadingCancelledRequest: false});
        case GET_ANALYTICS_DATA_TRANSPORT_TYPE_BY_DATE:
            return Object.assign({}, state, {loadingTransportTypeByDate: true});
        case GET_ANALYTICS_DATA_SUCCESS_TRANSPORT_TYPE_BY_DATE:
            return Object.assign({}, state, {
                loadingTransportTypeByDate: false,
                reportDataTransportTypeByDate: action.data
            });
        case GET_ANALYTICS_DATA_ERROR_TRANSPORT_TYPE_BY_DATE:
            return Object.assign({}, state, {loadingTransportTypeByDate: false});
        case GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS:
            return Object.assign({}, state, {loadingMostActiveCustomers: true});
        case GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS:
            return Object.assign({}, state, {
                loadingMostActiveCustomers: false,
                reportDataMostActiveCustomers: action.data
            });
        case GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS:
            return Object.assign({}, state, {loadingMostActiveCustomers: false});
        case GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS_ALL_STORES:
            return Object.assign({}, state, {loadingMostActiveCustomersAllStore: true});
        case GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS_ALL_STORES:
            return Object.assign({}, state, {
                loadingMostActiveCustomersAllStore: false,
                reportDataMostActiveCustomersAllStore: action.data
            });
        case GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS_ALL_STORES:
            return Object.assign({}, state, {loadingMostActiveCustomersAllStore: false});
        default:
            return state;
    }
}