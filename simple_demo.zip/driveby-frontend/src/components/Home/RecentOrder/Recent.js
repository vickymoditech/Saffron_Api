import React, {Component} from 'react';
import Loader from 'react-loader';
import {orderBy} from "lodash";

import Logout from './Logout';
import InformationDialog from './InformationDialog';

export default class Recent extends Component {

    render() {
        const {recentOrderData} = this.props;
        const recentOrder = recentOrderData && recentOrderData.map((requests) => ({
                ...requests,
                completeTime: requests.driveByDetails.actionDateTime
            }));
        const sortedRecentOrders = orderBy(recentOrder, ['completeTime'], ['desc']);

        return (
            <div className="bottom-sidebar">
                <h3 className="sub-title">
                    Recent
                </h3>
                {this.props.isLoading ? <div><Loader loaded={false}/></div> : <ul className="recent-details">
                    {
                        sortedRecentOrders && sortedRecentOrders.map((data, index) => (
                            <InformationDialog ticketInfo={data} key={index} storeInfo={this.props.storeInfo}
                                               storeName={this.props.storeName}/>
                        ))
                    }
                </ul>
                }
                <Logout/>
            </div>
        );
    }
}



