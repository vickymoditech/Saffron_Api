import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import * as authAction from '../../../actions/authAction';

class Logout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            userName: (props.auth.userProfile && props.auth.userProfile.userName) || "",
            userAvatar: (props.auth.userProfile && props.auth.userProfile.userAvatar) || ""
        }
    }

    handleLogout = () => {
        this.props.actions.auth.loggedOut();
    };

    componentWillReceiveProps(nextProps) {
        this.setState({
            userName: (nextProps.auth.userProfile && nextProps.auth.userProfile.userName) || "",
            userAvatar: (nextProps.auth.userProfile && nextProps.auth.userProfile.userAvatar) || ""
        });
    }

    render() {
        return (
            <div>
                <a className="log-out" onClick={this.handleLogout}>Log Out</a>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    const {authReducer} = state;
    return {
        auth: authReducer
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        auth: bindActionCreators(authAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Logout);

