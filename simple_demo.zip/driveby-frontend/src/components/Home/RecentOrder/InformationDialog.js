import React, {Component} from 'react';

import TicketInformationDialog from '../../Helpers/TicketInformationDialog';

export default class InformationDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false
        };
    }

    handleOpenInfoDialog = () => {
        this.setState({isOpen: true});
    };

    handleCloseDialog = () => {
        this.setState({isOpen: false});
    };

    render(){
        let ticketInfo = this.props.ticketInfo;
        return(
                <li style={{cursor: 'pointer'}} onClick={this.handleOpenInfoDialog}
                    className={ticketInfo.driveByDetails.status.toLowerCase() === "Completed".toLowerCase() ? "on" : "off"}
                >
                    {this.state.isOpen && <TicketInformationDialog
                        ticketInformation={ticketInfo}
                        column="running late"
                        completed={true}
                        handleClose={this.handleCloseDialog}
                        storeInfo={this.props.storeInfo}
                        storeName={this.props.storeName}
                    />}
                    #{ticketInfo.order.orderNumber.split("/")[0]}
                </li>

        )
    }
}

