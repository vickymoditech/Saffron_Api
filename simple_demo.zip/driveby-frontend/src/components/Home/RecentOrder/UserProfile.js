import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import $ from 'jquery';
import NotificationSystem from 'react-notification-system';

import * as authAction from '../../../actions/authAction';
import DefaultUser from '../../Helpers/DriveThroughIcons/DefaultUser';

class UserProfile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            notificationSystem: null,
            userName: (props.auth.userProfile && props.auth.userProfile.firstName) || "",
            userLastName: (props.auth.userProfile && props.auth.userProfile.lastName) || "",
            userAvatar: (props.auth.userProfile && props.auth.userProfile.userAvatar) || ""
        }
    }

    addNotification = (message, level) => {
        this.state.notificationSystem.addNotification({
            message: message,
            level: level,
            autoDismiss: 3
        });
    };

    onHandleFileUpload = () => {
        $('#imgUpload').trigger('click');
    };

    onFileUpload = (e) => {
        let files = e.target.files[0];
        if(files){
            this.props.actions.auth.uploadStoreUserAvatar(files);
        }
    };

    componentWillReceiveProps(nextProps) {
        if(nextProps.fileUploadSuccess){
            this.addNotification('Image uploaded successfully','success');
        }
        if(nextProps.isErrorFileUpload){
            this.addNotification('Error while uploading Image','error');
        }
        this.setState({
            userName: (nextProps.auth.userProfile && nextProps.auth.userProfile.firstName) || "",
            userLastName: (nextProps.auth.userProfile && nextProps.auth.userProfile.lastName) || "",
            userAvatar: (nextProps.auth.userProfile && nextProps.auth.userProfile.userAvatar) || ""
        });
    }

    componentDidMount() {
        this.setState({notificationSystem : this.refs.notificationSystem});
    };

    render() {
        return (
            <div className="top-sidebar">
                <NotificationSystem ref="notificationSystem"/>
                <div className="image-div">
                    <input type="file" id="imgUpload" style={{display:'none'}} onChange={this.onFileUpload}/>
                    <a onClick={this.onHandleFileUpload} style={{position: 'absolute',right: '10px'}} title="Upload User Avatar"><i className="fa fa-pencil edit pull-right"/></a>
                    <div className="top-sidebar-img">
                    {
                        this.props.userAvatar ?
                            <img src={this.props.userAvatar} className="user-img" alt=""/> :
                            <DefaultUser/>
                    }
                    </div>
                    <h4 className="heading-name text-center" style={{fontSize:'18px'}}>{this.state.firstName}</h4>
                    <p className="subheading-name text-center"><a onClick={this.props.actions.auth.loggedOut} style={{cursor:'pointer'}}>(not you?)</a></p>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    const {authReducer} = state;
    return {
        auth: authReducer,
        fileUploadSuccess:authReducer.fileUploadSuccess,
        isErrorFileUpload:authReducer.isErrorFileUpload,
        userAvatar:authReducer.userAvatar
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        auth: bindActionCreators(authAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(UserProfile);