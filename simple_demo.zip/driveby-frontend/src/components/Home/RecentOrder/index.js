import React, {Component} from 'react';
import Recent from './Recent';
import UserProfile from './UserProfile';

export default class RecentOrder extends Component {

    render() {
        return (
            <div className={this.props.isResetOpen ? "sidebar recent-runner" : "sidebar"}>
                <UserProfile handleLogout={this.props.handleLogout}/>
                <Recent recentOrderData={this.props.recentOrderData} isLoading={this.props.isLoading} handleLogout={this.props.handleLogout} storeInfo={this.props.storeInfo} storeName={this.props.storeName} isResetOpen={this.props.isResetOpen}/>
            </div>
        );
    }
}


