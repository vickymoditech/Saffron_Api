import moment from 'moment';
export const waitingTime = (requestedTime , actionTime) =>{
    let diffMs = Math.abs(actionTime - requestedTime);
    return diffMs;
};

export const getDateGMT = (dateToConvertGMT,timeZone) => {
    const userProfile = JSON.parse(localStorage.getItem('userProfile'));
    if(userProfile){
        return moment(dateToConvertGMT).utcOffset(timeZone);
    }
    else{
        return moment(Date.now());
    }
};

export const pickupInTime = (requestedTime,timeZone) => {
    let pickUpTime = requestedTime.split(":");
    let convertedDate = getDateGMT(Date.now(),timeZone).format("HH:mm:ss").split(":");
    let timeDiffHour = (parseInt(pickUpTime[0])-parseInt(convertedDate[0]));
    let timeDiffMinute = (parseInt(pickUpTime[1]) || 0) - (parseInt(convertedDate[1]) || 0);
    let diffMs = (timeDiffHour*60*60*1000) + (timeDiffMinute*60*1000);
    if (diffMs < 0) {
        return 0;
    }
    return Math.floor(((diffMs / 1000) / 60));
};