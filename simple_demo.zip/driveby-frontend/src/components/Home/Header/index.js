import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import { Dropdown } from 'semantic-ui-react'
import moment from 'moment';
import {orderBy} from "lodash";
import {getDateGMT} from '../waitingTime';
import * as storeConfigurationAction from '../../../actions/storeConfigurationAction';
import SidebarComponent from '../../Helpers/Sidebar';

class Header extends Component {
    constructor(props) {
        super(props);
        const userProfile = props.userProfile;
        this.state = {
            date: this.getDateGMTChangeStore(userProfile.store.gmtOffset),
            timeZone:userProfile.store.gmtOffset,
            sidebar: false,
            isOpen: false,
            open:false,
            isResetOpen:false,
            allStores:[],
            storeName:userProfile.store.storeName,
            userRole:userProfile.roleOrder,
            storeInfo:{
                latitude:userProfile.store.latitude,
                longitude:userProfile.store.longitude
            }
        }
    }

    componentWillMount(){
        if(this.state.userRole === 1){
            this.props.actions.StoreConfiguration.getAllStores();
        }
    }

    componentDidMount() {
        this.timerID = setInterval(
            () => this.tick(),
            1000
        );
    }

    componentWillUnmount() {
        clearInterval(this.timerID);
    };

    openNav = () => {
        this.setState({open:true});
    };

    closeNav = () => {
        this.setState({open:false});
    };

    onRecentOpen = () => {
        this.props.handleRecent();
    };

    tick() {
        this.setState({
            date: this.getDateGMTChangeStore(this.state.timeZone)
        });
    }

    handleChangeStore = (event, { value }) => {
        const {allStores} = this.state;
        let zone=this.state.timeZone;
        let storeInfo = this.state.storeInfo;
        allStores && allStores.filter((data)=>{
            if(value.toString() === data.storeName.toString()){
                zone=data.gmtOffset;
                storeInfo = {
                    latitude:data.latitude,
                    longitude:data.longitude
                }
            }
        });

        if(this.state.storeName !== value){
            this.props.handleChangeStore(value,zone,storeInfo);
        }

        this.setState({storeName:value,timeZone:zone});
    };

    getDateGMTChangeStore = (timeZone) => {
        return moment(Date.now()).utcOffset(timeZone).format("HH:mm:ss");
    };

    componentWillReceiveProps(nextProps) {
        this.setState({allStores:nextProps.allStores || []});
    }

    render() {
        let currentDate = this.getDateGMTChangeStore(this.state.timeZone);
        if (currentDate === "01:00:00") {
            window.location.reload();
        }
        const {allStores} = this.state;
        let options =[];
        allStores && allStores.map((data)=>{
            options.push({ text: data.storeName, value: data.storeName})
        });
        const sortedOptions = orderBy(options,['text'],'asc');
        return (
            <div className="header-box">
                {this.state.open && <SidebarComponent closeNav={this.closeNav} open={this.state.open} handleOpen={this.openChangePasswordModal}/>}
                <div id="main" className="collespe">
                    <span><img src="/assets/Images/menu.png" onClick={this.openNav} alt="" /></span>
                </div>
                <div className="recent-arrow" onClick={this.onRecentOpen}>
                    <i className="fa fa-bars" aria-hidden="true"/>
                    <i className="fa fa-arrow-right" aria-hidden="true"/>
                </div>
                <nav className="navbar">
                    <div className="navbar-header">
                        <a className="navbar-brand"><img src="/assets/Images/DB_Logo.png" alt=""/></a>
                    </div>
                    {
                        this.state.userRole===1 && options.length > 0 && <div className="header-dropdown" style={{marginTop:10}}>
                        <Dropdown
                            options={sortedOptions}
                            search
                            fluid
                            selection
                            className="header-select-dropdown"
                            value={this.state.storeName}
                            onChange={this.handleChangeStore}
                        />
                    </div>
                    }

                    <div className="collapse navbar-collapse time-ul" id="bs-example-navbar-collapse-1">
                        <ul className="nav navbar-nav navbar-right">
                            <li className="sub-title">Current Time - {this.state.date} |</li>
                            <li className="sub-title">Average Wait Time - <span
                                className="average-wait-time">{this.props.avgWaitTime}</span></li>
                        </ul>
                    </div>
                </nav>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    const {storeConfigurationReducer,authReducer} = state;
    return{
        allStores: storeConfigurationReducer.allStores || [],
        userProfile:authReducer.userProfile
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        StoreConfiguration: bindActionCreators(storeConfigurationAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Header);