import React, {Component} from 'react';
import {orderBy} from "lodash";
import DriveByComponent from '../../Helpers/DriveByComponent';
import {waitingTime} from '../waitingTime';
import jQuery from 'jquery';
import {getDateGMT} from '../waitingTime';

export default class HereNow extends Component {
    constructor(props){
        super(props);
        this.state={
            currentTicket:0
        }
    }

    setTicket = (activeTicket) => {
        let windowWidth = jQuery(window).width();
        let windowHeight = jQuery(window).height() - 130; //130 px for header part
        let lengthoful= document.getElementById("here-now") && document.getElementById("here-now").getElementsByTagName("li").length;
        let liHeight = jQuery("#here-now")[0] && jQuery("#here-now li").height();
        let hereNowHeight = jQuery("#here-now")[0] && ((liHeight * lengthoful));
        // if(windowWidth <= 992){
        //     jQuery(".here-now .card-body").addClass("overflow-scroll");
        //     jQuery("#here-now li").each(function(){
        //         jQuery(this).css("margin-bottom","8px");
        //     });
        // }
        // else{
            if(hereNowHeight > windowHeight-50){
                let hereNowUl = jQuery("#here-now li");
                let prevTicket = hereNowUl.slice(0,activeTicket);
                let currentTickets = hereNowUl.slice(activeTicket,activeTicket+4);
                let lastTicket = hereNowUl.slice(activeTicket+3,lengthoful);
                let ulHeight = Math.floor(hereNowHeight/lengthoful*4);
                let remainHeight = windowHeight - ulHeight-24-4-20; //24px for 8px of each margin bottom,4 px for bottom
                let marginSetValue = liHeight - remainHeight/(prevTicket.length+lastTicket.length-1);
                let marginSet;
                if(marginSetValue < 60){
                    marginSet = "-"+(marginSetValue)+"px";
                }else{
                    jQuery('.here-now-scroll').addClass('overflow-scroll');
                    marginSet = "-60px";
                }
                let prevTicketLength = prevTicket.length;
                jQuery("#here-now li").each(function(i,data){
                    let bodyStyle = data.style;
                    bodyStyle.removeProperty('position');
                    bodyStyle.removeProperty('z-index');
                    bodyStyle.removeProperty('opacity');
                    bodyStyle.removeProperty('margin-bottom');
                    bodyStyle.removeProperty('margin-top');
                });
                currentTickets.each(function (index,data) {
                    currentTickets[index].style.marginBottom = '8px';
                });
                prevTicket.each(function(index,data){
                    prevTicket[prevTicketLength - (index+1)].style.position='relative';
                    prevTicket[prevTicketLength - (index+1)].style.marginBottom=marginSet;
                });
                let lastTicketLength = lastTicket.length;
                lastTicket.each(function(index,data){
                    lastTicket[index].style.position='relative';
                    lastTicket[index].style.zIndex=lastTicketLength - index;
                    if(index !== 0){
                        lastTicket[index].style.marginTop=marginSet;
                    }
                });
            }else{
                jQuery("#here-now li").each(function(index,data){
                    if(lengthoful-1 !== index) jQuery(this).css("margin-bottom","8px");
                });
            }
        // }
        // jQuery("#here-now li").each(function(){
        //     jQuery(this).fadeOut("fast").fadeIn("slow","swing")
        // })
    };

    handleChangeTicket = (activeTicket) => {
        let lengthoful= document.getElementById("here-now") && document.getElementById("here-now").getElementsByTagName("li").length;
            if(activeTicket > lengthoful-4){
                this.setState({currentTicket:lengthoful-4});
            }else {
                this.setState({currentTicket:activeTicket});
            }
    };

    render() {
        const sortedData = this.props.driveByRequests;
        const driveByRequests = sortedData && sortedData.map((requests) => ({
                ...requests,
                waitingTime: waitingTime(getDateGMT(requests.driveByDetails.hereNowDateTime,this.props.timeZone), getDateGMT(Date.now(),this.props.timeZone))
            }));
        const sortedDriveByRequests = orderBy(driveByRequests, ['waitingTime'], ['desc']);
        return (
            <div className="col-lg-4 col-sm-12 col-md-6 card here-now">
                <div className="card-header"><span
                    className="item-number">{(driveByRequests && driveByRequests.length) || 0}</span>
                    <h3 className="sub-title">here Now!</h3></div>
                <div className="card-body here-now-scroll">
                    <ul id="here-now">
                        {
                            sortedDriveByRequests && sortedDriveByRequests.map((requests, index) => (
                                <DriveByComponent
                                    storeInfo={this.props.storeInfo}
                                    key={index}
                                    requestData={requests}
                                    time={Math.floor(((requests.waitingTime / 1000) /60))}
                                    timeZone={this.props.timeZone}
                                    status="waiting"
                                    column="here now"
                                    storeName={this.props.storeName}
                                    currentElement={index}
                                    handleChangeTicket={this.handleChangeTicket}
                                    updateStatus={this.props.updateStatus}
                                    handleCustomerNotificationStatus={this.props.handleCustomerNotificationStatus}
                                    handleCustomerNotificationStatusForComeIn={this.props.handleCustomerNotificationStatusForComeIn}
                                    handleSendMessage={this.props.handleSendMessage}
                                    handleReadMessage={this.props.handleReadMessage}
                                    handleReadStatusOpenChat={this.props.handleReadStatusOpenChat}
                                />
                            ))
                        }
                    </ul>
                </div>
            </div>
        );
    }

    componentDidUpdate(){
        this.setTicket(this.state.currentTicket);
    }
}