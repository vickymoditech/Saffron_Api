import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import NotificationSystem from 'react-notification-system';
import {groupBy, findIndex} from "lodash";
import PubNubReact from 'pubnub-react';

import RecentOrder from './RecentOrder';
import Header from './Header';
import HereNow from './HereNow';
import OnTheWay from './OnTheWay';
import RunningLate from './RunningLate';
import Loader from '../Helpers/Loader';
import {GyGLog} from '../../Logging/GyGLog';
import {getDateGMT} from './waitingTime';
import * as DDSStartupAction from '../../actions/DDSStartupAction';
import * as authAction from '../../actions/authAction';

import './column-layout.css';

class Home extends Component {
    constructor(props) {
        super(props);
        const userProfile = props.userProfile;
        const storeName = (userProfile && userProfile.store.storeName) || "";
        this.state = ({
            startupData: [],
            startGettingDDSData: false,
            controlChannelName: [],
            hereNow: [],
            runningLate: [],
            onTheWay: [],
            isNetworkError: false,
            isNew: false,
            storeName: storeName,
            newRequestOrderNumber: "",
            allDDSListenChannelName: [],
            isFirst: true,
            notificationSystem: null,
            avgWaitTime: [],
            recentOrder: [],
            isFirstRecent: true,
            clock: true,
            timeZone: userProfile.store.gmtOffset,
            storeInformation: {
                latitude: userProfile.store.latitude,
                longitude: userProfile.store.longitude
            },
            isResetOpen: false
        });
        try {
            this.pubnub = new PubNubReact({
                publishKey: 'pub-c-19816247-f9ed-4214-bf9f-d92a2961625e',
                subscribeKey: 'sub-c-39f660ae-a81b-11e7-a527-fa7c0b7198dc'
            });
            this.pubnub.init(this);
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component Constructor.' + error);
        }
    }

    addNotification = (message, level) => {
        this.state.notificationSystem && this.state.notificationSystem.addNotification({
            message: message,
            level: level,
            autoDismiss: 3
        });
    };

    componentWillMount() {
        this.initializeDDS(this.state.storeName, this.state.timeZone, this.state.storeInformation);
        let that = this;
        try {
            this.pubnub.addListener({
                message: function (msg) {
                    if (msg.message.messageType.toLowerCase() === "newRequest".toLowerCase()) {
                        that.newRequest(msg.message.data);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateRequest".toLowerCase()) {
                        that.updateRequest(msg.message.data);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateStatus".toLowerCase() && msg.message.data.newStatus.toLowerCase() === "HereNow".toLowerCase()) {
                        that.moveHereNow(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateStatus".toLowerCase() && msg.message.data.newStatus.toLowerCase() === "DeliveryInProgress".toLowerCase()) {
                        that.deliveryInProgress(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateLocation".toLowerCase()) {
                        that.updateLocation(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateStatus".toLowerCase() && msg.message.data.newStatus.toLowerCase() === "completed".toLowerCase()) {
                        that.orderCompleteCancel(msg, 'Completed');
                    }
                    if (msg.message.messageType.toLowerCase() === "updateStatus".toLowerCase() && msg.message.data.newStatus.toLowerCase() === "Cancelled".toLowerCase()) {
                        that.orderCompleteCancel(msg, 'Cancelled');
                    }
                    if (msg.message.messageType.toLowerCase() === "cancelledReason".toLowerCase()) {
                        that.addCancelledReason(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateStatus".toLowerCase() && msg.message.data.newStatus.toLowerCase() === "RunningLate".toLowerCase()) {
                        that.moveRunningLateConfirm(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateUserAvatar".toLowerCase()) {
                        that.updateUserAvatar(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateCustomerNotification".toLowerCase()) {
                        that.updateCustomerNotification(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "updateAvgWaitTime".toLowerCase()) {
                        that.updateAverageWaitTime(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "logout") {
                        that.logoutFromAll();
                    }
                    if (msg.message.messageType.toLowerCase() === "driveByRating".toLowerCase()) {
                        that.addRating(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "chatMessage".toLowerCase()) {
                        that.getChatMessage(msg);
                    }
                    if(msg.message.messageType.toLowerCase() === "SeenMessagesConfirm".toLowerCase()) {
                        that.seenMessagesConfirm(msg);
                    }
                    if(msg.message.messageType.toLowerCase() === "chatMessageConfirm".toLowerCase()) {
                        that.handleConfirmSendMessage(msg);
                    }
                    if(msg.message.messageType.toLowerCase() === "MessageStatusUpdateConfirm".toLowerCase()) {
                        that.handleConfirmSendMessageOpenScreen(msg);
                    }
                }
            });
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component ComponentWillMount Pubnub Add listener' + error);
        }
    };

    initializeDDS = (storeName, timeZone, storeInformation) => {
        this.pubnub.unsubscribe({channels: this.state.allDDSListenChannelName});
        let that = this;
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
        }
        this.setState({
            startupData: [],
            controlChannelName: [],
            hereNow: [],
            runningLate: [],
            onTheWay: [],
            loading: false,
            isNetworkError: false,
            isNew: false,
            newRequestOrderNumber: "",
            allDDSListenChannelName: [],
            isFirst: true,
            notificationSystem: null,
            avgWaitTime: [],
            recentOrder: [],
            isFirstRecent: true,
            storeName: storeName,
            timeZone: timeZone,
            storeInformation: storeInformation
        }, () => {
            that.props.actions.startupAction.getDDSStartup(storeName);
        });
    };

    componentDidMount() {
        this.setState({notificationSystem: this.refs.notificationSystem});
    };

    moveRunningLateConfirm = (request) => {
        let onTheWay = this.state.onTheWay;
        let runningLate = this.state.runningLate;
        let isAlreadyRunningLate = false;
        runningLate && runningLate.map((data) => {
            if (data.order.orderNumber === request.message.data.order.orderNumber) {
                isAlreadyRunningLate = true;
            }
        });
        if (isAlreadyRunningLate !== true) {
            let newOnTheWay = onTheWay && onTheWay.filter((data) => {
                    if (data.order.orderNumber === request.message.data.order.orderNumber) {
                        data.isRunningLate = true;
                        runningLate.push(data);
                        return false;
                    } else {
                        return true;
                    }
                });
            this.setState({onTheWay: newOnTheWay, runningLate: runningLate});
        }
    };

    moveRunningLate = () => {
        if (!this.pubnub) {
            this.pubnub = new PubNubReact({
                publishKey: 'pub-c-19816247-f9ed-4214-bf9f-d92a2961625e',
                subscribeKey: 'sub-c-39f660ae-a81b-11e7-a527-fa7c0b7198dc'
            });
            this.pubnub.init(this);
            this.pubnub.subscribe({channels: this.state.allDDSListenChannelName, withPresence: true});
            GyGLog('info', 'DDS Log Home Component Reinitialize pubnub.');
        }
        this.setState({clock: !this.state.clock});
    };

    updateLocation = (updateRequest) => {
        let {runningLate, onTheWay, hereNow} = this.state;
        let newRunningLate = runningLate && runningLate.filter((data) => {
                if (updateRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.driveByDetails.distanceInMeters = updateRequest.message.data.distance.distanceInMeters;
                    data.driveByDetails.durationInSeconds = updateRequest.message.data.distance.durationInSeconds;
                    data.location = data.location.length ? [...data.location, updateRequest.message.data.location] : [updateRequest.message.data.location];
                    return data;
                }
                else return data;
            });
        let newHereNow = hereNow && hereNow.filter((data) => {
                if (updateRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.driveByDetails.distanceInMeters = updateRequest.message.data.distance.distanceInMeters;
                    data.driveByDetails.durationInSeconds = updateRequest.message.data.distance.durationInSeconds;
                    data.location = data.location.length ? [...data.location, updateRequest.message.data.location] : [updateRequest.message.data.location];
                    return data;
                }
                else return data;
            });

        let newOnTheWay = onTheWay && onTheWay.filter((data) => {
                if (updateRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.driveByDetails.distanceInMeters = updateRequest.message.data.distance.distanceInMeters;
                    data.driveByDetails.durationInSeconds = updateRequest.message.data.distance.durationInSeconds;
                    data.location = data.location.length ? [...data.location, updateRequest.message.data.location] : [updateRequest.message.data.location];
                    return data;
                }
                else return data;
            });
        this.setState({runningLate: newRunningLate, onTheWay: newOnTheWay, hereNow: newHereNow});
    };

    updateStatus = (channelName, customerId, orderNumber, action) => {
        try {
            let message = {
                messageType: "updateStatus",
                data: {
                    "newStatus": action,
                    "order": {
                        "customerId": customerId,
                        "orderNumber": orderNumber
                    },
                    "sender": "DDS"
                }
            };
            this.pubnub.publish({message: message, channel: channelName});
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component updateStatus Pubnub publish message' + error);
        }
    };

    handleCustomerNotificationStatus = (channelName, customerId, orderNumber, action) => {
        try {
            if (action === "AdjustMapPosition" || action === "MessageGuest" || action === "TakePhoto") {
                this.addNotification("This feature is not implemented yet!", "warning");
            } else {
                const message = {
                    messageType: "updateCustomerNotification",
                    data: {
                        "customerNotification": {
                            "name": action
                        },
                        "order": {
                            "customerId": customerId,
                            "orderNumber": orderNumber
                        },
                        "sender": "DDS"
                    }
                };
                let that = this;
                this.pubnub.publish({message: message, channel: channelName}, (status, response) => {
                    if (status.statusCode === 200) {
                        that.addNotification && that.addNotification("Request successfully send to customer for " + action + ".", "success");
                    }
                });
            }
        }
        catch (error) {
            GyGLog('debug', 'DDS Log Home Component handleCustomerNotificationStatus Pubnub publish message' + error);
        }
    };

    handleCustomerNotificationStatusForComeIn = (channelName, customerId, orderNumber, action, reason) => {
        try {
            if (action === "AdjustMapPosition" || action === "MessageGuest" || action === "TakePhoto") {
                this.addNotification("This feature is not implemented yet!", "warning");
            } else {
                let {runningLate, onTheWay, hereNow} = this.state;
                let newRunningLate = runningLate && runningLate.filter((data) => {
                        if (orderNumber === data.order.orderNumber) {
                            data.driveByDetails.cancelledReason = reason;
                            return data;
                        }
                        else return data;
                    });

                let newHereNow = hereNow && hereNow.filter((data) => {
                        if (orderNumber === data.order.orderNumber) {
                            data.driveByDetails.cancelledReason = reason;
                            return data;
                        }
                        else return data;
                    });

                let newOnTheWay = onTheWay && onTheWay.filter((data) => {
                        if (orderNumber === data.order.orderNumber) {
                            data.driveByDetails.cancelledReason = reason;
                            return data;
                        }
                        else return data;
                    });
                let that = this;
                this.setState({runningLate: newRunningLate, onTheWay: newOnTheWay, hereNow: newHereNow}, () => {
                    const message = {
                        messageType: "storeCancelledNotification",
                        data: {
                            "customerNotification": {
                                "name": action,
                                "reason": reason
                            },
                            "order": {
                                "customerId": customerId,
                                "orderNumber": orderNumber
                            },
                            "sender": "DDS"
                        }
                    };

                    that.pubnub.publish({message: message, channel: channelName}, (status, response) => {
                        if (status.statusCode === 200) {
                            that.addNotification && that.addNotification("Request successfully send to customer for " + action + ".", "success");
                        }
                    });
                });
            }
        }
        catch (error) {
            GyGLog('debug', 'DDS Log Home Component handleCustomerNotificationStatus Pubnub publish message' + error);
        }
    };

    updateCustomerNotification = (notificationRequest) => {
        let {runningLate, onTheWay, hereNow} = this.state;
        let newRunningLate = runningLate && runningLate.filter((data) => {
                if (notificationRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.customerNotification = notificationRequest.message.data.customerNotification;
                    return data;
                }
                else return data;
            });

        let newHereNow = hereNow && hereNow.filter((data) => {
                if (notificationRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.customerNotification = notificationRequest.message.data.customerNotification;
                    return data;
                }
                else return data;
            });

        let newOnTheWay = onTheWay && onTheWay.filter((data) => {
                if (notificationRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.customerNotification = notificationRequest.message.data.customerNotification;
                    return data;
                }
                else return data;
            });
        this.setState({runningLate: newRunningLate, onTheWay: newOnTheWay, hereNow: newHereNow});
    };

    moveHereNow = (hereNowRequest) => {
        let onTheWay = this.state.onTheWay;
        let runningLate = this.state.runningLate;
        let hereNow = this.state.hereNow;
        let newOnTheWay = onTheWay && onTheWay.filter((data) => {
                if (hereNowRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.driveByDetails.actionDateTime = hereNowRequest.message.data.actionDateTime;
                    data.driveByDetails.status = hereNowRequest.message.data.newStatus;
                    data.driveByDetails.hereNowDateTime = hereNowRequest.message.data.actionDateTime;
                    data.isHereNow = true;
                    data.isSoundPlay = true;
                    hereNow.push(data);
                } else {
                    return true;
                }
            });

        let newRunningLate = runningLate && runningLate.filter((data) => {
                if (hereNowRequest.message.data.order.orderNumber === data.order.orderNumber) {
                    data.driveByDetails.actionDateTime = hereNowRequest.message.data.actionDateTime;
                    data.driveByDetails.status = hereNowRequest.message.data.newStatus;
                    data.driveByDetails.hereNowDateTime = hereNowRequest.message.data.actionDateTime;
                    data.isHereNow = true;
                    data.isSoundPlay = true;
                    hereNow.push(data)
                } else {
                    return true;
                }
            });
        this.setState({onTheWay: newOnTheWay, hereNow: hereNow, runningLate: newRunningLate});
    };

    deliveryInProgress = (changeStatusRequest) => {
        let onTheWay = this.state.onTheWay;
        let runningLate = this.state.runningLate;
        let hereNow = this.state.hereNow;
        let newOnTheWay = onTheWay && onTheWay.map((request) => {
                if (changeStatusRequest.message.data.order.orderNumber === request.order.orderNumber) {
                    request.driveByDetails.status = changeStatusRequest.message.data.newStatus;
                    request.driveByDetails.deliveryInProgressDateTime = changeStatusRequest.message.data.actionDateTime
                    return request
                } else {
                    return request
                }
            });

        let newRunningLate = runningLate && runningLate.map((request) => {
                if (changeStatusRequest.message.data.order.orderNumber === request.order.orderNumber) {
                    request.driveByDetails.status = changeStatusRequest.message.data.newStatus;
                    request.driveByDetails.deliveryInProgressDateTime = changeStatusRequest.message.data.actionDateTime;
                    return request
                } else {
                    return request
                }
            });

        let newHereNow = hereNow && hereNow.map((request) => {
                if (changeStatusRequest.message.data.order.orderNumber === request.order.orderNumber) {
                    request.driveByDetails.status = changeStatusRequest.message.data.newStatus;
                    request.driveByDetails.deliveryInProgressDateTime = changeStatusRequest.message.data.actionDateTime;
                    return request
                } else {
                    return request
                }
            });
        this.setState({onTheWay: newOnTheWay, hereNow: newHereNow, runningLate: newRunningLate});
    };

    getDriveRequestsByStatus = (driveByRequests) => {
        let sortedData = driveByRequests && driveByRequests.map((requests) => ({
                ...requests,
                status: requests.driveByDetails.status.toLowerCase()
            }));
        return groupBy(sortedData, "status");
    };

    setDriveByData = () => {
        let driveByRequests = this.state.onTheWay;
        const driveByRequestsByStatus = this.getDriveRequestsByStatus(driveByRequests);
        const allHereNowRequests = driveByRequestsByStatus.herenow || [];
        const deliveryInProgress = driveByRequestsByStatus.deliveryinprogress;
        const firstOnTheWayRequests = driveByRequestsByStatus.ontheway ? (driveByRequestsByStatus.requested ? driveByRequestsByStatus.ontheway.concat(driveByRequestsByStatus.requested) : driveByRequestsByStatus.ontheway) : (driveByRequestsByStatus.requested ? driveByRequestsByStatus.requested : []);
        const onTheWayWithReRequest = driveByRequestsByStatus.rerequested ? (firstOnTheWayRequests ? firstOnTheWayRequests.concat(driveByRequestsByStatus.rerequested || []) : driveByRequestsByStatus.rerequested || []) : firstOnTheWayRequests;
        const filterOnTheWayForDeliveryInProgress = onTheWayWithReRequest ? (deliveryInProgress ? onTheWayWithReRequest.concat(deliveryInProgress) : onTheWayWithReRequest) : deliveryInProgress ? deliveryInProgress : [];
        let runningLate = this.state.runningLate;
        const filterRunningLate = driveByRequestsByStatus.runninglate ? runningLate.concat(driveByRequestsByStatus.runninglate) : (runningLate || []);
        let newOnTheWayRequests = filterOnTheWayForDeliveryInProgress && filterOnTheWayForDeliveryInProgress.filter((data) => {
                if (data.driveByDetails.hereNowDateTime) {
                    allHereNowRequests.push(data);
                } else if (data.driveByDetails.isRunningLate && !data.driveByDetails.hereNowDateTime) {
                    filterRunningLate.push(data);
                } else {
                    return true;
                }
            });
        this.setState({hereNow: allHereNowRequests, onTheWay: newOnTheWayRequests, runningLate: filterRunningLate});
    };

    newRequest = (newDriveByRequest) => {
        try {
            let onTheWayRequests = this.state.onTheWay;
            newDriveByRequest.isNew = true;
            newDriveByRequest.isSoundPlay = true;
            // newDriveByRequest.chatScreenStatus=false;
            let allDDSListenChannelName = this.state.allDDSListenChannelName;
            allDDSListenChannelName.push(newDriveByRequest.channels.ddsListenChannelName);
            this.setState({
                onTheWay: [...onTheWayRequests, newDriveByRequest],
                allDDSListenChannelName: allDDSListenChannelName
            });
            this.pubnub.subscribe({
                channels: [newDriveByRequest.channels.ddsListenChannelName,newDriveByRequest.channels.ddsChatListenChannelName],
                withPresence: true
            });
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component newRequest Pubnub Subscribe Channel' + error);
        }
    };

    updateRequest = (updatedRequest) => {
        let {hereNow, onTheWay, runningLate, recentOrder} = this.state;
        let isOrderUpdated = false;
        let updateReq;
        let status = updatedRequest.driveByDetails && updatedRequest.driveByDetails.status;
        let updatedDataHereNow = hereNow && hereNow.map((data, index) => {
                if (data.order.orderNumber === updatedRequest.order.orderNumber) {
                    isOrderUpdated = true;
                    hereNow[index].driveByDetails.licensePlateNumber = updatedRequest.driveByDetails && updatedRequest.driveByDetails.licensePlateNumber;
                    hereNow[index].driveByDetails.modeOfTransport = updatedRequest.driveByDetails && updatedRequest.driveByDetails.modeOfTransport;
                    hereNow[index].driveByDetails.transportColor = updatedRequest.driveByDetails && updatedRequest.driveByDetails.transportColor;
                    hereNow[index].driveByDetails.notes = updatedRequest.driveByDetails && updatedRequest.driveByDetails.notes;
                    hereNow[index].location = updatedRequest.location;
                    return hereNow[index]
                } else {
                    return hereNow[index];
                }
            });

        let updatedDataOnTheWay = onTheWay && onTheWay.map((data, index) => {
                if (data.order.orderNumber === updatedRequest.order.orderNumber) {
                    isOrderUpdated = true;
                    onTheWay[index].driveByDetails.licensePlateNumber = updatedRequest.driveByDetails && updatedRequest.driveByDetails.licensePlateNumber;
                    onTheWay[index].driveByDetails.modeOfTransport = updatedRequest.driveByDetails && updatedRequest.driveByDetails.modeOfTransport;
                    onTheWay[index].driveByDetails.transportColor = updatedRequest.driveByDetails && updatedRequest.driveByDetails.transportColor;
                    onTheWay[index].driveByDetails.notes = updatedRequest.driveByDetails && updatedRequest.driveByDetails.notes;
                    onTheWay[index].location = updatedRequest.location;
                    return onTheWay[index]
                } else {
                    return onTheWay[index];
                }
            });

        let updatedDataRunningLate = runningLate && runningLate.map((data, index) => {
                if (data.order.orderNumber === updatedRequest.order.orderNumber) {
                    isOrderUpdated = true;
                    runningLate[index].driveByDetails.licensePlateNumber = updatedRequest.driveByDetails && updatedRequest.driveByDetails.licensePlateNumber;
                    runningLate[index].driveByDetails.modeOfTransport = updatedRequest.driveByDetails && updatedRequest.driveByDetails.modeOfTransport;
                    runningLate[index].driveByDetails.transportColor = updatedRequest.driveByDetails && updatedRequest.driveByDetails.transportColor;
                    runningLate[index].driveByDetails.notes = updatedRequest.driveByDetails && updatedRequest.driveByDetails.notes
                    runningLate[index].location = updatedRequest.location;
                    return runningLate[index]
                } else {
                    return runningLate[index];
                }
            });
        let indexToRemove = -1;
        if (!isOrderUpdated) {
            updateReq = recentOrder && recentOrder.filter((data, index) => {
                    if (data.order.orderNumber === updatedRequest.order.orderNumber) {
                        indexToRemove = index;
                        return data;
                    }
                });
            if (indexToRemove !== -1) {
                recentOrder.splice(indexToRemove, 1);
            }
        }
        if (updateReq && status) {
            let newRecord = updateReq[0];
            if (status.toLowerCase() === "ReRequested".toLowerCase() && newRecord) {
                newRecord.driveByDetails.licensePlateNumber = updatedRequest.driveByDetails && updatedRequest.driveByDetails.licensePlateNumber;
                newRecord.driveByDetails.modeOfTransport = updatedRequest.driveByDetails && updatedRequest.driveByDetails.modeOfTransport;
                newRecord.driveByDetails.transportColor = updatedRequest.driveByDetails && updatedRequest.driveByDetails.transportColor;
                newRecord.driveByDetails.notes = updatedRequest.driveByDetails && updatedRequest.driveByDetails.notes
                newRecord.driveByDetails.status = "ReRequested";
                newRecord.location = updatedRequest.location;
                newRecord.channels && this.pubnub.subscribe({
                    channels: [newRecord.channels.ddsListenChannelName],
                    withPresence: true
                });
                if (newRecord.driveByDetails.hereNowDateTime) {
                    updatedDataHereNow.push(newRecord);
                } else if (newRecord.driveByDetails.isRunningLate) {
                    updatedDataRunningLate.push(newRecord);
                } else {
                    updatedDataOnTheWay.push(newRecord);
                }
            }
        }
        this.setState({
            hereNow: updatedDataHereNow,
            runningLate: updatedDataRunningLate,
            onTheWay: updatedDataOnTheWay,
            recentOrder: recentOrder
        });
    };

    updateUserAvatar = (request) => {
        let {hereNow, onTheWay, runningLate} = this.state;
        let updatedDataHereNow = hereNow && hereNow.map((data, index) => {
                if (data.order.orderNumber === request.message.data.order.orderNumber) {
                    hereNow[index].driveByDetails.userAvatar = request.message.data.driveByDetails.userAvatar;
                    return hereNow[index];
                } else {
                    return hereNow[index];
                }
            });

        let updatedDataOnTheWay = onTheWay && onTheWay.map((data, index) => {
                if (data.order.orderNumber === request.message.data.order.orderNumber) {
                    onTheWay[index].driveByDetails.userAvatar = request.message.data.driveByDetails.userAvatar;
                    return onTheWay[index]
                } else {
                    return onTheWay[index];
                }
            });

        let updatedDataRunningLate = runningLate && runningLate.map((data, index) => {
                if (data.order.orderNumber === request.message.data.order.orderNumber) {
                    runningLate[index].driveByDetails.userAvatar = request.message.data.driveByDetails.userAvatar;
                    return runningLate[index]
                } else {
                    return runningLate[index];
                }
            });

        this.setState({
            hereNow: updatedDataHereNow,
            runningLate: updatedDataRunningLate,
            onTheWay: updatedDataOnTheWay
        });
    };

    convertSecsToHrsMinsSecs = (totalSeconds) => {
        let hours = Math.floor(totalSeconds / 3600);
        totalSeconds %= 3600;
        let minutes = Math.floor(totalSeconds / 60);
        let seconds = Math.floor(totalSeconds % 60);

        hours = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;

        return hours + ':' + minutes + ':' + seconds;
    };

    orderCompleteCancel = (request, status) => {
        let {hereNow, onTheWay, runningLate, recentOrder} = this.state;
        const orderNumber = request.message.data.order.orderNumber;
        let updatedDataHereNow = hereNow && hereNow.filter((data, index) => {
                if (data.order.orderNumber !== orderNumber) {
                    return true
                } else {
                    data.driveByDetails.status = status;
                    data.driveByDetails.actionDateTime = request.message.data.actionDateTime;
                    data.channels && this.pubnub.unsubscribe({channels: [data.channels.ddsListenChannelName,data.channels.ddsChatListenChannelName]});
                    recentOrder.push(data);
                }
            });

        let updatedDataOnTheWay = onTheWay && onTheWay.filter((data, index) => {
                if (data.order.orderNumber !== orderNumber) {
                    return true
                } else {
                    data.driveByDetails.status = status;
                    data.driveByDetails.actionDateTime = request.message.data.actionDateTime;
                    data.channels && this.pubnub.unsubscribe({channels: [data.channels.ddsListenChannelName,data.channels.ddsChatListenChannelName]});
                    recentOrder.push(data);
                }
            });

        let updatedDataRunningLate = runningLate && runningLate.filter((data, index) => {
                if (data.order.orderNumber !== orderNumber) {
                    return true
                } else {
                    data.driveByDetails.status = status;
                    data.driveByDetails.actionDateTime = request.message.data.actionDateTime;
                    data.channels && this.pubnub.unsubscribe({channels: [data.channels.ddsListenChannelName,data.channels.ddsChatListenChannelName]});
                    recentOrder.push(data);
                }
            });

        this.setState({
            hereNow: updatedDataHereNow,
            runningLate: updatedDataRunningLate,
            onTheWay: updatedDataOnTheWay,
            recentOrder: recentOrder
        });
    };

    addCancelledReason = (requestData) => {
        let {hereNow, onTheWay, runningLate, recentOrder} = this.state;
        const orderNumber = requestData.message.data.order.orderNumber;
        let newOnTheWay = onTheWay && onTheWay.map((request) => {
                if (orderNumber === request.order.orderNumber) {
                    request.driveByDetails.cancelledReason = requestData.message.data.reason;
                    return request
                } else {
                    return request
                }
            });

        let newRunningLate = runningLate && runningLate.map((request) => {
                if (orderNumber === request.order.orderNumber) {
                    request.driveByDetails.cancelledReason = requestData.message.data.reason;
                    return request
                } else {
                    return request
                }
            });

        let newHereNow = hereNow && hereNow.map((request) => {
                if (orderNumber === request.order.orderNumber) {
                    request.driveByDetails.cancelledReason = requestData.message.data.reason;
                    return request
                } else {
                    return request
                }
            });

        let newRecentOrder = recentOrder && recentOrder.map((request) => {
                if (orderNumber === request.order.orderNumber) {
                    request.driveByDetails.cancelledReason = requestData.message.data.reason;
                    return request
                } else {
                    return request
                }
            });
        this.setState({
            onTheWay: newOnTheWay,
            hereNow: newHereNow,
            runningLate: newRunningLate,
            recentOrder: newRecentOrder
        });
    };

    updateAverageWaitTime = (msg) => {
        let {avgWaitTime} = this.state;
        avgWaitTime.totalSeconds = avgWaitTime.totalSeconds + msg.message.data.diffInSeconds;
        avgWaitTime.totalRequests = avgWaitTime.totalRequests + 1;
        avgWaitTime.calculatedTime = this.convertSecsToHrsMinsSecs(avgWaitTime.totalSeconds / avgWaitTime.totalRequests);
        this.setState({avgWaitTime});
    };

    setMessage = (msg) => {
        const {hereNow, onTheWay, runningLate} = this.state;
        let updatedDataHereNow = hereNow && hereNow.map((data, index) => {
                if (data.channels.ddsListenChannelName === msg.channel) {
                    hereNow[index].chatDetails = hereNow[index].chatDetails ? [...hereNow[index].chatDetails, msg.message.data.chatDetail] : [msg.message.data.chatDetail];
                    return hereNow[index];
                } else {
                    return hereNow[index];
                }
            });

        let updatedDataOnTheWay = onTheWay && onTheWay.map((data, index) => {
                if (data.channels.ddsListenChannelName === msg.channel) {
                    onTheWay[index].chatDetails = onTheWay[index].chatDetails ? [...onTheWay[index].chatDetails, msg.message.data.chatDetail] : [msg.message.data.chatDetail];
                    return onTheWay[index]
                } else {
                    return onTheWay[index];
                }
            });

        let updatedDataRunningLate = runningLate && runningLate.map((data, index) => {
                if (data.channels.ddsListenChannelName === msg.channel) {
                    runningLate[index].chatDetails = runningLate[index].chatDetails ? [...runningLate[index].chatDetails, msg.message.data.chatDetail] : [msg.message.data.chatDetail];
                    return runningLate[index]
                } else {
                    return runningLate[index];
                }
            });

        this.setState({
            hereNow: updatedDataHereNow,
            runningLate: updatedDataRunningLate,
            onTheWay: updatedDataOnTheWay
        });
    };

    addMessage = (msg) => {
        const {hereNow, onTheWay, runningLate} = this.state;
        let updatedDataHereNow = hereNow && hereNow.map((data, index) => {
                if (data.channels.ddsListenChannelName === msg.channel) {
                    hereNow[index].chatDetails = hereNow[index].chatDetails ? [...hereNow[index].chatDetails, msg.data.chatDetail] : [msg.data.chatDetail];
                    return hereNow[index];
                } else {
                    return hereNow[index];
                }
            });

        let updatedDataOnTheWay = onTheWay && onTheWay.map((data, index) => {
                if (data.channels.ddsListenChannelName === msg.channel) {
                    onTheWay[index].chatDetails = onTheWay[index].chatDetails ? [...onTheWay[index].chatDetails, msg.data.chatDetail] : [msg.data.chatDetail];
                    return onTheWay[index]
                } else {
                    return onTheWay[index];
                }
            });

        let updatedDataRunningLate = runningLate && runningLate.map((data, index) => {
                if (data.channels.ddsListenChannelName === msg.channel) {
                    runningLate[index].chatDetails = runningLate[index].chatDetails ? [...runningLate[index].chatDetails, msg.data.chatDetail] : [msg.data.chatDetail];
                    return runningLate[index]
                } else {
                    return runningLate[index];
                }
            });

        this.setState({
            hereNow: updatedDataHereNow,
            runningLate: updatedDataRunningLate,
            onTheWay: updatedDataOnTheWay
        });
    };

    handleConfirmSendMessage = (msg) => {
        const {hereNow, onTheWay, runningLate} = this.state;
        let newMsg = {
            data: msg.message.message.data,
            dateTime: msg.message.message.sendDateTime,
            message_type: msg.message.message.type,
            status: msg.message.message.status,
            userId: msg.message.message.userId
        };
        let newHereNow = hereNow && hereNow.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;
                } else return data
            });
        let newOnTheWay = onTheWay && onTheWay.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;
                } else return data
            });
        let newRunningLate = runningLate && runningLate.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;
                } else return data
            });
        this.setState({onTheWay: newOnTheWay, hereNow: newHereNow, runningLate: newRunningLate});
    };

    handleSendMessage = (msg, orderNumber, customerId, channelName) => {
        let message = {
            messageType: "chatMessage",
            message: {
                type: "TEXT",
                data: msg
            },
            data: {
                order: {
                    customerId: customerId,
                    orderNumber: orderNumber,
                    userId: this.props.userProfile.userId
                },
                sender: "DDS"
            }
        };
        this.pubnub.publish({message: message, channel: channelName});
    };

    logoutFromAll = () => {
        try {
            this.props.actions.authAction.loggedOut()
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component logoutFromAll' + error);
        }
    };

    handleLogout = () => {
        const message = {
            messageType: "logout"
        };
        this.pubnub.publish({message: message, channel: this.state.controlChannelName});
        this.props.actions.authAction.loggedOut();
    };

    addRating = (msg) => {
        let {recentOrder} = this.state;
        let newRecentOrder = recentOrder && recentOrder.map((data) => {
                if (data.order.orderNumber === msg.message.data.order.orderNumber) {
                    data.driveByDetails.ratingValue = msg.message.data.rating.value;
                    return data;
                } else return data;
            });
        this.setState({recentOrder: newRecentOrder});
    };

    handleRecentOpen = () => {
        this.setState({isResetOpen: !this.state.isResetOpen});
    };

    getChatMessage = (msg) => {
        const {hereNow, onTheWay, runningLate} = this.state;
        let newMsg = {
            data: msg.message.message.data,
            dateTime: msg.message.message.sendDateTime,
            message_type: msg.message.message.type,
            status: msg.message.message.status,
            userId: null,
            id:msg.message.message.id
        };
        let newHereNow = hereNow && hereNow.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;
                } else return data
            });
        let newOnTheWay = onTheWay && onTheWay.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;
                } else return data
            });
        let newRunningLate = runningLate && runningLate.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;
                } else return data
            });
        this.setState({onTheWay: newOnTheWay, hereNow: newHereNow, runningLate: newRunningLate});
    };

    handleReadStatusOpenChat = (messageId,channelName) =>{
        let SeenSingleMessage = {

            messageType: "MessageStatusUpdate",
            data:{
                message:{
                    messageId:messageId
                }
            }
        };
        this.pubnub.publish({message: SeenSingleMessage, channel: channelName});
    };

    handleReadMessage = (orderNumber,channelName,messageType) => {
        let {hereNow, onTheWay, runningLate} = this.state;
        let readStatus = false;
        hereNow.forEach((data)=>{
            data.messageDetails.forEach((msg)=>{
                if(!msg.status && !msg.userId){
                    readStatus = true;
                }
            });
        });
        onTheWay.forEach((data)=>{
            data.messageDetails.forEach((msg)=>{
                if(!msg.status && !msg.userId){
                    readStatus = true;
                }
            });
        });
        runningLate.forEach((data)=>{
            data.messageDetails.forEach((msg)=>{
                if(!msg.status && !msg.userId){
                    readStatus = true;
                }
            });
        });
        if(readStatus){
            let msg = {
                messageType: messageType,
                data:{
                    order:{
                        orderNumber:orderNumber
                    }
                }
            };
            this.pubnub.publish({message: msg, channel: channelName});
        }
    };

    seenMessagesConfirm = (msg) => {
        const {hereNow, onTheWay, runningLate} = this.state;
        let newHereNow = hereNow && hereNow.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let newMessageDetailsHereNow = data.messageDetails && data.messageDetails.map((message,index)=>{
                        let diff = getDateGMT(message.dateTime,this.state.timeZone).diff(getDateGMT(msg.message.data.order.dateTime,this.state.timeZone));
                        if(diff <= 0){
                            message.status= true;
                            return message
                        }else return message
                    });
                    data.messageDetails = newMessageDetailsHereNow;
                    return data;
                } else return data
            });
        let newOnTheWay = onTheWay && onTheWay.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let newMessageDetailsOnTheWay = data.messageDetails && data.messageDetails.map((message,index)=>{
                        let diff = getDateGMT(message.dateTime,this.state.timeZone).diff(getDateGMT(msg.message.data.order.dateTime,this.state.timeZone));
                        if(diff <= 0){
                            message.status= true;
                            return message
                        }else return message
                    });
                    data.messageDetails = newMessageDetailsOnTheWay;
                    return data;
                } else return data
            });
        let newRunningLate = runningLate && runningLate.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let newMessageDetailsRunningLate = data.messageDetails && data.messageDetails.map((message,index)=>{
                        let diff = getDateGMT(message.dateTime,this.state.timeZone).diff(getDateGMT(msg.message.data.order.dateTime,this.state.timeZone));
                        if(diff <= 0){
                            message.status= true;
                            return message
                        }else return message
                    });
                    data.messageDetails = newMessageDetailsRunningLate;
                    return data;
                } else return data
            });
        this.setState({onTheWay: newOnTheWay, hereNow: newHereNow, runningLate: newRunningLate});
    };

    handleConfirmSendMessageOpenScreen = (msg) => {
        const {hereNow, onTheWay, runningLate} = this.state;
        let newHereNow = hereNow && hereNow.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let getData = data.messageDetails && data.messageDetails.find((order) => order.id === msg.message.data.message.id);
                    const index = data.messageDetails && data.messageDetails.indexOf(getData);
                    if(index>=0){
                        data.messageDetails[index].status=msg.message.data.message.status;
                    }
                    return data;
                } else return data
            });
        let newOnTheWay = onTheWay && onTheWay.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let getData = data.messageDetails && data.messageDetails.find((order) => order.id === msg.message.data.message.id);
                    const index = data.messageDetails && data.messageDetails.indexOf(getData);
                    if(index>=0){
                        data.messageDetails[index].status=msg.message.data.message.status;
                    }
                    return data;
                } else return data
            });
        let newRunningLate = runningLate && runningLate.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let getData = data.messageDetails && data.messageDetails.find((order) => order.id === msg.message.data.message.id);
                    const index = data.messageDetails && data.messageDetails.indexOf(getData);
                    if(index>=0){
                        data.messageDetails[index].status=msg.message.data.message.status;
                    }
                    return data;
                } else return data
            });
        this.setState({onTheWay: newOnTheWay, hereNow: newHereNow, runningLate: newRunningLate});
    };

    componentWillReceiveProps(nextProps) {
        try {
            this.setState({loading: nextProps.loading});
            if (nextProps.startupData.networkError) {
                this.setState({isNetworkError: true});
            } else {
                if (this.state.isFirst && this.props.startLoadDDSData && !nextProps.startLoadDDSData) {
                    let allChannel = [];
                    const channelName = nextProps.startupData.DDSStartupData.controlChannelName;
                    allChannel.push(channelName);
                    this.setState({
                        loading: false,
                        startupData: nextProps.startupData.DDSStartupData,
                        controlChannelName: channelName,
                        avgWaitTime: nextProps.startupData.DDSStartupData.avgWaitTime
                    });
                    let startupData = nextProps.startupData.DDSStartupData.driveByRequests;
                    startupData && startupData.map((driveby) => {
                        allChannel.push(driveby.channels.ddsListenChannelName);
                        allChannel.push(driveby.channels.ddsChatListenChannelName)
                    });
                    this.pubnub.subscribe({channels: allChannel, withPresence: true});
                    this.props.actions.startupAction.allRecentOrders(this.state.storeName);
                    if (this.state.isFirst) {
                        this.timeoutId = setTimeout(this.setDriveByData, 5000);
                        this.setState({
                            allDDSListenChannelName: allChannel,
                            onTheWay: startupData,
                            isFirst: false
                        });
                    }
                }
                if (this.state.isFirstRecent && nextProps.loadRecentOrder === false && this.props.loadRecentOrder) {
                    this.setState({isFirstRecent: false, recentOrder: nextProps.startupData.recentOrders});
                }
            }
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component componentWillReceiveProps' + error);
        }
    }

    componentWillUnmount() {
        try {
            clearTimeout(this.timeoutId);
            this.pubnub.unsubscribe({channels: this.state.allDDSListenChannelName});
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component componentWillUnmount' + error);
        }
    }

    render() {
        if (this.state.isNetworkError) {
            return (<div>
                please try again!
            </div>)
        }
        return (
            <div className="drive-by myClass">
                <NotificationSystem ref="notificationSystem"/>
                <section className={this.state.isResetOpen ? "drive-widget recent-runner" : "drive-widget"}>
                    <div className="drive-details">
                        <Header
                            avgWaitTime={(this.state.avgWaitTime && this.state.avgWaitTime.calculatedTime) || '00:00'}
                            notify={this.addNotification} handleChangeStore={this.initializeDDS}
                            handleRecent={this.handleRecentOpen}/>
                        <HereNow driveByRequests={this.state.hereNow} moveRunningLate={this.moveRunningLate}
                                 updateStatus={this.updateStatus}
                                 handleCustomerNotificationStatus={this.handleCustomerNotificationStatus}
                                 handleCustomerNotificationStatusForComeIn={this.handleCustomerNotificationStatusForComeIn}
                                 handleSendMessage={this.handleSendMessage} timeZone={this.state.timeZone}
                                 storeInfo={this.state.storeInformation} storeName={this.state.storeName}
                                 handleReadMessage={this.handleReadMessage}
                                 handleReadStatusOpenChat={this.handleReadStatusOpenChat}/>
                        <OnTheWay driveByRequests={this.state.onTheWay} moveRunningLate={this.moveRunningLate}
                                  isFirst={this.state.isFirst}
                                  updateStatus={this.updateStatus}
                                  handleCustomerNotificationStatus={this.handleCustomerNotificationStatus}
                                  handleCustomerNotificationStatusForComeIn={this.handleCustomerNotificationStatusForComeIn}
                                  handleSendMessage={this.handleSendMessage} timeZone={this.state.timeZone}
                                  storeInfo={this.state.storeInformation} storeName={this.state.storeName}
                                  handleReadMessage={this.handleReadMessage}
                                  handleReadStatusOpenChat={this.handleReadStatusOpenChat}/>
                        <RunningLate driveByRequests={this.state.runningLate} updateStatus={this.updateStatus}
                                     handleCustomerNotificationStatus={this.handleCustomerNotificationStatus}
                                     handleCustomerNotificationStatusForComeIn={this.handleCustomerNotificationStatusForComeIn}
                                     handleSendMessage={this.handleSendMessage} timeZone={this.state.timeZone}
                                     storeInfo={this.state.storeInformation} storeName={this.state.storeName}
                                     handleReadMessage={this.handleReadMessage}
                                     handleReadStatusOpenChat={this.handleReadStatusOpenChat}/>
                    </div>
                    <RecentOrder recentOrderData={this.state.recentOrder}
                                 isLoading={this.props.startupData.loadRecentOrder} timeZone={this.state.timeZone}
                                 storeInfo={this.state.storeInformation} storeName={this.state.storeName}
                                 isResetOpen={this.state.isResetOpen}/>
                </section>
                {this.state.loading && <Loader/>}
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    const {ddsStartupReducer, authReducer} = state;
    return {
        startupData: ddsStartupReducer,
        loadRecentOrder: ddsStartupReducer.loadRecentOrder,
        loading: ddsStartupReducer.loading,
        startLoadDDSData: ddsStartupReducer.startLoadDDSData,
        userProfile: authReducer.userProfile
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        startupAction: bindActionCreators(DDSStartupAction, dispatch),
        authAction: bindActionCreators(authAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Home);