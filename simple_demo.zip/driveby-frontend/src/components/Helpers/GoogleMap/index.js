import React from "react"
import {orderBy} from "lodash";
import {compose, withProps,lifecycle,withState,withStateHandlers} from "recompose";
import {withScriptjs, withGoogleMap, GoogleMap, Marker,DirectionsRenderer,InfoWindow} from "react-google-maps/lib"

import { GyGLog } from '../../../Logging/GyGLog';
const MyMapComponent = compose(
    withProps({
        googleMapURL: "https://maps.googleapis.com/maps/api/js?key=AIzaSyB3V6CpjLhGK72bqFoIw7nwoZpL7299U7g&libraries=geometry,drawing,places",
        loadingElement: <div style={{height: `100%`}}/>,
        containerElement: <div style={{height: `100%`}}/>,
        mapElement: <div style={{height: `100%`}}/>
    }),
    withScriptjs,
    withGoogleMap,
    withStateHandlers(()=>({
        isOpen:false,
    }),{
        onToggleOpen: ({isOpen}) => () => ({
            isOpen:!isOpen
        })
    }),
    withState('isFirst','setIsFirst',true),
    withState('allLocationWayPoint','setAllLocation',[]),
    withState('bounds','setBounds',""),
    lifecycle({
        componentDidMount() {
            try{
                let google = window.google;
                let DirectionsService = new google.maps.DirectionsService();
                let allLocation = [...this.props.allLocationCoordinates];
                let allLocationMarker = [...this.props.allLocationCoordinates];
                let allParts = [];
                let bounds = new window.google.maps.LatLngBounds();
                if(bounds){
                    bounds.extend(new window.google.maps.LatLng(this.props.storeLatLng.latitude,this.props.storeLatLng.longitude));
                    allLocation.forEach((data,index)=>{
                        bounds.extend(new window.google.maps.LatLng(data.location.lat, data.location.lng));
                    });
                }
                this.props.setBounds(bounds);
                if(this.props.column==="here now" || this.props.completed){
                    allLocationMarker.pop();
                    this.props.setAllLocation([...allLocationMarker]);
                }
                else{
                    this.props.setAllLocation([...allLocationMarker]);
                }
                let directions = [];
                if(allLocation.length > 0){
                    if(allLocation.length > 23) {
                        let lastElem = [];
                        while(allLocation.length > 23){
                            let parts = allLocation.splice(0, 23);
                            if(lastElem.length){
                                parts.unshift(lastElem[lastElem.length-1])
                                parts.pop();
                            }
                            let origin,destination;
                            if(parts.length >= 2){
                                origin = parts[0].location;
                                destination = parts[parts.length - 1].location
                            }else if(parts.length === 1) {
                                origin = parts[0].location;
                                destination = parts[0].location;
                            }
                            allParts.push({origin:origin,destination:destination,wayPoints:parts});
                            lastElem = parts;
                            if (allLocation.length > 0 && allLocation.length <= 23 ) {
                                allLocation.unshift(parts[parts.length-1]);
                                let origin,destination;
                                if(allLocation.length >= 2){
                                    origin = allLocation[0].location;
                                    destination = allLocation[allLocation.length - 1].location
                                }else if(allLocation.length === 1) {
                                    origin = allLocation[0].location;
                                    destination = allLocation[0].location;
                                }
                                allParts.push({origin:origin,destination:destination,wayPoints:allLocation});
                            }
                        }
                        allParts.forEach((data,index)=>{
                            DirectionsService.route({
                                origin: data.origin,
                                destination:data.destination,
                                waypoints: data.wayPoints,
                                travelMode: google.maps.TravelMode.DRIVING,
                            }, (result, status) => {
                                if (status === google.maps.DirectionsStatus.OK) {
                                    directions.push(result);
                                    this.setState({
                                        directions: directions,
                                    });
                                }
                            });
                        })
                    }else{
                        var origin,destination;
                        if(allLocation.length >= 2){
                            origin = allLocation[0].location;
                            destination = allLocation[allLocation.length - 1].location
                        }else if(allLocation.length === 1) {
                            origin = allLocation[0].location;
                            destination = allLocation[0].location;
                        }
                        DirectionsService.route({
                            origin: origin,
                            destination:destination,
                            waypoints: allLocation,
                            travelMode: google.maps.TravelMode.DRIVING,
                        }, (result, status) => {
                            if (status === google.maps.DirectionsStatus.OK) {
                                directions.push(result);
                                this.setState({
                                    directions: directions,
                                });
                            }
                        });
                    }
                }
            }catch(error){
                GyGLog("debug","DDS Log GoogleMap"+error)
            }
        }
    })
)((props) =>
    <GoogleMap
        ref={(map) => {props.bounds && map && map.fitBounds(props.bounds) }}
        defaultCenter={{lat: parseFloat(props.storeLatLng.latitude), lng: parseFloat(props.storeLatLng.longitude)}}
    >
        {props.directions && props.directions.length && props.directions.map((data,index)=>(
            <DirectionsRenderer directions={data} key={index} options={{suppressMarkers:true}}/>
        ))}
        {props.isMarkerShown && props.allLocationWayPoint && props.allLocationWayPoint.length && props.allLocationWayPoint.map((data,index)=>(
            <Marker position={{lat: parseFloat(data.location.lat), lng: parseFloat(data.location.lng)}} key={index} options={{label:(index+1).toString(),title:"Location "+(index+1)}}/>
        ))}
        {props.isMarkerShown &&  <Marker onClick={props.onToggleOpen} position={{lat: parseFloat(props.storeLatLng.latitude), lng: parseFloat(props.storeLatLng.longitude)}} options={{icon:'/assets/Images/store-icon-map.png'}}>
            {props.isOpen && <InfoWindow onCloseClick={props.onToggleOpen}>
                <div>
                    <div>Store Name : {props.storeName}</div>
                    <div>Latitude : {props.storeLatLng.latitude}</div>
                    <div>Longitude : {props.storeLatLng.longitude}</div>
                </div>
            </InfoWindow>}
        </Marker>}
    </GoogleMap>
);

export default class GoogleMapComponent extends React.PureComponent {
    constructor(props){
        super(props);
        this.state={
            isMarkerShown:false,
            keyValue:Date.now().toString()
        }
    }

    delayShowMarker = () => {
        this.timeOutId = setTimeout(()=>{
            this.setState({isMarkerShown:true});
        },1000);
    };

    componentDidMount(){
        this.delayShowMarker()
    }

    componentWillReceiveProps(nextProps){
        if(nextProps.allLocation.length > this.props.allLocation.length ){
            this.setState({keyValue:Date.now().toString()});
        }
    }

    componentWillUnmount(){
        clearTimeout(this.timeOutId);
    }

    render() {
        let {allLocation = [], storeInformation} = this.props;
        let orderedLocation = orderBy(allLocation, ['sequence'], ['asc']);
        let allLocationCoordinates = orderedLocation && orderedLocation.length && orderedLocation.map((location,index) => ({
                location: {
                    lat: parseFloat(location.latitude),
                    lng: parseFloat(location.longitude)
                },
                stopover: true
        }));
        if(this.props.column === "here now" || this.props.completed){
            let addLocationCoordinate = {
                location: {
                    lat:parseFloat(storeInformation.latitude),
                    lng:parseFloat(storeInformation.longitude)
                    },
                    stopover:true
                };
            allLocationCoordinates && allLocationCoordinates.push(addLocationCoordinate)
        }
        return (
            <MyMapComponent
                key={this.state.keyValue}
                storeLatLng={storeInformation}
                allLocationCoordinates={allLocationCoordinates}
                column={this.props.column}
                storeName={this.props.storeName}
                isMarkerShown={this.state.isMarkerShown}
            />
        )
    }
}