import React, {Component} from 'react';
import {orderBy} from "lodash";
import { Twemoji } from 'react-emoji-render';

import {getDateGMT} from '../../Home/waitingTime';
import './MessageGuest.css';

export default class MessageGuest extends Component {

    constructor(props){
        super(props);
        this.state={
            chatMessage:""
        }
    }

    handleSubmit = (e) => {
        e.preventDefault();
        if(this.state.chatMessage.trim().length > 0){
            this.props.handleSendMessage(this.state.chatMessage.trim());
        }
        return this.setState({chatMessage:""});
    };

    handleChange = (e) => {
        return this.setState({chatMessage:e.target.value});
    };

    handleScrollToBottom = () => {
        let elem = this.refs.chatBox;
        elem.scrollTop= elem.scrollHeight;
    };

    render(){
        const {chatDetails} = this.props;
        const sortedChatDetails = orderBy(chatDetails, ['messageTime'], ['asc']);
        return(
            <div className="message-guest">
                <div className="chating-box" ref="chatBox">
                    <div className="chat-date-time">
                        <h6>Chat</h6>
                        <h6>{getDateGMT(Date.now(),this.props.timeZone).format("HH:mm:ss A")}</h6>
                    </div>
                    {chatDetails.length>0 && chatDetails.map((value, index) => (
                        <div key={index}>
                            {!value.userId ? <div>
                                <div className="chat-reply">
                                    <Twemoji text={value.data}/>
                                </div>
                                <h6 className="msg-time">{getDateGMT(value.dateTime,this.props.timeZone).format("HH:mm:ss A")}</h6>
                            </div> : <div>
                                <div className="chat-send-msg">
                                    <Twemoji text={value.data}/>
                                </div>
                                <h6 className="msg-time">{getDateGMT(value.dateTime,this.props.timeZone).format("HH:mm:ss A")}</h6>
                            </div>
                            }
                        </div>
                    ))}
                </div>
                <div className="msg-type">
                    <div className="input-group">
                        <form onSubmit={this.handleSubmit}>
                        <input type="text" className="form-control" placeholder="Type your chat here" value={this.state.chatMessage} onChange={this.handleChange} style={{width:'100%'}} maxLength={600}/>
                            <a onClick={this.handleSubmit}><img src="/assets/Images/send-arrow.png"/></a>
                        </form>
                    </div>
                </div>
            </div>
        )
    }

    componentDidMount(){
        this.handleScrollToBottom();
    }

    componentDidUpdate(){
        this.handleScrollToBottom()

    }
}

