/*global chrome*/
import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Dialog} from 'material-ui';
import moment from 'moment';
import {orderBy} from "lodash";
import Loader from 'react-loader';
import Rating from 'react-rating';

import GoogleMapComponent from '../GoogleMap';
import MessageGuest from '../MessageGuest';
import * as DDSStartupAction from '../../../actions/DDSStartupAction';
import CarIcons from '../DriveThroughIcons/CarIcons';
import MotorcycleIcon from '../DriveThroughIcons/MotorcycleIcon';
import FootIcon from '../DriveThroughIcons/FootIcon';
import BicycleIcon from '../DriveThroughIcons/BicycleIcon';
import BurroIcon from '../DriveThroughIcons/BurroIcon';
import {getDateGMT} from '../../Home/waitingTime';

import './TicketInformationDialog.css';

const style = {
    titleStyle: {
        paddingLeft: 15,
        paddingRight: '15px',
        borderBottom: '1px solid #F5F5F5'
    },
    actionsContainerStyle: {
        textAlign: 'right',
        padding: '5 5'
    },
    leftCloseButton: {
        borderRadius: '50%',
        boxShadow: '0px 2px 9px -2px #000',
        float: 'right',
        backgroundColor: '#fff',
        width: 43,
        height: 43,
        fontSize: 25,
        fontFamily: 'FontAwesome',
        color: '#c53140',
        marginTop: '-6px',
        padding: "9px 12px"
    }
};

class TicketInformationDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orderDetail: [],
            loading: true,
            // getChatData: false,
            isCustomerNotificationOpen: false,
            isChatOpen: false,
            isExtraNotesOpen: false,
            isConfirmationOpen: false,
            takePhotoConfirm: false,
            reasonForCancel: "Please pick up your order at the counter",
            currentOrderChatDetail:[],
            isAlreadyOpen:false
        }
    }

    componentWillMount() {
        this.props.actions.startupAction.getOrderDetails(this.props.ticketInformation.order.orderNumber);
    };

    componentWillReceiveProps(nextProps) {
        nextProps.orderDetail.currentOrderDetail && this.setState({
            orderDetail: nextProps.orderDetail.currentOrderDetail,
            loading: false
        });
        nextProps.orderDetail.orderNotFound && this.setState({loading: false});
    };

    handleClose = () => {
        this.props.actions.startupAction.initialOrderDetail();
        this.props.handleClose();
    };

    showCustomerNotification = () => {
        this.setState({isCustomerNotificationOpen: true});
    };

    hideCustomerNotification = () => {
        this.setState({isCustomerNotificationOpen: false});
    };

    handleChat = () => {
        let _this = this;
        this.setState({isChatOpen: !this.state.isChatOpen},()=>{
            if(this.state.isChatOpen){
                _this.props.handleReadStatus("SeenMessages");
            }
        });
    };

    showExtraNotes = () => {
        this.setState({isExtraNotesOpen: true});
    };

    handleCloseExtraNote = () => {
        this.setState({isExtraNotesOpen: false});
    };

    handleComeIn = () => {
        this.setState({isConfirmationOpen: true});
    };

    confirmComeIn = () => {
        this.props.handleCustomerActionForComeIn('ComeIn', this.state.reasonForCancel)
    };

    handleTakePhoto = () => {
        if (this.props.ticketInformation.driveByDetails.userAvatar) {
            this.setState({takePhotoConfirm: true});
        } else {
            this.handleConfirmTakePhoto();
        }
    };

    handleCloseTakePhoto = () => {
        this.setState({takePhotoConfirm: false});
    };

    handleConfirmTakePhoto = () => {
        this.setState({takePhotoConfirm: false});
        this.props.handleCustomerAction('TakePhoto')
    };

    handleCloseComeInConfirmation = () => {
        this.setState({isConfirmationOpen: false});
    };

    handleReasonValue = (e) => {
        this.setState({reasonForCancel: e.target.value});
    };

    handleSendMessage = (message) => {
        this.props.handleSendMessage(message, this.props.ticketInformation.order.orderNumber, this.props.ticketInformation.order.customerId, this.props.ticketInformation.channels.apiChatListenChannelName);
    };

    handleReadStatusClose = () => {
        return null;
        // if(this.state.isChatOpen){
        //     this.props.handleReadStatus("CloseChatScreen");
        // }
    };

    render() {
        const {column} = this.props;
        const pickupTime = this.props.ticketInformation.order.pickUpTime;
        const orderNo = this.props.ticketInformation.order.orderNumber;
        const modeOfTransport = this.props.ticketInformation.driveByDetails.modeOfTransport.toLowerCase();
        const transportColor = this.props.ticketInformation.driveByDetails.transportColor.toLowerCase() || "#12232d";
        const licensePlateNumber = this.props.ticketInformation.driveByDetails.licensePlateNumber;
        const driveThroughColor = column === "here now" ? this.props.ticketInformation.driveByDetails.tileColor : "#12232d";
        const firstName = this.props.ticketInformation.customer.firstName;
        const lastName = this.props.ticketInformation.customer.lastName;
        const phoneNumber = this.props.ticketInformation.customer.phoneNumber;
        const points = this.state.orderDetail.orderObject && this.state.orderDetail.orderObject.pointsNumber;
        const items = (this.state.orderDetail.itemsObjectArray && this.state.orderDetail.itemsObjectArray) || [];
        const userAvatar = this.props.ticketInformation.driveByDetails.userAvatar;
        const allLocation = this.props.ticketInformation.location;
        const deliveryInProgressDate = this.props.ticketInformation.driveByDetails.deliveryInProgressDateTime;
        const customerNotification = orderBy(this.props.ticketInformation.customerNotification, ['notificationDateTime'], ['desc']);
        const rattingValue = this.props.ticketInformation.driveByDetails.ratingValue;
        const transportMode = {
            bicycle: <BicycleIcon color={transportColor}/>,
            car: <CarIcons color={transportColor}/>,
            motorbike: <MotorcycleIcon color={transportColor}/>,
            onfoot: <FootIcon color={transportColor}/>,
            burro: <BurroIcon color={transportColor}/>,
        };
        const notes = this.props.ticketInformation.driveByDetails.notes;
        const messagesDetails = this.props.ticketInformation.messageDetails;
        let classes = this.props.completed ? ["ticket-modal-right", "modal-scroll", "customer-notification"] : ["ticket-modal-right", "modal-scroll"];
        this.state.isChatOpen && classes.push("ticket-modal-right-scroll-hide", "d-none");
        return (
            <div>
                <Dialog
                    modal={true}
                    open={true}
                    contentClassName="ticket-info-main-content"
                    bodyClassName="ticket-info-body"
                    paperClassName="main-paper"
                    className="ticket-info-main"
                    ref="ticket-information"
                    onRequestClose={this.handleClose}
                >
                    <div className="ticket-info-content desktop-view">
                        <div className="ticket-modal">
                            <span className="close-btn" onClick={this.handleClose}>+</span>
                            <div className="ticket-modal-left ticket-modal-chat">
                                <div className="ticket-left-header" style={{backgroundColor: driveThroughColor}}>
                                    {this.state.isChatOpen ?
                                        <h3><img src="/assets/Images/DB_Logo.png" alt=""/></h3> : rattingValue ?
                                            <div className="app-rating">
                                                <h3 className="order-no"> #{orderNo}</h3>
                                                <Rating className="rating-star" readonly initialRate={rattingValue}
                                                        empty={<i className="fa fa-star" aria-hidden="true"
                                                                  style={{color: "#ded3bd", fontSize: 30}}/>}
                                                        full={<i className="fa fa-star" aria-hidden="true"
                                                                 style={{color: "#ffd204", fontSize: 30}}/>}/>
                                            </div> : <h3 className="text-center">#{orderNo}</h3>}
                                </div>
                                <div
                                    className={this.state.isChatOpen ? "ticket-left-contain chat-left" : this.props.completed ? "ticket-left-contain ticket-left-contain-recent" : "ticket-left-contain"}>
                                    {this.state.isChatOpen ?
                                        <MessageGuest handleSendMessage={this.handleSendMessage}
                                                      chatDetails={messagesDetails} timeZone={this.props.timeZone} /> :
                                        <GoogleMapComponent column={column} allLocation={allLocation}
                                                            storeInformation={this.props.storeInfo}
                                                            storeName={this.props.storeName}
                                                            completed={this.props.completed}/>}
                                    {this.state.isExtraNotesOpen && <div className="modal-left-overlay">
                                        <div className="text-center extra-notes">
                                            <div className="heading">
                                                <h4>
                                                    Customer Notes
                                                </h4>
                                                <i className="fa fa-times close" onClick={this.handleCloseExtraNote}/>
                                            </div>
                                            <div className="text">
                                                {notes}
                                            </div>
                                        </div>
                                    </div>}
                                    {this.state.isConfirmationOpen && <div className="modal-left-overlay">
                                        <div className="text-center extra-notes">
                                            <div className="heading">
                                                <h4>
                                                    Confirm
                                                </h4>
                                                <i className="fa fa-times close"
                                                   onClick={this.handleCloseComeInConfirmation}/>
                                            </div>
                                            <div className="text">
                                                <div className="text-box">
                                                    <p style={{fontSize: 18, fontWeight: 600}}> Are you sure you want to
                                                        cancel DriveBy request for this order?</p>
                                                    <p style={{color: '#c53140', fontWeight: 500}}>Reason for cancel
                                                        DriveBy request</p>
                                                    <textarea value={this.state.reasonForCancel}
                                                              onChange={this.handleReasonValue} rows={3}
                                                              className="reason-text"/>
                                                </div>
                                                <button className="btn btn-warning" style={{
                                                    backgroundColor: '#12232d', borderColor: '#12232d', marginRight: 10,
                                                    width: 60, padding: 10, fontWeight: 600, fontSize: 14
                                                }} onClick={this.confirmComeIn}
                                                        disabled={!this.state.reasonForCancel.length}>Yes
                                                </button>
                                                <button className="btn btn-default"
                                                        style={{width: 60, padding: 10, fontWeight: 600, fontSize: 14}}
                                                        onClick={this.handleCloseComeInConfirmation}>Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>}
                                    {this.state.takePhotoConfirm && <div className="modal-left-overlay">
                                        <div className="text-center extra-notes">
                                            <div className="heading">
                                                <h4>
                                                    Confirm
                                                </h4>
                                                <i className="fa fa-times close" onClick={this.handleCloseTakePhoto}/>
                                            </div>
                                            <div className="text">
                                                <div>
                                                    Are you sure you want to ReRequest for take a photo?
                                                </div>
                                                <button className="btn btn-warning" style={{
                                                    backgroundColor: '#12232d', borderColor: '#12232d', marginRight: 10,
                                                    width: 60, padding: 10, fontWeight: 600, fontSize: 14
                                                }} onClick={this.handleConfirmTakePhoto}>Yes
                                                </button>
                                                <button className="btn btn-default"
                                                        style={{width: 60, padding: 10, fontWeight: 600, fontSize: 14}}
                                                        onClick={this.handleCloseTakePhoto}>Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>}
                                </div>

                                {!this.props.completed && <div
                                    className={column === "here now" ? "ticket-left-footer" : "ticket-left-footer customer-notify"}>
                                    {deliveryInProgressDate ?
                                        <button className="btn-delivered" onClick={this.props.handleChangeStatus}>
                                            Delivered</button>
                                        : <button className="btn-taking" onClick={this.props.handleChangeStatus}>Taking
                                            order out</button>
                                    }
                                    {/*<button className="btn-inverse"*/}
                                    {/*onClick={this.handleChat}>{this.state.isChatOpen ? "HIDE CHAT" : "Message Guest"}</button>*/}
                                    <button className="btn-inverse"
                                            onClick={this.showCustomerNotification}>Message Guest
                                    </button>
                                </div>}
                            </div>
                            {
                                this.state.isCustomerNotificationOpen && <div
                                    className={column !== "here now" ? "modal-right-overlay customer-notification" : "modal-right-overlay"}>
                                    <h3>What do you want the customer to do?</h3>
                                    <ul className="modal-scroll">
                                        {
                                            customerNotification && customerNotification.map((v, index) => (
                                                <li key={index}>
                                                    <h4>{v.name}</h4>
                                                    <h4 style={{color: v.value.toLowerCase() === "waiting" ? '#bb7d28' : (v.value.toLowerCase() === 'rejected' ? '#BF1E2E' : '#73de02')}}>{v.value}<span
                                                        style={{color: '#f7f7f7'}}>{moment(new Date(v.notificationDateTime)).format('HH:mm')}</span>
                                                    </h4>
                                                </li>
                                            ))
                                        }
                                    </ul>
                                    <div
                                        className={this.props.completed ? "overlay-btn-group recent-order-buttons" : "overlay-btn-group"}>
                                        <div>
                                            {column === "here now" &&
                                            <button onClick={() => this.props.handleCustomerAction('ShowOrderNumber')}>
                                                show order number</button>}
                                            {column === "here now" &&
                                            <button onClick={() => this.props.handleCustomerAction('FlashLights')}>Flash
                                                Lights</button>}
                                            {column === "here now" &&
                                            <button onClick={() => this.props.handleCustomerAction('HonkHorn')}>Honk
                                                Horn</button>}
                                            {/*<button*/}
                                            {/*onClick={() => this.props.handleCustomerAction('AdjustMapPosition')}>*/}
                                            {/*Adjust Map Position*/}
                                            {/*</button>*/}

                                            {/*<button onClick={this.handleTakePhoto}>Take a*/}
                                            {/*photo*/}
                                            {/*</button>*/}
                                            {/*<button onClick={() => this.props.handleCustomerAction('MessageGuest')}>*/}
                                            {/*Message*/}
                                            {/*Guest*/}
                                            {/*</button>*/}
                                            <button onClick={this.handleChat}>{this.state.isChatOpen ? "Show Map" : "Message Guest"}</button>
                                            <button onClick={this.handleComeIn}
                                                    style={{color: '#e64a49', borderColor: '#e64a49'}}>Come in
                                            </button>
                                        </div>
                                        <a onClick={this.hideCustomerNotification}
                                           style={{cursor: 'pointer'}} className="back-btn">Back</a>
                                    </div>
                                </div>
                            }
                            <div className={classes.join(" ")}>
                                <h5>Our Guest is</h5>
                                <h3>{firstName} {lastName}</h3>
                                {userAvatar && <img className="img-responsive" src={userAvatar} alt=""/>}
                                <h5>What to look out for</h5>
                                <h3>
                                    <div className="ticket-info-transport-mode">{transportMode[modeOfTransport]}
                                        <span>{modeOfTransport}</span></div>
                                </h3>
                                <h3>{licensePlateNumber}</h3>
                                <h5 className="m-t-15">Phone number</h5>
                                <h3>{phoneNumber}</h3>
                                <h5 className="m-t-15">order details</h5>
                                <h4>Pick up : {pickupTime}</h4>
                                <h4 className="m-b-15">Gomex {points || 0} pts</h4>
                                {
                                    this.state.loading ?
                                        <div><Loader loaded={false}/></div> : items && items.map((value, index) => (
                                            <h4 className="m-t-15" key={index}>{value.Quantity}x {value.Name}</h4>
                                        ))
                                }
                                {this.props.completed && <div>
                                    {customerNotification.length > 0 && <h3>Customer Notifications</h3>}
                                    <ul className="modalScroll">
                                        {
                                            customerNotification && customerNotification.map((v, index) => (
                                                <li key={index}>
                                                    <h4 className="sub-heading">{v.name}</h4>
                                                    <p style={{color: v.value.toLowerCase() === "waiting" ? '#bb7d28' : (v.value.toLowerCase() === 'rejected' ? '#BF1E2E' : '#73de02')}}>{v.value}
                                                        <span
                                                            style={{marginLeft: '2px'}}>{moment(new Date(v.notificationDateTime)).format("HH:mm").toString()}</span>
                                                    </p>
                                                </li>
                                            ))
                                        }
                                    </ul>
                                </div>
                                    // : column === "here now" && <a onClick={this.showCustomerNotification}
                                    //         style={{cursor: 'pointer', textDecoration: 'underline'}}>Customer
                                    // Notification</a>
                                }
                                <br/>
                                {notes && <a onClick={this.showExtraNotes}
                                             style={{cursor: 'pointer', textDecoration: 'underline'}}>Extra Notes</a>}
                                {this.props.completed && this.props.ticketInformation.driveByDetails.cancelledReason &&
                                <div className="order-text">
                                    <h3 style={{color: '#c53140'}}>Reason for cancelled request</h3>
                                    <p>{this.props.ticketInformation.driveByDetails.cancelledReason}</p>
                                </div>}
                            </div>
                        </div>
                    </div>
                    <div className="ticket-info-content mobile-view">
                        <div className="ticket-modal">
                            {!this.state.isChatOpen && <span className="close-btn" onClick={this.handleClose}>+</span>}
                            <div className="ticket-modal-left ticket-modal-chat">
                                <div className="ticket-left-header" style={{backgroundColor: driveThroughColor}}>
                                    {this.state.isChatOpen ?
                                        <div className="msg-heading-wrapper">
                                            <img src="/assets/Images/arrow-left.png" onClick={this.handleChat}
                                                 alt="Back" className="back-icon"/>
                                            <h3 className="text-center"><img src="/assets/Images/DB_Logo.png" alt=""/>
                                            </h3></div> : rattingValue ?
                                            <div className="app-rating">
                                                <h3 className="order-no"> #{orderNo}</h3>
                                                <Rating className="rating-star" readonly initialRate={rattingValue}
                                                        empty={<i className="fa fa-star" aria-hidden="true"
                                                                  style={{color: "#ded3bd", fontSize: 30}}/>}
                                                        full={<i className="fa fa-star" aria-hidden="true"
                                                                 style={{color: "#ffd204", fontSize: 30}}/>}/>
                                            </div> : <h3 className="text-center">#{orderNo}</h3>}
                                </div>
                                {this.state.isConfirmationOpen && <div
                                    className={column === "here now" ? "modal-right-overlay customer-notification" : "modal-right-overlay"}>
                                    <div className="text-center extra-notes">
                                        <div className="heading">
                                            <h4>
                                                Confirm
                                            </h4>
                                            <i className="fa fa-times close"
                                               onClick={this.handleCloseComeInConfirmation}/>
                                        </div>
                                        <div className="text">
                                            <div>
                                                <p style={{fontSize: 18, fontWeight: 600}}> Are you sure you want to
                                                    cancel DriveBy request for this order?</p>
                                                <p style={{color: '#c53140', fontWeight: 500}}>Reason for cancel DriveBy
                                                    request</p>
                                                <textarea value={this.state.reasonForCancel}
                                                          onChange={this.handleReasonValue} rows={3}
                                                          className="reason-text"/>
                                            </div>
                                            <button className="btn btn-warning" style={{
                                                backgroundColor: '#12232d', borderColor: '#12232d', marginRight: 10,
                                                  width: 60, padding: 10, fontWeight: 600, fontSize: 14
                                            }} onClick={this.confirmComeIn}>Yes
                                            </button>
                                            <button className="btn btn-default"
                                                    style={{width: 60, padding: 10, fontWeight: 600, fontSize: 14}}
                                                    onClick={this.handleCloseComeInConfirmation}>Cancel
                                            </button>
                                        </div>
                                    </div>
                                </div>}
                                <div
                                    className={this.state.isChatOpen ? "ticket-left-contain chat-left" : this.props.completed ? "ticket-left-contain ticket-left-contain-recent" : "ticket-left-contain"}>
                                    {this.state.isChatOpen ?
                                        <MessageGuest handleSendMessage={this.handleSendMessage}
                                                      chatDetails={messagesDetails} timeZone={this.props.timeZone}/> :
                                        <GoogleMapComponent column={column} allLocation={allLocation}
                                                            storeInformation={this.props.storeInfo}
                                                            storeName={this.props.storeName}
                                                            completed={this.props.completed}/>}
                                    {this.state.isExtraNotesOpen && <div className="modal-left-overlay">
                                        <div className="text-center extra-notes">
                                            <div className="heading">
                                                <h4>
                                                    Customer Notes
                                                </h4>
                                                <i className="fa fa-times close" onClick={this.handleCloseExtraNote}/>
                                            </div>
                                            <div className="text">
                                                {notes}
                                            </div>
                                        </div>
                                    </div>}
                                    {this.state.takePhotoConfirm && <div className="modal-left-overlay">
                                        <div className="text-center extra-notes">
                                            <div className="heading">
                                                <h4>
                                                    Confirm
                                                </h4>
                                                <i className="fa fa-times close" onClick={this.handleCloseTakePhoto}/>
                                            </div>
                                            <div className="text">
                                                <div>
                                                    Are you sure you want to ReRequest for take a photo?
                                                </div>
                                                <button className="btn btn-warning" style={{
                                                    backgroundColor: '#12232d', borderColor: '#12232d', marginRight: 10,
                                                    width: 60, padding: 10, fontWeight: 600, fontSize: 14
                                                }} onClick={this.handleConfirmTakePhoto}>Yes
                                                </button>
                                                <button className="btn btn-default"
                                                        style={{width: 60, padding: 10, fontWeight: 600, fontSize: 14}}
                                                        onClick={this.handleCloseTakePhoto}>Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>}
                                </div>
                                <div
                                    className={classes.join(" ")}>
                                    <h5>Our Guest is</h5>
                                    <h3>{firstName} {lastName}</h3>
                                    {userAvatar && <img className="img-responsive" src={userAvatar} alt=""/>}
                                    <h5>What to look out for</h5>
                                    <h3>
                                        <div className="ticket-info-transport-mode">{transportMode[modeOfTransport]}
                                            <span>{modeOfTransport}</span></div>
                                    </h3>
                                    <h3>{licensePlateNumber}</h3>
                                    <h5 className="m-t-15">Phone number</h5>
                                    <h3>{phoneNumber}</h3>
                                    <h5 className="m-t-15">order details</h5>
                                    <h4>Pick up : {pickupTime}</h4>
                                    <h4 className="m-b-15">Gomex {points || 0} pts</h4>
                                    {
                                        this.state.loading ?
                                            <div><Loader loaded={false}/></div> : items && items.map((value, index) => (
                                                <h4 className="m-t-15" key={index}>{value.Quantity}x {value.Name}</h4>
                                            ))
                                    }
                                    {this.props.completed && this.props.ticketInformation.driveByDetails.cancelledReason &&
                                    <div className="order-text">
                                        <h3 style={{color: '#c53140'}}>Reason for cancelled request</h3>
                                        <p>{this.props.ticketInformation.driveByDetails.cancelledReason}</p>
                                    </div>}
                                    <div>
                                        {customerNotification.length > 0 && <h3>Customer Notifications</h3>}
                                        <ul className="modalScroll">
                                            {
                                                customerNotification && customerNotification.map((v, index) => (
                                                    <li key={index}>
                                                        <h4 className="sub-heading">{v.name}</h4>
                                                        <p style={{color: v.value.toLowerCase() === "waiting" ? '#bb7d28' : (v.value.toLowerCase() === 'rejected' ? '#BF1E2E' : '#73de02')}}>{v.value}
                                                            <span
                                                                style={{marginLeft: '2px'}}>{moment(v.notificationDateTime, 'YYYY-MM-DD hh:mm:ss A').format('HH:mm')}</span>
                                                        </p>
                                                    </li>
                                                ))
                                            }
                                        </ul>
                                    </div>
                                    <br/>
                                    {notes && <a onClick={this.showExtraNotes}
                                                 style={{cursor: 'pointer', textDecoration: 'underline'}}>Extra
                                        Notes</a>}
                                </div>
                                {!this.props.completed && <div
                                    className={column === "here now" ? "ticket-left-footer" : "ticket-left-footer customer-notify"}>
                                    {deliveryInProgressDate ?
                                        <button className="btn-delivered" onClick={this.props.handleChangeStatus}>
                                            Delivered</button>
                                        : <button className="btn-taking" onClick={this.props.handleChangeStatus}>Taking
                                            order out</button>
                                    }
                                    {/*<button className="btn-inverse"*/}
                                    {/*onClick={this.handleChat}>{this.state.isChatOpen ? "HIDE CHAT" : "Message Guest"}</button>*/}
                                    <button onClick={this.handleChat}>{this.state.isChatOpen ? "Show Map" : "Message Guest"}</button>
                                    <button className="btn-inverse"
                                            onClick={this.showCustomerNotification}>Customer Notification
                                    </button>

                                </div>}
                            </div>
                            {
                                this.state.isCustomerNotificationOpen && <div className="modal-right-overlay">
                                    <h3>What do you want the customer to do?</h3>
                                    <ul className="modal-scroll">
                                        {
                                            customerNotification && customerNotification.map((v, index) => (
                                                <li key={index}>
                                                    <h4>{v.name}</h4>
                                                    <h4 style={{color: v.value.toLowerCase() === "waiting" ? '#bb7d28' : (v.value.toLowerCase() === 'rejected' ? '#BF1E2E' : '#73de02')}}>{v.value}<span
                                                        style={{color: '#f7f7f7'}}>{moment(v.notificationDateTime, 'YYYY-MM-DD hh:mm:ss A').format('HH:mm')}</span>
                                                    </h4>
                                                </li>
                                            ))
                                        }
                                    </ul>
                                    <div
                                        className={this.props.completed ? "overlay-btn-group recent-order-buttons" : "overlay-btn-group"}>
                                        <div>
                                            {column === "here now" &&
                                            <button onClick={() => this.props.handleCustomerAction('ShowOrderNumber')}>
                                                show
                                                order number
                                            </button>}
                                            {column === "here now" &&
                                            <button onClick={() => this.props.handleCustomerAction('FlashLights')}>Flash
                                                Lights</button>}
                                            {column === "here now" &&
                                            <button onClick={() => this.props.handleCustomerAction('HonkHorn')}>Honk
                                                Horn</button>}
                                            {/*<button*/}
                                            {/*onClick={() => this.props.handleCustomerAction('AdjustMapPosition')}>*/}
                                            {/*Adjust Map Position*/}
                                            {/*</button>*/}

                                            {/*<button onClick={this.handleTakePhoto}>Take a*/}
                                            {/*photo*/}
                                            {/*</button>*/}
                                            {/*<button onClick={() => this.props.handleCustomerAction('MessageGuest')}>*/}
                                            {/*Message Guest*/}
                                            {/*</button>*/}
                                            <button onClick={this.handleComeIn}
                                                    style={{color: '#e64a49', borderColor: '#e64a49'}}>Come in
                                            </button>
                                        </div>
                                        <a onClick={this.hideCustomerNotification}
                                           style={{cursor: 'pointer'}} className="back-btn">Back</a>
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                </Dialog>
            </div>
        )
    }

    componentDidMount(){
        let _this =  this;
        window.addEventListener("beforeunload", (ev) =>
        {
            ev.preventDefault();
            if(_this.state.isChatOpen){
                _this.props.handleReadStatus("CloseChatScreen");
            }
        });
        window.addEventListener("unload", (ev) =>
        {
            if(_this.state.isChatOpen){
                _this.props.handleReadStatus("CloseChatScreen");
            }
        });
        window.onclose = (event) => {
            if(_this.state.isChatOpen){
                _this.props.handleReadStatus("CloseChatScreen");
            }
        };

        window.onbeforeunload = () => {
            if(_this.state.isChatOpen){
                _this.props.handleReadStatus("CloseChatScreen");
            }
        };
    }

    componentDidUpdate(nextProps, nextState){
        if(this.state.isChatOpen && nextProps.ticketInformation.messageDetails.length < this.props.ticketInformation.messageDetails.length){
            let _this=this;
            const chatDetails = _this.props.ticketInformation.messageDetails;
            if(_this.state.isChatOpen){
                chatDetails.forEach((msg)=>{
                    if(!msg.status && !msg.userId){
                        _this.props.handleReadStatusOpenChat(msg.id,_this.props.ticketInformation.channels.apiChatListenChannelName);
                    }
                });
            }
        }
    }
}

const mapStateToProps = (state) => {
    const {ddsStartupReducer, authReducer} = state;
    return {
        orderDetail: ddsStartupReducer,
        currentOrderChatDetail: ddsStartupReducer.currentOrderChatDetail && ddsStartupReducer.currentOrderChatDetail.messagesDetails || [],
        storeInformation: {
            latitude: authReducer.userProfile.store.latitude || '',
            longitude: authReducer.userProfile.store.longitude || ''
        },
        userProfile:authReducer.userProfile,
        getChatData: ddsStartupReducer.getChatData || false
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        startupAction: bindActionCreators(DDSStartupAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(TicketInformationDialog);