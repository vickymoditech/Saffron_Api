import React, { Component } from 'react';
import './drive-through.css';
export default class DefaultUser extends Component {
    render(){
        return(
            <div className="drive-through-icon user-img" style={{color:'white'}}>
                <span>h</span>
            </div>
        )
    }
}
