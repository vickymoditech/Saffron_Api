import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Link} from 'react-router';
import NotificationSystem from 'react-notification-system';

import Loader from '../Helpers/Loader';
import * as authAction from '../../actions/authAction';

import './forgot-password.css';

class ForgotPassword extends Component {
    constructor(props){
        super(props);
        this.state={
            notificationSystem: null,
            forgotPassword:{
                userName:"",
                emailAddress:""
            },
            loading:false
        }
    }

    addNotification = (message, level) => {
        this.state.notificationSystem.addNotification({
            message: message,
            level: level,
            autoDismiss: 3
        });
    };

    handleChange = (event) => {
        const field = event.target.name;
        const forgotPassword = this.state.forgotPassword;
        forgotPassword[field] = event.target.value;
        return this.setState({forgotPassword: forgotPassword});
    };

    handleSubmit = (event) => {
        event.preventDefault();
        const {forgotPassword} = this.state;
        let emailRegEx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if(forgotPassword.userName.trim() === "" || forgotPassword.emailAddress.trim() === ""){
          this.addNotification("UserName and Email are must be required","error");
        }else if(!emailRegEx.test(forgotPassword.emailAddress)){
           this.addNotification("please enter proper email address","error");
        }else {
            this.props.actions.auth.sendMail(forgotPassword)
        }
    };

    componentWillReceiveProps(nextProps) {
        this.setState({loading:nextProps.loading});
        if(nextProps.success){
            this.addNotification(nextProps.success_msg,'success');
            this.setState({forgotPassword:{userName:"", emailAddress:""}});
            // this.props.actions.auth.forgotPasswordComplete();
        }
        else if(nextProps.is_Error){
            this.addNotification(nextProps.error_msg,'error');
            // this.props.actions.auth.forgotPasswordComplete();
        }
    }

    componentDidMount() {
        this.setState({notificationSystem : this.refs.notificationSystem});
    };

    render(){
        return(
            <div className="vertical-alignment-helper">
                <NotificationSystem ref="notificationSystem"/>
                <div className="modal-dialog vertical-align-center">
                    <div className="modal-content">
                        <a href="javascript:void(0);" className="logo"></a>
                        <div className="modal-body">
                            <div className="row login-form">
                                <div className="col-xs-12 text-center">
                                    <h2>Forgot Your Password?</h2>
                                </div>
                                <div className="panel-body">
                                    <div className="row">
                                        <div className="col-md-offset-1 col-md-10">
                                            <div className="forgot-info"><span>Don't worry! just fill in your UserName and Email,we'll help you to reset your password.</span></div>
                                            <form>
                                                <div id="loginForm">
                                                    <div className="form-group">
                                                        <div className="input-group">
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-user" title="User Name"/>
                                                        </span>
                                                            <input type="text" value={this.state.forgotPassword.userName}
                                                                   name="userName" placeholder="Username"
                                                                   className="form-control" onChange={this.handleChange}/>
                                                        </div>
                                                    </div>
                                                    <div className="form-group">
                                                        <div className="input-group">
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-envelope" title="Email"/></span>
                                                            <input type="email" value={this.state.forgotPassword.emailAddress}
                                                                   name="emailAddress" placeholder="Registered Email"
                                                                   className="form-control" onChange={this.handleChange}/>
                                                        </div>
                                                        <div className="form-group text-center row">
                                                            <div className="col-xs-12 text-center">
                                                            </div>
                                                            <button type="submit" className="btn btn-save"
                                                                    onClick={this.handleSubmit}>SUBMIT
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div className="back-login text-center">
                                                <Link to="/login" style={{textDecoration: 'underline'}}>Back to Login</Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {this.state.loading && <Loader/>}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const {authReducer} = state;
    return {
        invalidUser: authReducer.invalidUser,
        loading: authReducer.loading,
        success:authReducer.success || false,
        success_msg:authReducer.success_msg,
        is_Error:authReducer.is_Error,
        error_msg:authReducer.error_msg
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        auth: bindActionCreators(authAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword)

