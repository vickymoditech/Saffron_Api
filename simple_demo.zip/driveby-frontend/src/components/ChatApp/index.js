import React, {Component} from 'react';
import PubNubReact from 'pubnub-react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import Header from '../Helpers/Header';
import ChatComponent from './ChatComponent';
import {getDateGMT} from '../Home/waitingTime';
import {GyGLog} from '../../Logging/GyGLog';
import Loader from '../Helpers/Loader';
import * as DDSStartupAction from '../../actions/DDSStartupAction';

import './ChatApp.css';

class ChatApp extends Component {

    constructor(props) {
        super(props);
        this.state = {
            controlChannelName: [],
            allChatDetails: [],
            allChatChannelName: [],
            isFirst: true,
        };

        try {
            this.pubnub = new PubNubReact({
                publishKey: 'pub-c-19816247-f9ed-4214-bf9f-d92a2961625e',
                subscribeKey: 'sub-c-39f660ae-a81b-11e7-a527-fa7c0b7198dc'
            });
            this.pubnub.init(this);
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component Constructor.' + error);
        }
    }

    componentWillMount() {
        this.props.actions.startupAction.getChatStartup(this.props.userProfile.store.storeId, this.props.userProfile.store.storeName);
        let that = this;
        try {
            this.pubnub.addListener({
                message: function (msg) {
                    if (msg.message.messageType.toLowerCase() === "chatMessage".toLowerCase()) {
                        that.newMessage(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "newRequest".toLowerCase()) {
                        that.newChatBox(msg.message);
                    }
                    if (msg.message.messageType.toLowerCase() === "CancleCompeleteRequest".toLowerCase()) {
                        that.cancleCompeleteRequest(msg.message);
                    }
                    if (msg.message.messageType.toLowerCase() === "chatMessageConfirm".toLowerCase()) {
                        that.sendMessageConfirm(msg);
                    }
                    if (msg.message.messageType.toLowerCase() === "MessageStatusUpdateConfirm".toLowerCase()) {
                        that.messageSeenStatus(msg.message);
                    }
                    if (msg.message.messageType.toLowerCase() === "seenMessagesConfirm".toLowerCase()) {
                        that.messageSeenStatusFirst(msg.message);
                    }
                }
            });
        } catch (error) {
            GyGLog('debug', 'DDS Log Home Component ComponentWillMount Pubnub Add listener' + error);
        }
    }

    sendMessage = (orderNumber, customerId, chatChannel, chatMessage) => {
        const message = {
            messageType: "chatMessage",
            message: {
                type: "TEXT",
                data: chatMessage
            },
            data: {
                order: {
                    customerId: customerId,
                    orderNumber: orderNumber
                },
                sender: "APP"
            }
        };
        this.pubnub.publish({message: message, channel: chatChannel});
    };

    sendMessageConfirm = (msg) => {
        let messagesDetails = this.state.allChatDetails.messagesDetails;
        let newMessageDetails = messagesDetails && messagesDetails.filter((data, index) => {
                if (msg.message.data.order.orderNumber === data.order.orderNumber) {
                    let newMsg = {
                        data: msg.message.message.data,
                        dateTime: msg.message.message.sendDateTime,
                        message_type: msg.message.message.type,
                        status: msg.message.message.status,
                        userId: msg.message.message.userId,
                        id:msg.message.message.id,
                    };
                    data.messageDetails = [...data.messageDetails, newMsg];
                    return data;

                } else return data
            });
        let allChatDetails = this.state.allChatDetails;
        allChatDetails.messagesDetails = newMessageDetails;
        this.setState({allChatDetails: allChatDetails});
    };

    newMessage = (newMessageDetails) => {
        let messagesDetails = this.state.allChatDetails.messagesDetails;
        let getData = messagesDetails.find((order) => order.order.orderNumber === newMessageDetails.message.data.order.orderNumber);
        const index = messagesDetails.indexOf(getData);
        if(index>=0){
            let newMsg = {
                data: newMessageDetails.message.message.data,
                dateTime: newMessageDetails.message.message.sendDateTime,
                message_type: newMessageDetails.message.message.type,
                status: newMessageDetails.message.message.status,
                userId: this.props.userProfile.userId,
            };
            messagesDetails[index].messageDetails = [...messagesDetails[index].messageDetails, newMsg];
        }
        this.setState({allChatDetails:{...this.state.allChatDetails,messagesDetails:messagesDetails}});
    };

    newChatBox = (message) => {
        this.pubnub.subscribe({channels: [message.data.channels.appChatListenChannelName], withPresence: true});
        this.setState({
            allChatDetails: {
                ...this.state.allChatDetails,
                messagesDetails: [...this.state.allChatDetails.messagesDetails, message.data]
            }
        });
    };

    cancleCompeleteRequest = (message) => {
        let messagesDetails = this.state.allChatDetails.messagesDetails;
        let getData = messagesDetails.find((order) => order.order.orderNumber === message.data.order.orderNumber);
        const index = messagesDetails.indexOf(getData);
        if(index>=0){
            messagesDetails.splice(index,1);
            this.setState({allChatDetails:{...this.state.allChatDetails,messagesDetails:messagesDetails}});
            this.pubnub.unsubscribe({channels: [message.data.channels.appChatListenChannelName]});
        }
    };

    messageSeenStatus = (message) => {
        let messagesDetails = this.state.allChatDetails.messagesDetails;
        let getData = messagesDetails.find((order) => order.order.orderNumber === message.data.order.orderNumber);
        const index = messagesDetails.indexOf(getData);
        if(index>=0){
            let getMessage = getData.messageDetails.find((msg)=>msg.id === message.data.message.id);
            const indexMessage = getData.messageDetails.indexOf(getMessage);
            if(indexMessage >= 0){
                messagesDetails[index]['messageDetails'][indexMessage].status = true;
            }
        }
        this.setState({allChatDetails:{...this.state.allChatDetails,messagesDetails:messagesDetails}})
    };

    messageSeenStatusFirst = (msg) => {
        let messagesDetails = this.state.allChatDetails.messagesDetails;
        let getData = messagesDetails.find((order) => order.order.orderNumber === msg.data.order.orderNumber);
        const index = messagesDetails.indexOf(getData);
        if(index>=0){
            let newMessage = getData.messageDetails.filter((msgDetails)=>{
                let diff = getDateGMT(msgDetails.dateTime,this.props.userProfile.store.gmtOffset).diff(getDateGMT(msg.data.order.dateTime,this.props.userProfile.store.gmtOffset));
                if(diff <= 0){
                    msgDetails.status= true;
                    return msgDetails
                }else return msgDetails
            });
            messagesDetails[index]['messageDetails'] = newMessage;
        }
        this.setState({allChatDetails:{...this.state.allChatDetails,messagesDetails:messagesDetails}})
    };

    componentWillReceiveProps(nextProps) {
        if (this.props.loading && !nextProps.loading) {
            let allChatChannelName = []
            allChatChannelName.push(nextProps.chatStartupData.chatControlChannelName);
            nextProps.chatStartupData && nextProps.chatStartupData.messagesDetails && nextProps.chatStartupData.messagesDetails.map((data, index) => {
                allChatChannelName.push(data.channels.appChatListenChannelName);
            });
            this.setState({allChatDetails: nextProps.chatStartupData, allChatChannelName: allChatChannelName});
            this.pubnub.subscribe({channels: allChatChannelName, withPresence: true});
        }
    };

    render() {
        const messageDetails = this.state.allChatDetails.messagesDetails;
        return (
            <div>
                <Header/>
                {this.props.loading && <Loader/>}
                {messageDetails && messageDetails.map((data, index) => (
                    <ChatComponent chatDetail={data} key={index} sendMessage={this.sendMessage} timeZone={this.props.userProfile.store.gmtOffset}/>
                ))}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const {ddsStartupReducer, authReducer} = state;;
    return {
        loading: ddsStartupReducer.chatDetailsLoading || false,
        chatStartupData: ddsStartupReducer.chatStartupData || [],
        userProfile: authReducer.userProfile
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        startupAction: bindActionCreators(DDSStartupAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(ChatApp);