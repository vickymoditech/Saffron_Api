import React, {Component} from 'react';
import { Twemoji } from 'react-emoji-render';

import {getDateGMT} from '../Home/waitingTime';
export default class FromMessage extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        const {msgDetail} = this.props;
        return (
            <div className="chat-component">
                <div className="chat-content darker">
                    <p><Twemoji text={msgDetail.data}/></p>
                </div>
                <span className="time-left"><span className="time-right">{getDateGMT(msgDetail.dateTime,this.props.timeZone).format("HH:mm:ss A")}</span></span>
            </div>
        )
    }
}


