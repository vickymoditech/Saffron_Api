import React, {Component} from 'react';
import FromMessage from './FromMessage';
import ToMessage from './ToMessage';

export default class ChatComponent extends Component {

    constructor(props) {
        super(props);
        this.state={
          chatMessage:""
        };
    }

    onSendMessage = (e) => {
        e.preventDefault();
        const message = this.state.chatMessage.trim();
        if(message.length > 0){
            this.props.sendMessage(this.props.chatDetail.order.orderNumber,this.props.chatDetail.order.customerId,this.props.chatDetail.channels.apiChatListenChannelName,message);
        }
        this.setState({chatMessage:""});
    };

    onHandleChange = (e) => {
        this.setState({chatMessage:e.target.value});
    };

    handleScrollToBottom = () => {
        let elem = this.refs.chatBox;
        elem.scrollTop= elem.scrollHeight;
    };

    render() {
        const {chatDetail} = this.props;
        return (
            <div>
                <div className="col-md-4">
                    <div className="text-center order">
                        Order Number {chatDetail.order.orderNumber}
                    </div>
                    <div className="chat_section">
                        <div className="sdr-rcv" ref="chatBox">
                            <div>
                                {chatDetail.messageDetails && chatDetail.messageDetails.map((data,index)=>(
                                    data.userId ? <FromMessage msgDetail={data} key={index} timeZone={this.props.timeZone}/>:<ToMessage msgDetail={data} key={index} timeZone={this.props.timeZone}/>
                                    ))}

                            </div>
                        </div>
                        <div className="chat-box">

                            <div className="module">
                                <form onSubmit={this.onSendMessage}>
                                <a> <input type="text" className="form-control send" value={this.state.chatMessage}
                                                    placeholder="Type Your Chat Here..." onChange={this.onHandleChange} maxLength={600}/>
                                    <i className="fa fa-location-arrow " onClick={this.onSendMessage}/></a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        )
    }

    componentDidMount(){
        this.handleScrollToBottom()
    }

    componentDidUpdate(){
        this.handleScrollToBottom()
    }
}


