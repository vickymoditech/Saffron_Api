import React, {Component} from 'react';
import { Twemoji } from 'react-emoji-render';

import {getDateGMT} from '../Home/waitingTime'
export default class ToMessage extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        const {msgDetail} = this.props;
        return (
            <div className="chat-component">
                <div className="chat-content">
                    <p><Twemoji text={msgDetail.data}/></p>
                </div>
                <span className="time-right">{msgDetail.status && <i className="fa fa-eye"/>}{getDateGMT(msgDetail.dateTime,this.props.timeZone).format("HH:mm:ss A")}</span>
            </div>
        )
    }
}


