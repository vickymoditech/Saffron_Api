import React, {Component} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class LocationTrackingReport extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let barData = [];
        reportData.forEach((data) => {
            barData.push({
                date: data.date,
                minLocationCount: data.minLocationCount,
                maxLocationCount: data.maxLocationCount,
                averageLocation:data.avgLocationCount
            });
        });
        let options = {
            type: "serial",
            theme: "light",
            categoryField: "date",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            dataProvider: barData,
            graphs: [
                {
                    balloonText: "Minimum Location:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    lineAlpha: 0.3,
                    title: "Min Location Tracked",
                    type: "column",
                    valueField: "minLocationCount"
                },
                {
                    balloonText: "Maximum Location:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    lineAlpha: 0.3,
                    title: "Max Location Tracked",
                    type: "column",
                    valueField: "maxLocationCount"
                },
                {
                    id: "g1",
                    balloonText: "Average Location:[[averageLocation]]",
                    bullet: "round",
                    bulletBorderAlpha: 1,
                    bulletColor: "#FFFFFF",
                    hideBulletsCount: 50,
                    title: "Average Location",
                    lineColor: "#BF1E2E",
                    valueField: "averageLocation",
                    useLineColorForBulletBorder: true
                }
            ],
            chartCursor: {
                categoryBalloonEnabled: false,
                cursorAlpha: 0,
                zoomable: false
            },
            legend: {
                useGraphSettings: true,
                align: "center"
            },
            valueAxes: [
                {
                    title: "Number Of Location Tracked",
                    stackType: "regular"
                }
            ],
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };
        return (
            <div>
                <div className="col-lg-6 col-xs-12 c-0ol-sm-12 all-store-chart ">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Min/Max Location Tracked Analytics</span>
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                barData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}



