import React, {Component} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';
var AmCharts = require("@amcharts/amcharts3-react");

export default class AverageWaitTimeReport extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let chartData = [];
        let ticksValue = [];
        reportData && reportData.forEach((data) => {
            ticksValue.push(data.date);
            chartData.push({
                date: data.date,
                avgWaitTime: data.avgWaitTime,
                avgWaitTimeText:data.avgWaitTimeText
            });
        });

        let options = {
            type: "serial",
            theme: "light",
            categoryField: "date",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            startDuration: 1,
            dataProvider: chartData,
            graphs: [
                {
                    balloonText: "Average Wait Time:[[avgWaitTimeText]]",
                    fillAlphas: 0.8,
                    fillColors: "#44B749",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    id: "AmGraph-1",
                    lineAlpha: 0.2,
                    title: "Wait Time",
                    type: "column",
                    valueField: "avgWaitTime"
                }
            ],
            legend: {
                useGraphSettings: true,
                align: "center"
            },
            depth3D: 20,
            angle: 30,
            valueAxes: [
                {
                    title: "Wait Time(in seconds)"
                }
            ],
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };

        return (
            <div>
                <div className="col-lg-6 col-xs-12 col-sm-12 avg-wait-time-report">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Average Wait Time Analytics</span>
                                {/*<small>distance stats...</small>*/}
                            </div>
                            <div className="chart-tools">
                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                chartData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
