import React, {Component} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class CancelledRequests extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let barData = [];
        reportData.forEach((data) => {
            barData.push({
                date: data.date,
                customerCancelledCount: data.customerCancelledCount,
                staffCancelledCount: data.staffCancelledCount,
            });
        });
        let options = {
            type: "serial",
            theme: "light",
            categoryField: "date",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            dataProvider: barData,
            graphs: [
                {
                    balloonText: "Customer Cancelled Count:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    lineAlpha: 0.3,
                    title: "Customer Cancelled Count",
                    type: "column",
                    valueField: "customerCancelledCount"
                },
                {
                    balloonText: "Staff Cancelled Count:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    lineAlpha: 0.3,
                    title: "Staff Cancelled Count",
                    type: "column",
                    valueField: "staffCancelledCount"
                }
            ],
            chartCursor: {
                categoryBalloonEnabled: false,
                cursorAlpha: 0,
                zoomable: false
            },
            legend: {
                useGraphSettings: true,
                align: "center"
            },
            valueAxes: [
                {
                    title: "Number Of Requests",
                    stackType: "regular"
                }
            ],
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };
        return (
            <div>
                <div className="col-lg-6 col-xs-12 c-0ol-sm-12 all-store-chart ">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Cancelled Requests by Staff/Customer</span>
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                barData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}




