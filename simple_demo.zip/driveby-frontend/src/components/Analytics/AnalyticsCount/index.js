import React, {Component} from 'react';
import CountUp from 'react-countup';
import Rating from 'react-rating';
import {Progress} from 'semantic-ui-react';

export default class AnalyticsCount extends Component {
    render() {
        return (
            <div className="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div className="dashboard-stat2">
                    <div className="analytics-display">
                        <div className="analytics-number">
                            <h3 className="analytics-font-green-sharp">
                                { this.props.isRating ? <Rating readonly initialRate={this.props.value}
                                                                  empty={<i className="fa fa-star" aria-hidden="true"
                                                                            style={{color: "#ded3bd", fontSize: 30}}/>}
                                                                  full={<i className="fa fa-star" aria-hidden="true"
                                                                           style={{color: "#ffd204", fontSize: 30}}/>}/>
                                        :
                                        <span data-counter="counterup" data-value={this.props.value}><CountUp start={0}
                                                                                                              end={this.props.value}/></span>}
                                {/*<small className="analytics-font-green-sharp">{this.props.symbol}</small>*/}
                            </h3>
                            <small>{this.props.text}</small>
                        </div>
                        <div className="analytics-icon">
                            <img src={this.props.img}/>
                        </div>
                        <div className="analytics-progress-bar">
                            <Progress percent={this.props.progress} size='tiny'/>
                        </div>
                        <div className="progress-percentage">
                            <span className="text-uppercase progress-text progress-title">Progress</span>
                            <span className="pull-right progress-text percent">{Math.round(this.props.progress)}%</span>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}