import React, {Component} from 'react';
import $ from "jquery";
import {orderBy} from "lodash";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class TransportReport extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let pieData = orderBy(reportData, ['transportCount'], 'desc');
        if (pieData.length) {
            pieData[0].pulledOut = true;
        }
        let options = {
            type: "pie",
            theme: "light",
            valueField: "transportCount",
            titleField: "modeOfTransport",
            dataProvider: reportData,
            legend: {
                align: "center",
                valueText: ""
            },
            pulledField: "pulledOut",
            depth3D: 15,
            angle: 30,
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };

        return (
            <div>
                <div className="col-lg-6 col-xs-12 col-sm-12">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Mode Of Transport Analytics</span>
                                {/*<small>distance stats...</small>*/}
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                reportData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/>
                                    : <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


