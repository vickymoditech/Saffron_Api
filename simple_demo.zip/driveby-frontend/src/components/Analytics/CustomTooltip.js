import React, {Component} from 'react';

export default class CustomTooltip extends Component {
    render(){
        const { active } = this.props;
        if (active) {
            const { payload, label } = this.props;
            return (
                <div className="custom-tooltip">
                    <p className='barchart-tooltip'>{label}</p>
                    {this.props.isAverageTimeChart ? <p className='barchart-tooltip'>Average Wait Time : {payload[0].value}</p>: payload.length && payload.map((value,index)=>(
                            <p className='barchart-tooltip' key={index}>{payload[index].name} : {payload[index].value}</p>
                        ))}
                    {/*<p className="intro">{this.getIntroOfPage(label)}</p>*/}
                    {/*<p className="desc">Anything you want can be displayed here.</p>*/}
                </div>
            );
        }
        return null;
    }
}
