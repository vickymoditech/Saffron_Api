import React, {Component} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class MostActiveCustomerAllStore extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let barData = [];
        reportData.forEach((data) => {
            barData.push({
                name: data.name,
                orderCount: data.orderCount
            });
        });
        let options = {
            type: "serial",
            theme: "light",
            categoryField: "name",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            dataProvider: barData,
            graphs: [
                {
                    balloonText: "Total DriveBy Request:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    lineAlpha: 0.3,
                    title: "Total DriveBy Request",
                    type: "column",
                    valueField: "orderCount"
                }
            ],
            chartCursor: {
                categoryBalloonEnabled: false,
                cursorAlpha: 0,
                zoomable: false
            },
            legend: {
                useGraphSettings: true,
                align: "center"
            },
            valueAxes: [
                {
                    title: "Number Of Request",
                    stackType: "regular"
                }
            ],
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };
        return (
            <div>
                <div className="col-lg-6 col-xs-12 c-0ol-sm-12 all-store-chart ">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Most Active Customers Analytics(All Stores)</span>
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                barData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}




