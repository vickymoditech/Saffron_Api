import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Dropdown} from 'semantic-ui-react';

import Header from "../Helpers/Header/index";
import WeeklyReport from './WeeklyReport';
import ReportAllStores from './ReportAllStores';
import AverageWaitTimeReport from './AverageWaitTimeReport';
import RatingReport from './RatingReport';
import TransportReport from './TransportReport';
import RequestByHours from './RequestByHours';
import LocationTrackingReport from './LocationTrackingReport';
import ReRequestedOrder from './ReRequestedOrder';
import CancelledRequests from './CancelledRequests';
import TransportTypeByDate from './TransportTypeByDate';
import MostActiveCustomers from './MostActiveCustomers';
import MostActiveCustomerAllStore from './MostActiveCutomerAllStore';
import * as AnalyticsAction from '../../actions/AnalyticsAction';
import * as storeConfigurationAction from '../../actions/storeConfigurationAction';
import AnalyticsCount from './AnalyticsCount';
import './analytics.css';

class Analytics extends Component {
    constructor(props) {
        super(props);
        let today = new Date();
        let yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 6);
        this.state = {
            report: 'week',
            startDate: this.getStringDate(yesterday),
            endDate: this.getStringDate(today),
            storeName: props.userProfile.store.storeName
        }
    }

    onChangeReportSelection = (event, {value}) => {
        if (value !== this.state.report) {
            let curr = new Date();
            let firstDay = "", lastDay = "";
            if (value === "week") {
                let today = new Date();
                let yesterday = new Date(today);
                yesterday.setDate(today.getDate() - 6);
                firstDay = yesterday;
                lastDay = today;
            } else if (value === "month") {
                let today = new Date();
                let yesterday = new Date(today);
                yesterday.setDate(today.getDate() - 30);
                firstDay = yesterday;
                lastDay = today;
            } else if (value === "today") {
                firstDay = new Date();
                lastDay = new Date();
            } else if (value === "yesterday") {
                let today = new Date();
                let yesterday = new Date(today);
                yesterday.setDate(today.getDate() - 1);
                firstDay = yesterday;
                lastDay = yesterday;
            }
            let that = this;
            this.setState({startDate: this.getStringDate(firstDay), endDate: this.getStringDate(lastDay)}, () => {
                that.changeReport()
            });
        }
        this.setState({report: value});
    };

    onChangeStore = (event, {value}) => {
        if(this.state.storeName !== value) {
            this.setState({storeName:value},()=>{
                this.changeReport()
            });
        }
    };

    getStringDate = (dateToConvert) => {
        let month = dateToConvert.getMonth() + 1;
        let date = dateToConvert.getDate();
        if (month < 10) {
            month = "0" + month
        }
        if (date < 10) {
            date = "0" + date;
        }
        return dateToConvert.getFullYear() + "-" + month + "-" + date;
    };

    componentWillMount() {
        this.props.userProfile.roleOrder === 1 && this.props.actions.storeConfigurationAction.getAllStores();
        this.changeReport();
    }

    changeReport = () => {
        let storeName = this.state.storeName;
        let startDate = this.state.startDate;
        let endDate = this.state.endDate;
        const reportDetail = {
            storeName: storeName,
            startDate: startDate,
            endDate: endDate
        };
        const reportDetailStore = {
            startDate: startDate,
            endDate: endDate
        };

        this.props.actions.analytics.getDriveByOrderReport(reportDetail);
        this.props.actions.analytics.getAllStoreDriveByOrderReport(reportDetailStore);
        this.props.actions.analytics.getAvgWaitTimeReport(reportDetail);
        this.props.actions.analytics.getRatingReport(reportDetail);
        this.props.actions.analytics.getTransportReport(reportDetail);
        this.props.actions.analytics.getTicketStatistics(reportDetail);
        this.props.actions.analytics.getReportByHours(reportDetail);
        this.props.actions.analytics.getLocationTrackingReport(reportDetail);
        this.props.actions.analytics.getReRequestedOrderReport(reportDetail);
        this.props.actions.analytics.getCancelledRequests(reportDetail);
        this.props.actions.analytics.getTransportTypeByDate(reportDetail);
        this.props.actions.analytics.getMostActiveUsers(reportDetail);
        this.props.actions.analytics.getMostActiveUsersAllStore(reportDetailStore);
    };

    render() {
        let {
            reportData, loading, loadingAllStore, reportDataAllStore, loadingAvgWitTime, reportDataAvgWaitTime, loadingRating,
            reportDataRating, loadingTransport, reportDataTransport, loadingTicketStats, reportDataTicketStats, reportDataRequestByHours,
            loadingRequestByHours, loadingRequestLocationTracking, reportDataRequestLocationTracking,
            loadingReRequestedOrder,reportDataReRequestedOrder,
            loadingCancelledRequest,reportDataCancelledRequest,
            loadingTransportTypeByDate,reportDataTransportTypeByDate,allStores,
            loadingMostActiveCustomers,reportDataMostActiveCustomers,
            loadingMostActiveCustomersAllStore,reportDataMostActiveCustomersAllStore
        } = this.props;
        let progressCompleted = reportDataTicketStats.totalCompletedRequests * 100 / reportDataTicketStats.totalRequests;
        let progressCancelled = reportDataTicketStats.totalCancelledRequests * 100 / reportDataTicketStats.totalRequests;
        let progressRating = reportDataTicketStats.avgRating * 100 / 5;
        let options = [{text: 'Today', value: 'today'}, {text: 'Yesterday', value: 'yesterday'}, {
            text: 'Last 7 Days',
            value: 'week'
        }, {text: 'Last 30 Days', value: 'month'}];
        let optionsAllStores = [];
        if(this.props.userProfile.roleOrder === 1){
            allStores.forEach((data,index)=>{
                optionsAllStores.push({text:data.storeName,value:data.storeName});
            });
        }

        return (
            <div className="analytics-wrap">
                <Header/>
                <div className="sub-header-dropdown">
                    <div className="dropdown-right">
                        {this.props.userProfile.roleOrder === 1 && <Dropdown
                            options={optionsAllStores}
                            search
                            fluid
                            selection
                            value={this.state.storeName}
                            onChange={this.onChangeStore}
                            className="header-select-dropdown all-store"
                        /> }
                        <Dropdown
                            options={options}
                            search
                            fluid
                            selection
                            value={this.state.report}
                            onChange= {this.onChangeReportSelection}
                            className="header-select-dropdown"
                        />
                    </div>
                </div>
                <div className="dashboard-main">
                    <div className="row">
                        <AnalyticsCount text="TOTAL REQUESTS" value={reportDataTicketStats.totalRequests || 0}
                                        loading={loadingTicketStats} progress={100} img="/assets/Images/total_request.png"/>
                        <AnalyticsCount text="TOTAL COMPLETED REQUESTS"
                                        value={reportDataTicketStats.totalCompletedRequests || 0}
                                        loading={loadingTicketStats} progress={progressCompleted || 0} img="/assets/Images/complete_request.png"/>
                        <AnalyticsCount text="TOTAL CANCELLED REQUESTS"
                                        value={reportDataTicketStats.totalCancelledRequests || 0}
                                        loading={loadingTicketStats} progress={progressCancelled || 0} img="/assets/Images/cancel.png"/>
                        <AnalyticsCount text="AVERAGE RATING" value={reportDataTicketStats.avgRating || 0}
                                        loading={loadingTicketStats} isRating={true} progress={progressRating || 0} img="/assets/Images/rating_analytics.png"/>
                    </div>
                </div>
                <WeeklyReport reportData={reportData} loading={loading}/>
                <RatingReport reportData={reportDataRating} loading={loadingRating}/>
                <AverageWaitTimeReport reportData={reportDataAvgWaitTime} loading={loadingAvgWitTime}/>
                <TransportReport reportData={reportDataTransport} loading={loadingTransport}/>
                <ReportAllStores reportData={reportDataAllStore} loading={loadingAllStore}/>
                <RequestByHours reportData={reportDataRequestByHours} loading={loadingRequestByHours}/>
                <LocationTrackingReport reportData={reportDataRequestLocationTracking}
                                        loading={loadingRequestLocationTracking}/>
                <ReRequestedOrder reportData={reportDataReRequestedOrder} loading={loadingReRequestedOrder}/>
                <CancelledRequests reportData={reportDataCancelledRequest} loading={loadingCancelledRequest}/>
                <TransportTypeByDate reportData={reportDataTransportTypeByDate} loading={loadingTransportTypeByDate}/>
                <MostActiveCustomers reportData={reportDataMostActiveCustomers} loading={loadingMostActiveCustomers} storeName={this.state.store}/>
                <MostActiveCustomerAllStore reportData={reportDataMostActiveCustomersAllStore} loading={loadingMostActiveCustomersAllStore}/>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const {analyticsReducer, authReducer,storeConfigurationReducer} = state;
    return {
        loading: analyticsReducer.loading,
        reportData: analyticsReducer.reportData,
        loadingAllStore: analyticsReducer.loadingAllStore,
        reportDataAllStore: analyticsReducer.reportDataAllStore,
        loadingAvgWitTime: analyticsReducer.loadingAvgWitTime,
        reportDataAvgWaitTime: analyticsReducer.reportDataAvgWaitTime,
        loadingRating: analyticsReducer.loadingRating,
        reportDataRating: analyticsReducer.reportDataRating,
        loadingTransport: analyticsReducer.loadingTransport,
        reportDataTransport: analyticsReducer.reportDataTransport,
        loadingTicketStats: analyticsReducer.loadingTicketStats,
        reportDataTicketStats: analyticsReducer.reportDataTicketStats,
        loadingRequestByHours: analyticsReducer.loadingRequestByHours,
        reportDataRequestByHours: analyticsReducer.reportDataRequestByHours,
        loadingRequestLocationTracking: analyticsReducer.loadingRequestLocationTracking,
        reportDataRequestLocationTracking: analyticsReducer.reportDataRequestLocationTracking,
        loadingReRequestedOrder:analyticsReducer.loadingReRequestedOrder,
        reportDataReRequestedOrder:analyticsReducer.reportDataReRequestedOrder,
        loadingCancelledRequest:analyticsReducer.loadingCancelledRequest,
        reportDataCancelledRequest:analyticsReducer.reportDataCancelledRequest,
        loadingTransportTypeByDate:analyticsReducer.loadingTransportTypeByDate,
        reportDataTransportTypeByDate:analyticsReducer.reportDataTransportTypeByDate,
        loadingMostActiveCustomers:analyticsReducer.loadingMostActiveCustomers,
        reportDataMostActiveCustomers:analyticsReducer.reportDataMostActiveCustomers,
        loadingMostActiveCustomersAllStore:analyticsReducer.loadingMostActiveCustomersAllStore,
        reportDataMostActiveCustomersAllStore:analyticsReducer.reportDataMostActiveCustomersAllStore,
        userProfile: authReducer.userProfile,
        allStores:storeConfigurationReducer.allStores || []
    };
};

const mapDispatchToProps = dispatch => ({
    actions: {
        analytics: bindActionCreators(AnalyticsAction, dispatch),
        storeConfigurationAction: bindActionCreators(storeConfigurationAction,dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Analytics);