import React, {Component} from 'react';

export default class CustomLabel extends Component {
    render(){
        const {fill,x,y,fontSize,rotate} = this.props;
        return(
            <text fill={fill} x={x} y={y} fontSize={fontSize} transform={rotate}>
                {this.props.labelText}
            </text>
        )
    }
}
