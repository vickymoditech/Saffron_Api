import React, {Component} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class ReportAllStores extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let barData = [];
        reportData.forEach((data) => {
            barData.push({
                storeName: data.storeName,
                Completed: data.completedCount,
                Cancelled: data.cancelledCount
            });
        });
        let options = {
            type: "serial",
            theme: "light",
            categoryField: "storeName",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            dataProvider: barData,
            graphs: [
                {
                    balloonText: "Completed:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    fillColors: "#44B749",
                    lineAlpha: 0.3,
                    title: "Completed",
                    type: "column",
                    valueField: "Completed"
                },
                {
                    balloonText: "Cancelled:[[value]]",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    fillAlphas: 0.8,
                    fillColors: "#BF1E2E",
                    lineAlpha: 0.3,
                    title: "Cancelled",
                    type: "column",
                    valueField: "Cancelled"
                }
            ],
            chartCursor: {
                categoryBalloonEnabled: false,
                cursorAlpha: 0,
                zoomable: false
            },
            legend: {
                useGraphSettings: true,
                align: "center"
            },
            depth3D: 10,
            angle: 15,
            valueAxes: [
                {
                    title: "Number Of Requests",
                    stackType: "regular"
                }
            ],
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };
        return (
            <div>
                <div className="col-lg-6 col-xs-12 col-sm-12 all-store-chart">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Completed/Cancelled Requests(Store Wise)</span>
                                {/*<small>distance stats...</small>*/}
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                barData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


