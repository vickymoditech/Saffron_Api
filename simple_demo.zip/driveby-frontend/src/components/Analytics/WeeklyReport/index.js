import React, {Component} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class WeeklyReport extends Component {

    componentWillUpdate() {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        }, 3000)
    }

    render() {
        let {reportData} = this.props;
        let barData = [];
        reportData.forEach((data) => {
            barData.push({
                date: data.date,
                Completed: data.completedCount,
                Cancelled: data.cancelledCount
            });
        });
        let options = {
            type: "serial",
            theme: "light",
            categoryField: "date",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            startDuration: 1,
            dataProvider: barData,
            graphs: [
                {
                    balloonText: "Completed:[[value]]",
                    fillAlphas: 0.8,
                    fillColors: "#44B749",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    id: "AmGraph-1",
                    lineAlpha: 0.2,
                    title: "Completed",
                    type: "column",
                    valueField: "Completed"
                },
                {
                    balloonText: "Cancelled:[[value]]",
                    fillAlphas: 0.8,
                    fillColors: "#BF1E2E",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    id: "AmGraph-2",
                    lineAlpha: 0.2,
                    title: "Cancelled",
                    type: "column",
                    valueField: "Cancelled"
                }
            ],
            depth3D: 10,
            angle: 15,
            legend: {
                useGraphSettings: true,
                align: "center"
            },
            valueAxes: [
                {
                    title: "Number Of Requests"
                }
            ]
        };

        return (
            <div>
                <div className="col-lg-6 col-xs-12 col-sm-12 complete-cancel-request">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span> Completed/Cancelled Requests</span>
                                {/*<small>distance stats...</small>*/}
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                barData.length ? <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}