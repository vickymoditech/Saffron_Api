import React, {Component, PropTypes} from 'react';
import $ from "jquery";

import DataNotFound from '../DataNotFound';
import ChartLoader from '../../Helpers/ChartLoader';

var AmCharts = require("@amcharts/amcharts3-react");

export default class RatingReport extends Component {

    hideAnchor = () => {
        setTimeout(() => {
            $('a[title="JavaScript charts"]').hide()
        })
    };

    finishedAnimation = () => {
        this.hideAnchor();
    };

    render() {
        let {reportData} = this.props;
        let chartData = [];
        reportData.forEach((data) => {
            let bulletImg;
            if (data.avgRating > 4 && data.avgRating <= 5) {
                bulletImg = "/assets/Images/rating5.png"
            } else if (data.avgRating > 3 && data.avgRating <= 4) {
                bulletImg = "/assets/Images/rating4.png"
            } else if (data.avgRating > 2 && data.avgRating <= 3) {
                bulletImg = "/assets/Images/rating3.png"
            } else if (data.avgRating > 1 && data.avgRating <= 2) {
                bulletImg = "/assets/Images/rating2.png"
            } else {
                bulletImg = "/assets/Images/rating1.png"
            }
            chartData.push({
                date: data.date,
                AverageRating: data.avgRating,
                bullet: bulletImg,
                totalRating: data.totalRating
            });
        });

        let options = {
            type: "serial",
            theme: "light",
            categoryField: "date",
            categoryAxis: {
                gridPosition: "start",
                labelRotation: 45
            },
            responsive: {
                enabled: true
            },
            startDuration: 1,
            dataProvider: chartData,
            hideBulletsCount:1,
            graphs: [
                {
                    balloonText: "Average Rating:[[value]]<br>Rating Count:[[totalRating]]",
                    fillAlphas: 0.8,
                    customBulletField: "bullet",
                    labelText: "[[value]]",
                    labelPosition: "middle",
                    lineAlpha: 0.2,
                    title: "Rating",
                    type: "column",
                    valueField: "AverageRating",
                    bulletSize: 30,
                    bulletOffset: 15
                }
            ],
            legend: {
                align: "center"
            },
            valueAxes: [
                {
                    title: "Rating"
                }
            ],
            listeners:
                [{ event: "drawn", method: this.finishedAnimation }]
        };

        return (
            <div>
                <div className="col-lg-6 col-xs-12 col-sm-12 avg-rating">
                    <div className="analytics-chart-modal">
                        <div className="analytics-chart-header">
                            <div className="chart-title">
                                <span>Average Rating For DriveBy Experience</span>
                                {/*<small>distance stats...</small>*/}
                            </div>
                            <div className="chart-tools">

                            </div>
                        </div>
                        <div className="analytics-chart-body">
                            { this.props.loading ? <ChartLoader/> :
                                chartData.length > 0 ?
                                    <AmCharts.React style={{width: '100%', height: 400}} options={options}/> :
                                    <DataNotFound/>
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
