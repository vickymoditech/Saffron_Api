import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import NotificationSystem from 'react-notification-system';
import Switch from 'react-flexible-switch';
import {Dropdown} from 'semantic-ui-react'
import {orderBy} from "lodash";

import * as storeConfigurationAction from '../../actions/storeConfigurationAction';
import Loader from '../Helpers/Loader';
import Header from '../Helpers/Header';
import '../StoreConfiguration/store-configuration.css';

class StoreUserConfiguration extends Component {
    constructor(props) {
        super(props);
        const userProfile = props.userProfile;
        const userRole = userProfile && userProfile.roleOrder;
        let storeName = userProfile.store.storeName;
        const storeId = userProfile.store.storeId.toString();
        this.state = {
            userConfigurationDetails: {
                storeId: storeId,
                userName: "",
                emailAddress: "",
                password: "",
                role: "",
                firstName: "",
                lastName: "",
                filterUser: ""
            },
            notificationSystem: null,
            isEdit: false,
            allUsers: [],
            loading: true,
            isActive: true,
            isFirst: false,
            allRoles: [],
            getAllUserSuccess: true,
            userIdForEdit: "",
            allStores: [],
            currentUserStoreName: storeName,
            currentUserStoreId: userProfile.store.storeId.toString(),
            currentUserRole: userRole,
            loadingGetUsers: false,
            isFirstEdit: false
        }
    }

    handleClear = () => {
        let userConfigurationDetails = {
            storeId: this.state.currentUserStoreId,
            userName: "",
            emailAddress: "",
            password: "",
            role: "",
            firstName: "",
            lastName: ""
        };
        this.setState({userConfigurationDetails, isFirst: false, isEdit: false});
    };

    handleChange = (event) => {
        const field = event.target.name;
        let userConfigurationDetails = this.state.userConfigurationDetails;
        userConfigurationDetails[field] = event.target.value;
        return this.setState({userConfigurationDetails: userConfigurationDetails});
    };

    handleSelectChange = (event,{value}) => {
        let {userConfigurationDetails} = this.state;
        userConfigurationDetails.role = value;
        this.setState({userConfigurationDetails});
    };

    handleStore = (event, {value}) => {
        let {userConfigurationDetails} = this.state;
        if (userConfigurationDetails.storeId.toString() !== value.toString()) {
            this.getUserByStoreId(value);
        }
        userConfigurationDetails.storeId = value.toString();
        this.setState({userConfigurationDetails});
    };

    addNotification = (message, level) => {
        this.props.actions.StoreConfiguration.changeErrorValue();
        this.state.notificationSystem && this.state.notificationSystem.addNotification({
            message: message,
            level: level,
            autoDismiss: 5
        });
    };

    onChangeSwitch = (val) => {
        if (!this.state.isFirst) {
            this.setState({isActive: val})
        } else {
            this.setState({isFirst: false});
        }
    };

    getStoreName = (storeId) => {
        const {allStores} = this.state;
        let storeName = "";
        allStores.forEach(value => {
            if (value.storeId === parseInt(storeId)) {
                storeName = value.storeName
            }
        });
        return storeName;
    };

    checkValidation = () => {
        const {storeId, userName, emailAddress, password, role, firstName, lastName} = this.state.userConfigurationDetails;
        let emailRegEx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (storeId.trim() === "" || userName.trim() === "" || emailAddress.trim() === "" || (!this.state.isEdit && password.trim() === "") || role.trim() === "" || firstName.trim() === "" ||
            lastName.trim() === "") {
            this.addNotification("All field must be required", 'error');
        } else if (!Number.isInteger(parseInt(storeId))) {
            this.addNotification("storeId must be Integer", 'error');
        } else if (userName.length < 5 || userName.length > 30) {
            this.addNotification("User Name must be in between 5 to 30 character", 'error');
        } else if (!emailRegEx.test(emailAddress)) {
            this.addNotification("Invalid Email Address", 'error');
        } else {
            return true;
        }
    };

    handleEdit = (value) => {
        this.setState({isEdit: true, isFirstEdit: true});
        if (this.state.isActive !== value.isActive) {
            this.setState({isFirst: true});
        }
        const {userConfigurationDetails} = this.state;
        userConfigurationDetails.storeId = value.storeId.toString();
        userConfigurationDetails.userName = value.userName;
        userConfigurationDetails.emailAddress = value.emailAddress;
        userConfigurationDetails.role = value.roleName;
        userConfigurationDetails.firstName = value.firstName || "";
        userConfigurationDetails.lastName = value.lastName || "";
        this.setState({userConfigurationDetails, isActive: value.isActive, userIdForEdit: value.userId});
    };

    handleEditConfirm = () => {
        if (this.checkValidation()) {
            this.setState({loading: true});
            let {userConfigurationDetails, userIdForEdit} = this.state;
            if (userConfigurationDetails.password.trim() === "") {
                delete userConfigurationDetails.password;
            }
            userConfigurationDetails.isActive = this.state.isActive;
            this.props.actions.StoreConfiguration.editUser(userConfigurationDetails, userIdForEdit);
        }
    };

    handleSubmit = () => {
        if (this.checkValidation()) {
            this.setState({loading: true});
            let {userConfigurationDetails, isActive} = this.state;
            userConfigurationDetails.isActive = isActive;
            this.props.actions.StoreConfiguration.addStoreUser(userConfigurationDetails);
        }
    };

    componentWillMount() {
        this.state.currentUserRole === 1 && this.props.actions.StoreConfiguration.getAllStores();
        const userProfile = this.props.userProfile;
        const storeId = userProfile.store.storeId;
        this.getUserByStoreId(storeId);
        this.props.actions.StoreConfiguration.getAllRoles();
    }

    getUserByStoreId = (storeId) => {
        this.props.actions.StoreConfiguration.getAllStoreUser(storeId);
    };

    componentWillReceiveProps(nextProps) {
        if (nextProps.errorsGetRoles) {
            this.addNotification(nextProps.errorsGetRoles, 'error');
        }

        if (nextProps.isUserConfigSuccess) {
            this.addNotification("User Added Successfully", "success");
            let userConfigurationDetails = {
                storeId: this.state.userConfigurationDetails.storeId,
                firstName: "",
                lastName: "",
                userName: "",
                emailAddress: "",
                password: "",
                role: ""
            };
            this.setState({userConfigurationDetails});
        } else if (nextProps.errorsAddUser) {
            this.addNotification(nextProps.errorsAddUser, 'error');
        }
        if (this.props.loadingGetUsers && !nextProps.loadingGetUsers && !nextProps.getAllUserSuccess) {
            this.setState({allUsers: nextProps.allUsers});
        }
        if (this.state.isFirstEdit && nextProps.errorEditUser) {
            this.addNotification(nextProps.errorEditUser, 'error');
        }
        if (nextProps.errorGetAllUsers) {
            this.addNotification(nextProps.errorGetAllUsers, 'error');
        }
        if (this.state.isFirstEdit && nextProps.userEditedSuccess) {
            this.addNotification("User Updated Successfully", "success");
            let userConfigurationDetails = {
                storeId: this.state.userConfigurationDetails.storeId,
                firstName: "",
                lastName: "",
                userName: "",
                emailAddress: "",
                password: "",
                role: ""
            };
            this.setState({
                userConfigurationDetails,
                userIdForEdit: "",
                allUsers: nextProps.allUsers,
                isFirstEdit: false
            });
        }
        this.setState({
            loading: nextProps.loading,
            allRoles: nextProps.allRoles || [],
            getAllUserSuccess: nextProps.getAllUserSuccess,
            allStores: nextProps.allStores || [],
            loadingGetUsers: nextProps.loadingGetUsers
        });
    }

    componentDidMount() {
        this.setState({notificationSystem: this.refs.notificationSystem});
    };

    render() {
        const {storeId, userName, emailAddress, password = "", role, firstName, lastName} = this.state.userConfigurationDetails;
        const {allStores, allRoles, allUsers} = this.state;
        let options = [];
        let optionsRole = [];
        allStores && allStores.map((data) => {
            options.push({text: data.storeName, value: data.storeId.toString()})
        });
        allRoles && allRoles.map((data, index) => {
            optionsRole.push({text:data.roleName,value:data.roleName})
        });
        const sortedOptions = orderBy(options, ['text'], 'asc');
        let users = allUsers && allUsers.users || [];
        return (
            <div className="bg-burrito-image autofill-background store-user-config">
                <Header/>
                <NotificationSystem ref="notificationSystem"/>
                <div className="container tab-bg-container">
                    {this.state.currentUserRole === 1 && <div style={{marginTop: 10}}>
                        <Dropdown
                            options={sortedOptions}
                            placeholder='Choose Store'
                            search
                            selection
                            fluid
                            value={storeId}
                            onChange={this.handleStore}
                            style={{width: '69%', margin: '0 auto', borderRadius: '.28571429rem'}}
                        />
                    </div>
                    }
                    <div className="row">
                        <div className="form-wrapper col-sm-8 col-md-8 col-sm-offset-2 col-md-offset-2">
                            <h2 className="form-title">{this.state.isEdit ? "Update Store User" : "Register Store user"}</h2>
                            <form className="form-horizontal">
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="First Name"> <img
                                                    src="/assets/Images/username.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="firstName"
                                                       value={firstName}
                                                       placeholder="First Name" onChange={this.handleChange}/>
                                            </div>
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Last Name"> <img
                                                    src="/assets/Images/username.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="lastName"
                                                       value={lastName} placeholder="Last Name"
                                                       onChange={this.handleChange}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <span className="store-config-icon" title="User Name"> <img
                                            src="/assets/Images/username.png" alt=""/> </span>
                                        <input type="text" className="form-control" value={userName}
                                               name="userName" placeholder="User Name" onChange={this.handleChange}/>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <span className="store-config-icon" title="Email"> <img
                                            src="/assets/Images/email.png" alt=""/> </span>
                                        <input type="text" className="form-control" value={emailAddress}
                                               name="emailAddress" placeholder="Email" onChange={this.handleChange}/>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <span className="store-config-icon" title="Password"> <img
                                            src="/assets/Images/password.png" alt=""/> </span>
                                        <input type="password" className="form-control" value={password}
                                               name="password"
                                               placeholder={this.state.isEdit ? "Password,Leave it blank if you don't want to change" : "Password"}
                                               onChange={this.handleChange}/>
                                    </div>
                                </div>
                                <div className="form-group gmt-offset">
                                    <div className="col-sm-12 col-xs-12">
                                        <span className="icon1 col-sm-1 col-xs-1" title="Role">
                                         <img src="/assets/Images/user-role.png" width="25px" alt=""/>
                                        </span>
                                        <div className="col-sm-8 col-xs-7 role"
                                             style={{display: 'inline-block', padding: 0}}>
                                            {/*<select className="form-control" style={{padding: '5px 5px 5px 15px'}}*/}
                                                    {/*name="role" onChange={this.handleSelectChange} value={role}>*/}
                                                {/*<option value="">--Select Role--</option>*/}
                                                {/*{*/}
                                                    {/*allRoles && allRoles.map((data, index) => (*/}
                                                        {/*<option value={data.roleName}*/}
                                                                {/*key={index}>{data.roleName}</option>*/}
                                                    {/*))*/}
                                                {/*}*/}
                                            {/*</select>*/}
                                            <div className="store-config-zone store-user">
                                                <Dropdown
                                                    options={optionsRole}
                                                    placeholder='--Select Role--'
                                                    search
                                                    selection
                                                    fluid
                                                    value={role}
                                                    onChange={this.handleSelectChange}
                                                    style={{borderRadius: 0,background:'transparent',border:'#6f6f6f'}}
                                                />
                                            </div>
                                        </div>
                                        <div className="col-sm-2 col-md-3 col-xs-12 pr-0" style={{float:'right',width:'auto'}}>
                                            <Switch value={this.state.isActive}
                                                    circleStyles={{onColor: 'green', offColor: 'red', diameter: 25}}
                                                    labels={{on: 'Active', off: 'InActive'}} switchStyles={{width: 100}}
                                                    onChange={() => this.onChangeSwitch(!this.state.isActive)}/>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12 text-right button-div">
                                        {this.state.isEdit ?
                                            <a className="btn btn-save" onClick={this.handleEditConfirm}
                                               style={{cursor: 'pointer', marginRight: 10}}>Update User</a>
                                            : <a className="btn btn-save" onClick={this.handleSubmit}
                                                 style={{cursor: 'pointer', marginRight: 10}}>Register</a>}
                                        <a className="btn btn-save" onClick={this.handleClear}
                                           style={{cursor: 'pointer', float: 'right'}}>Clear</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    {users.length > 0 && <div className="data-display col-sm-12">
                        <div className="table-responsive overflow-scroll">
                            <table width="100%" className="table">
                                <tbody>
                                <tr>
                                    <th>Store Name</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>User Name</th>
                                    <th>Email</th>
                                    <th>User Role</th>
                                    <th>Active / Inactive</th>
                                    <th style={{textAlign: 'center'}}>Action</th>
                                </tr>
                                {users && users.map((value, index) => (
                                    <tr key={index}>
                                        <td>{this.state.currentUserRole === 1 ? this.getStoreName(value.storeId) : this.state.currentUserStoreName}</td>
                                        <td>{value.firstName}</td>
                                        <td>{value.lastName}</td>
                                        <td>{value.userName}</td>
                                        <td>{value.emailAddress}</td>
                                        <td>{value.roleName}</td>
                                        <td style={{textAlign: "center"}}>
                                            <Switch value={value.isActive}
                                                    circleStyles={{onColor: 'green', offColor: 'red', diameter: 25}}
                                                    labels={{on: 'Active', off: 'InActive'}} switchStyles={{width: 103}}
                                                    locked/>
                                        </td>
                                        <td style={{textAlign: "center"}}>
                                            <i title="Update User Configuration" className="fa fa-pencil-square-o"
                                               aria-hidden="true"
                                               style={{fontSize: 25, cursor: 'pointer'}}
                                               onClick={() => this.handleEdit(value)}/>
                                        </td>
                                    </tr>
                                ))
                                }
                                </tbody>
                            </table>
                        </div>
                    </div>
                    }
                </div>
                {(this.state.loading || this.state.getAllUserSuccess || this.state.loadingGetUsers) && <Loader/>}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const {storeConfigurationReducer, authReducer} = state;
    return {
        isUserConfigSuccess: storeConfigurationReducer.userConfigureSuccess,
        isStoreEditedSuccess: storeConfigurationReducer.storeEditedSuccess,
        errors: storeConfigurationReducer.errors,
        errorsEditing: storeConfigurationReducer.errorsEditing,
        errorsGetRoles: storeConfigurationReducer.errorsGetRoles,
        errorsAddUser: storeConfigurationReducer.errorsAddUser,
        loading: storeConfigurationReducer.loading,
        allStores: storeConfigurationReducer.allStores || [],
        allRoles: storeConfigurationReducer.allRoles || [],
        allUsers: storeConfigurationReducer.allUsers || [],
        getAllUserSuccess: storeConfigurationReducer.getAllUserSuccess,
        errorGetAllUsers: storeConfigurationReducer.errorGetAllUsers,
        errorEditUser: storeConfigurationReducer.errorEditUser,
        userEditedSuccess: storeConfigurationReducer.userEditedSuccess,
        loadingGetUsers: storeConfigurationReducer.loadingGetUsers,
        userProfile: authReducer.userProfile
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        StoreConfiguration: bindActionCreators(storeConfigurationAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(StoreUserConfiguration);
