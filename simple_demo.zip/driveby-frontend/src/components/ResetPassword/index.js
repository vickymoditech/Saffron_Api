import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import NotificationSystem from 'react-notification-system';
import {Link} from 'react-router';

import Loader from '../Helpers/Loader';
import * as authAction from '../../actions/authAction';
import './ResetPassword.css';

class ResetPassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            notificationSystem: null,
            forgotPassword: {
                newPassword: "",
                confirmPassword: ""
            },
            token: props.location.query.d,
            loading: false,
            isValid: false,
            isInvalidToken: props.location.query.d ? false : true,
            isTokenExpired: false,
            isPasswordAlreadyReset: false,
            userInfo: ""
        }
    }

    addNotification = (message, level) => {
        this.state.notificationSystem.addNotification({
            message: message,
            level: level,
            autoDismiss: 3
        });
    };

    handleChange = (event) => {
        const field = event.target.name;
        const forgotPassword = this.state.forgotPassword;
        forgotPassword[field] = event.target.value;
        return this.setState({forgotPassword: forgotPassword});
    };

    handleSubmit = (event) => {
        event.preventDefault();
        const {forgotPassword} = this.state;
        if (forgotPassword.newPassword.trim() === "" || forgotPassword.confirmPassword.trim() === "") {
            this.addNotification("newPassword and Email are must be required", "error");
        } else if (forgotPassword.newPassword.trim() !== forgotPassword.confirmPassword.trim()) {
            this.addNotification("New Password and Confirm Password mut be same", "error");
        } else {
            let resetPasswordData = {token: this.state.token, newPassword: this.state.forgotPassword.newPassword}
            this.setState({loading:true});
            this.props.actions.auth.resetPassword(resetPasswordData)
        }
    };

    componentWillMount() {
        if(!this.state.isInvalidToken ) {
            this.setState({loading:true});
            this.props.actions.auth.checkForgotPassword(this.state.token);
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({loading: nextProps.loading});
        if (nextProps.status === "ValidToken") {
            this.setState({isValid: true, userInfo: nextProps.userInfo});
        }
        if (nextProps.status === "InvalidToken") {
            this.setState({isInvalidToken: true});
        }
        if (nextProps.status === "TokenExpired") {
            this.setState({isTokenExpired: true});
        }
        if (nextProps.status === "PasswordAlreadyReset") {
            this.setState({isPasswordAlreadyReset: true, userInfo: nextProps.userInfo});
        }
        if (nextProps.resetPasswordStatus === "success") {
            this.setState({forgotPassword: {newPassword: "", confirmPassword: ""},isPasswordAlreadyReset:true,isValid:false});
            this.addNotification(nextProps.resetPasswordMessage, 'success');
        }
        if (nextProps.isErrorCheckPassword) {
            this.addNotification(nextProps.errorMsgCheckPassword, 'error');
        }
        if (nextProps.isErrorResetPassword) {
            this.addNotification(nextProps.errorMsgResetPassword, 'error');
        }
    }

    componentDidMount() {
        this.setState({notificationSystem: this.refs.notificationSystem});
    };

    render() {
        const {userInfo} = this.state;
        return (
            <div className="vertical-alignment-helper reset-password">
                <NotificationSystem ref="notificationSystem"/>
                <div className="modal-dialog vertical-align-center">
                    <div className="modal-content">
                        <a href="javascript:void(0);" className="logo"></a>
                        <div className="modal-body">
                            {this.state.isValid && <div className="row login-form">
                                <div className="col-xs-12 text-center">
                                    <h5>Hi <span> <strong> {userInfo && userInfo.firstName}, </strong> </span></h5>
                                    <h4>Reset your password from here!</h4>
                                </div>
                                <div className="panel-body col-xs-12" style={{marginTop: 5}}>
                                    <div className="row">
                                        <div className="col-md-offset-1 col-md-10">
                                            <form>
                                                <div id="loginForm">
                                                    <div className="form-group">
                                                        <div className="input-group">
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-unlock" title="New Password"/>
                                                        </span>
                                                            <input type="password"
                                                                   value={this.state.forgotPassword.newPassword}
                                                                   name="newPassword" placeholder="New Password"
                                                                   className="form-control"
                                                                   onChange={this.handleChange}/>
                                                        </div>
                                                    </div>
                                                    <div className="form-group">
                                                        <div className="input-group">
                                                        <span className="input-group-addon">
                                                            <i className="fa fa-lock" title="Confirm Password"/></span>
                                                            <input type="password"
                                                                   value={this.state.forgotPassword.confirmPassword}
                                                                   name="confirmPassword" placeholder="Confirm Password"
                                                                   className="form-control"
                                                                   onChange={this.handleChange}/>
                                                        </div>
                                                        <div className="form-group text-center row">
                                                            <div className="col-xs-12 text-center">
                                                            </div>
                                                            <button type="submit" className="btn btn-save"
                                                                    onClick={this.handleSubmit}>Reset Password
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div className="back-login text-center">
                                                <Link to="/login" style={{textDecoration: 'underline'}}>Back to Login</Link>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>}
                            {this.state.isPasswordAlreadyReset && <div>
                                <div className="row login-form">
                                    <div className="col-xs-12 text-center">
                                        <h5>Hi <span> <strong> {userInfo && userInfo.firstName}, </strong> </span></h5>
                                        <h2 style={{color: '#000'}}>Your password has been reset!</h2>
                                        <p>To signIn with your new password use the link below</p>
                                        <Link to="/login" style={{textDecoration: 'underline'}}>Back to Login</Link>
                                    </div>
                                </div>
                            </div>
                            }

                             {this.state.isInvalidToken &&
                             <div className="row login-form">
                            <div className="col-xs-12 text-center">
                                <h2 style={{color: '#f00'}}>Oops!</h2>
                                <p>Data not found to process your request. Please contact system administrator.</p>
                                <p>Use the link below to get started</p>
                                <Link to="/login" style={{textDecoration: 'underline'}}>Back to Login</Link>
                            </div>
                             </div>
                            }
                            {this.state.isTokenExpired && <div className="row login-form">
                                <div className="col-xs-12 text-center"><h5>Hi <span> <strong> {userInfo && userInfo.firstName}, </strong> </span></h5>
                                    <h2 style={{color: '#000'}}>Password reset link has been expired.</h2>
                                    <p>
                                        If you wish to reset password,
                                        <br />
                                        use the link below to get  started.
                                    </p>
                                    <Link to="/login" style={{textDecoration: 'underline'}}>Back to Login</Link>
                                </div>
                            </div>
                            }
                        </div>
                    </div>
                </div>
                {this.state.loading && <Loader/>}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const {authReducer} = state;
    return {
        loading: authReducer.loading,
        status: authReducer.status,
        message: authReducer.message,
        userInfo: authReducer.userInfo,
        resetPasswordStatus: authReducer.resetPasswordStatus,
        resetPasswordMessage: authReducer.resetPasswordMessage,
        isErrorCheckPassword: authReducer.isErrorCheckPassword,
        errorMsgCheckPassword: authReducer.errorMsgCheckPassword,
        isErrorResetPassword: authReducer.isErrorResetPassword,
        errorMsgResetPassword: authReducer.errorMsgResetPassword
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        auth: bindActionCreators(authAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword)