import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import NotificationSystem from 'react-notification-system';
import Switch from 'react-flexible-switch';
import {Dropdown} from 'semantic-ui-react'

import * as storeConfigurationAction from '../../actions/storeConfigurationAction';
import Loader from '../Helpers/Loader';
import Header from "../Helpers/Header/index";
import StoreDetails from './StoreDetails';
import './store-configuration.css';

const initState = {
    storeConfigurationDetails: {
        storeId: "",
        storeName: "",
        latitude: "",
        longitude: "",
        deliveryZone: {
            type: "",
            radiusInMeter: "",
            polygon: []
        },
        gmtOffset: "",
        wideGeofenceInMeters: "",
        frequencyInsideInSecs: "",
        frequencyOutsideInSecs: "",
        leanplumAttribute: "",
        throttle: ""
    }
};

class StoreConfiguration extends Component {
    constructor(props) {
        super(props);
        this.state = {
            storeConfigurationDetails: {...initState.storeConfigurationDetails},
            notificationSystem: null,
            isEdit: false,
            allStores: [],
            loading: true,
            differenceStamp: "plus",
            isActive: true,
            availability: true,
            isFirst: false,
            isFirstAvailability: false,
            isStoreDetailsOpen:false,
            storeDetails:[]
        }
    }

    handleClear = () => {
        let storeConfigurationDetails = {
            storeId: "",
            storeName: "",
            latitude: "",
            longitude: "",
            deliveryZone: {
                type: "",
                radiusInMeter: "",
                polygon: []
            },
            gmtOffset: "",
            wideGeofenceInMeters: "",
            frequencyInsideInSecs: "",
            frequencyOutsideInSecs: "",

            leanplumAttribute: "",
            throttle: ""
        };

        this.setState({
            storeConfigurationDetails,
            isEdit: false,
            differenceStamp: "plus",
            isFirst: false,
            isFirstAvailability: false
        },() => {
            // !this.state.availability && this.setState({availability:true});
        });
    };

    handleChange = (event) => {
        const field = event.target.name;
        let storeConfigurationDetails = this.state.storeConfigurationDetails;
        if (field === "type" || field === "radiusInMeter") {
            storeConfigurationDetails['deliveryZone'][field] = event.target.value;
        } else storeConfigurationDetails[field] = event.target.value;
        return this.setState({storeConfigurationDetails: storeConfigurationDetails});
    };

    handleSelectChange = (event) => {
        let val = event.target.value;
        this.setState({differenceStamp: val});
    };

    handleDeliveryZone = (event, {value}) => {
        let {storeConfigurationDetails} = this.state;
        storeConfigurationDetails.deliveryZone.type = value;
        this.setState({storeConfigurationDetails});
    };

    handleOrderDetails = (value) => {
        this.setState({isStoreDetailsOpen:true,storeDetails:value})
    };

    handleClose = () => {
        this.setState({isStoreDetailsOpen:false,storeDetails:[]})
    };

    addNotification = (message, level) => {
        this.props.actions.StoreConfiguration.changeErrorValue();
        this.state.notificationSystem.addNotification({
            message: message,
            level: level,
            autoDismiss: 5
        });
    };

    onChangeSwitch = (val) => {
        if (!this.state.isFirst) {
            this.setState({isActive: val})
        } else {
            this.setState({isFirst: false});
        }
    };

    onChangeSwitchAvailability = (val) => {
        if (!this.state.isFirstAvailability) {
            this.setState({availability: val});
        } else {
            this.setState({isFirstAvailability: false});
        }
    };

    checkValidation = () => {
        const {storeId, storeName, latitude, longitude, deliveryZone, gmtOffset, wideGeofenceInMeters, frequencyInsideInSecs, frequencyOutsideInSecs, leanplumAttribute, throttle} = this.state.storeConfigurationDetails;
        if (storeId.trim() === "" || storeName.trim() === "" || latitude.trim() === "" || longitude.trim() === "" || deliveryZone.radiusInMeter.trim() === ""
            || deliveryZone.type.trim() === "" || gmtOffset.trim() === "" || wideGeofenceInMeters.trim() === "" || frequencyInsideInSecs.trim() === ""
            || frequencyOutsideInSecs.trim() === "" || throttle.trim() === "") {
            this.addNotification("All field must be required", 'error');
        } else if (!Number.isInteger(parseInt(storeId))) {
            this.addNotification("storeId must be Integer", 'error');
        } else if (storeName.length > 100) {
            this.addNotification("Store Name must be less than 100 character", 'error');
        } else if (!Number.parseFloat(latitude)) {
            this.addNotification("Latitude must be an Decimal number", 'error');
        } else if (!Number.parseFloat(longitude)) {
            this.addNotification("Longitude must be an Decimal number", 'error');
        } else if (!Number.isInteger(parseInt(wideGeofenceInMeters))) {
            this.addNotification("Wide Geofence must be Integer", "error");
        } else if (!Number.isInteger(parseInt(frequencyInsideInSecs))) {
            this.addNotification("Wide Frequency Inside must be Integer", "error");
        } else if (!Number.isInteger(parseInt(frequencyOutsideInSecs))) {
            this.addNotification("Wide Frequency Outside must be Integer", "error");
        } else if (!Number.isInteger(parseInt(deliveryZone.radiusInMeter))) {
            this.addNotification("Radius must be Integer", 'error');
        } else if (!Number.isInteger(parseInt(gmtOffset)) || parseInt(gmtOffset) < 0 || parseInt(gmtOffset) > 9999) {
            this.addNotification("GMTOffset must be 4 digit Integer number", 'error');
        } else if (!Number.isInteger(parseInt(throttle))) {
            this.addNotification("Throttle Rate must be Integer", 'error');
        } else {
            return true;
        }
    };

    handleEdit = (value) => {
        value.availability = value.availability || false;
        this.setState({isEdit: true});
        if (this.state.availability !== value.availability) {
            this.setState({isFirstAvailability: true});
        }
        const {storeConfigurationDetails} = this.state;
        storeConfigurationDetails.storeId = value.storeId.toString();
        storeConfigurationDetails.storeName = value.storeName;
        storeConfigurationDetails.latitude = value.latitude;
        storeConfigurationDetails.longitude = value.longitude;
        storeConfigurationDetails.wideGeofenceInMeters = (value.wideGeofenceInMeters && value.wideGeofenceInMeters.toString()) || "";
        storeConfigurationDetails.frequencyInsideInSecs = (value.frequencyInsideInSecs && value.frequencyInsideInSecs.toString()) || "";
        storeConfigurationDetails.frequencyOutsideInSecs = (value.frequencyOutsideInSecs && value.frequencyOutsideInSecs.toString()) || "";
        storeConfigurationDetails.deliveryZone.type = value.deliveryZone.type;
        storeConfigurationDetails.deliveryZone.radiusInMeter = value.deliveryZone.radiusInMeter.toString();
        storeConfigurationDetails.gmtOffset = value.gmtOffset.substr(1).toString();
        storeConfigurationDetails.leanplumAttribute = value.leanplumAttribute || "";
        storeConfigurationDetails.throttle = value.throttle && value.throttle.toString() || "";
        let timeStamp;
        if (value.gmtOffset.substr(0, 1) === "+") {
            timeStamp = "plus"
        } else timeStamp = "minus";
        this.setState({
            storeConfigurationDetails,
            differenceStamp: timeStamp,
            availability: value.availability || false
        });
    };

    handleEditConfirm = () => {
        const {gmtOffset} = this.state.storeConfigurationDetails;
        const {differenceStamp} = this.state;
        if (this.checkValidation()) {
            this.setState({loading: true});
            let {storeConfigurationDetails} = this.state;
            if (differenceStamp === "plus") {
                storeConfigurationDetails.gmtOffset = "+".concat(gmtOffset);
            } else storeConfigurationDetails.gmtOffset = "-".concat(gmtOffset);
            // storeConfigurationDetails.isActive = this.state.isActive;
            storeConfigurationDetails.availability = this.state.availability;
            this.props.actions.StoreConfiguration.editStore(storeConfigurationDetails);
        }
    };

    handleSubmit = () => {
        const {gmtOffset} = this.state.storeConfigurationDetails;
        const {differenceStamp} = this.state;
        if (this.checkValidation()) {
            this.setState({loading: true});
            let {storeConfigurationDetails} = this.state;
            if (differenceStamp === "plus") {
                storeConfigurationDetails.gmtOffset = "+".concat(gmtOffset);
            } else storeConfigurationDetails.gmtOffset = "-".concat(gmtOffset);
            // storeConfigurationDetails.isActive = this.state.isActive;
            storeConfigurationDetails.availability = this.state.availability;
            this.props.actions.StoreConfiguration.addStore(storeConfigurationDetails);
        }
    };

    componentWillMount() {
        this.props.actions.StoreConfiguration.getAllStores();
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.isStoreConfigSuccess) {
            this.addNotification("Store Configure Successfully", 'success');
            let storeConfigurationDetails = {
                storeId: "",
                storeName: "",
                latitude: "",
                longitude: "",
                deliveryZone: {
                    type: "",
                    radiusInMeter: "",
                    polygon: []
                },
                gmtOffset: "",
                wideGeofenceInMeters: "",
                frequencyInsideInSecs: "",
                frequencyOutsideInSecs: "",
                leanplumAttribute: "",
                throttle: ""
            };
            this.setState({storeConfigurationDetails, differenceStamp: "plus"});
        } else if (nextProps.errors) {
            this.addNotification(nextProps.errors, 'error');
        }
        if (nextProps.isStoreEditedSuccess) {
            let storeConfigurationDetails = {
                storeId: "",
                storeName: "",
                latitude: "",
                longitude: "",
                deliveryZone: {
                    type: "",
                    radiusInMeter: "",
                    polygon: []
                },
                gmtOffset: "",
                wideGeofenceInMeters: "",
                frequencyInsideInSecs: "",
                frequencyOutsideInSecs: "",
                leanplumAttribute: "",
                throttle: ""
            };
            this.setState({storeConfigurationDetails, isEdit: false, differenceStamp: "plus"});
            this.addNotification("Store Updated Successfully", 'success');
        } else if (nextProps.errorsEditing) {
            this.setState({isEdit: false});
            this.addNotification(nextProps.errorsEditing, 'error');
        }
        this.setState({loading: nextProps.loading, allStores: nextProps.allStores || []});
    }

    componentDidMount() {
        this.setState({notificationSystem: this.refs.notificationSystem});
    };

    render() {
        const {storeId, storeName, latitude, longitude, deliveryZone, gmtOffset, wideGeofenceInMeters, frequencyInsideInSecs, frequencyOutsideInSecs, leanplumAttribute, throttle} = this.state.storeConfigurationDetails;
        const {allStores} = this.state;
        return (
            <div className="bg-burrito-image autofill-background">
                <Header/>
                <NotificationSystem ref="notificationSystem"/>
                {this.state.isStoreDetailsOpen && <StoreDetails handleClose={this.handleClose} storeDetail={this.state.storeDetails}/>}
                <div className="container tab-bg-container">
                    <div className="row">
                        <div className="form-wrapper col-sm-8 col-md-8 col-sm-offset-2 col-md-offset-2">
                            <h2 className="form-title">Store Configuration</h2>
                            <form className="form-horizontal">
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <span className="store-config-icon" title="Store Id"> <img src="/assets/Images/store-id-y.png"
                                                                                  alt=""/> </span>
                                        <input type="text" className="form-control" value={storeId}
                                               name="storeId" placeholder="Store ID" readOnly={this.state.isEdit}
                                               onChange={this.handleChange}/>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <span className="store-config-icon" title="Store Name"> <img src="/assets/Images/store-name-y.png"
                                                                                  alt=""/> </span>
                                        <input type="text" className="form-control" value={storeName}
                                               name="storeName" placeholder="Store Name" onChange={this.handleChange}/>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Latitude"> <img
                                                    src="/assets/Images/latitude-y.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="latitude"
                                                       value={latitude}
                                                       placeholder="Latitude" onChange={this.handleChange}/>
                                            </div>
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Longitude"> <img
                                                    src="/assets/Images/latitude-y.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="longitude"
                                                       value={longitude} placeholder="Longitude"
                                                       onChange={this.handleChange}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <span className="store-config-icon" title="Wide Geofence(In Meters)"> <img src="/assets/Images/distance.png"
                                                                                  alt=""/> </span>
                                        <input type="text" className="form-control" value={wideGeofenceInMeters}
                                               name="wideGeofenceInMeters" placeholder="Wide Geofence(In Meters)"
                                               onChange={this.handleChange}/>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Frequency Inside(In Seconds)"> <img
                                                    src="/assets/Images/frequency.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="frequencyInsideInSecs"
                                                       value={frequencyInsideInSecs}
                                                       placeholder="Frequency Inside(In Seconds)"
                                                       onChange={this.handleChange}/>
                                            </div>
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Frequency Outside(In Seconds)"> <img
                                                    src="/assets/Images/frequency.png" alt=""/> </span>
                                                <input type="text" className="form-control"
                                                       name="frequencyOutsideInSecs"
                                                       value={frequencyOutsideInSecs}
                                                       placeholder="Frequency Outside(In Seconds)"
                                                       onChange={this.handleChange}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Delivery Zone Type"> <img
                                                    src="/assets/Images/zone-type-y.png" alt=""/> </span>
                                                <div className="store-config-zone">
                                                    <Dropdown
                                                        options={[{text:"Radius",value:"radius"}]}
                                                        placeholder='--Select Delivery Zone Type--'
                                                        search
                                                        selection
                                                        fluid
                                                        value={deliveryZone.type}
                                                        onChange={this.handleDeliveryZone}
                                                        style={{borderRadius: 0,background:'transparent',border:'#6f6f6f'}}
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Radius"> <img
                                                    src="/assets/Images/radius-meter-y.png" alt=""/> </span>
                                                <input type="text" className="form-control"
                                                       value={deliveryZone.radiusInMeter}
                                                       name="radiusInMeter" placeholder="Radius in Meter"
                                                       onChange={this.handleChange}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group gmt-offset">
                                    <div className="col-sm-12 col-md-12 col-xs-12">
                                        <span className="icon1 col-sm-1 col-xs-1 col-md-1" title="GMT offset">
                                         <img src="/assets/Images/gmt-y.png" width="25px"/>
                                        </span>
                                        <div className="col-sm-1 col-md-1 col-xs-3 gmt"
                                             style={{display: 'inline-block', padding: 0}}>
                                            <select className="form-control" style={{padding: '5px 5px 5px 15px'}}
                                                    name="diffTimeStamp" onChange={this.handleSelectChange}
                                                    value={this.state.differenceStamp}>
                                                <option value="plus">+</option>
                                                <option value="minus">-</option>
                                            </select>
                                        </div>
                                        <div className="col-sm-6 col-md-4 col-xs-7 input">
                                            <input type="text" className="form-control" value={gmtOffset}
                                                   name="gmtOffset" placeholder="GMT Offset"
                                                   style={{padding: '6px 12px',width: '241px'}} onChange={this.handleChange}/>
                                        </div>
                                        <div className="col-sm-2 col-md-3 col-xs-12 availability pr-0" style={{float:'right'}}>
                                            <Switch value={this.state.availability}
                                                    circleStyles={{onColor: 'green', offColor: 'red', diameter: 25}}
                                                    labels={{on: 'DriveBy Enable', off: 'DriveBy Disable'}}

                                                    onChange={() => this.onChangeSwitchAvailability(!this.state.availability)}/>
                                        </div>
                                    </div>
                                </div>

                                <div className="form-group">
                                    <div className="col-sm-12">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Lean Plum variable"> <img
                                                    src="/assets/Images/input.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="leanplumAttribute"
                                                       value={leanplumAttribute}
                                                       placeholder="Lean Plum Variable" onChange={this.handleChange}/>
                                            </div>
                                            <div className="col-sm-6">
                                                <span className="store-config-icon" title="Throttle Rate"> <img
                                                    src="/assets/Images/input.png" alt=""/> </span>
                                                <input type="text" className="form-control" name="throttle"
                                                       value={throttle} placeholder="Throttle Rate"
                                                       onChange={this.handleChange}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="form-group button-div">
                                    <div className="col-sm-12 col-xs-12 col-md-12 text-right">
                                        {this.state.isEdit ?
                                            <a className="btn btn-save" onClick={this.handleEditConfirm}
                                               style={{cursor: 'pointer', marginRight: 10}}>Edit Configuration</a>
                                            : <a className="btn btn-save" onClick={this.handleSubmit}
                                                 style={{cursor: 'pointer'}}>Add Configuration</a>}
                                        <a className="btn btn-clear btn-save" onClick={this.handleClear}
                                           style={{cursor: 'pointer'}}>Clear</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    {allStores.length && <div className="data-display col-sm-12">
                        <div className="table-responsive overflow-scroll">
                            <table width="100%" className="table">
                                <tbody>
                                <tr>
                                    <th>Store ID</th>
                                    <th>Store Name</th>
                                    <th>Latitude</th>
                                    <th>Longitude</th>
                                    {/*<th>Zone Type</th>*/}
                                    {/*<th>Radius in Meter</th>*/}
                                    {/*<th>Wide Geofence in meters</th>*/}
                                    {/*<th>Frequency Outside in seconds</th>*/}
                                    {/*<th>Frequency Inside in seconds</th>*/}
                                    <th>GMT Offset</th>
                                    <th>Lean Plum Variable</th>
                                    <th>Throttle Rate</th>
                                    <th>Availability</th>
                                    <th style={{textAlign: 'center'}}>Action</th>
                                    <th>Details</th>
                                </tr>
                                {allStores && allStores.map((value, index) => (
                                    <tr key={index}>
                                        <td>{value.storeId}</td>
                                        <td>{value.storeName}</td>
                                        <td>{value.latitude}</td>
                                        <td>{value.longitude}</td>
                                        {/*<td>{value.deliveryZone.type}</td>*/}
                                        {/*<td>{value.deliveryZone.radiusInMeter}</td>*/}
                                        {/*<td>{value.wideGeofenceInMeters || ""}</td>*/}
                                        {/*<td>{value.frequencyOutsideInSecs || ""}</td>*/}
                                        {/*<td>{value.frequencyInsideInSecs || ""}</td>*/}
                                        <td>{value.gmtOffset}</td>
                                        <td>{value.leanplumAttribute}</td>
                                        <td>{value.throttle}</td>
                                        <td style={{textAlign: "center"}}>
                                            <Switch value={value.availability || false}
                                                    circleStyles={{onColor: 'green', offColor: 'red', diameter: 25}}
                                                    labels={{on: 'Enable', off: 'Disable'}}
                                                    switchStyles={{width: 95}}
                                                    locked/>
                                        </td>
                                        <td style={{textAlign: "center"}}>
                                            <i className="fa fa-pencil-square-o" aria-hidden="true"
                                               style={{fontSize: 25, cursor: 'pointer'}}
                                               onClick={() => this.handleEdit(value)} title="Edit Store Configuration Details"/>
                                        </td>
                                        <td style={{textAlign: "center"}}>
                                            <i className="fa fa-list-alt" aria-hidden="true"
                                               style={{fontSize: 25, cursor: 'pointer'}}
                                               onClick={() => this.handleOrderDetails(value)} title="Edit Store Configuration Details"/>
                                        </td>
                                    </tr>
                                ))
                                }
                                </tbody>
                            </table>
                        </div>
                    </div>
                    }
                </div>
                {this.state.loading && <Loader/>}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const {storeConfigurationReducer} = state;
    return {
        isStoreConfigSuccess: storeConfigurationReducer.storeConfigSuccess,
        isStoreEditedSuccess: storeConfigurationReducer.storeEditedSuccess,
        errors: storeConfigurationReducer.errors,
        errorsEditing: storeConfigurationReducer.errorsEditing,
        loading: storeConfigurationReducer.loading,
        allStores: storeConfigurationReducer.allStores || []
    }
};

const mapDispatchToProps = dispatch => ({
    actions: {
        StoreConfiguration: bindActionCreators(storeConfigurationAction, dispatch)
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(StoreConfiguration);