import React, {Component} from 'react';
import {Dialog} from 'material-ui';
import Switch from 'react-flexible-switch';

import './store-configuration.css';

export default class StoreDetails extends Component {
    constructor(props){
        super(props);
    }
    render(){
        const {storeDetail} = this.props;
        return(
            <div className="store-info">
                <Dialog
                    modal={false}
                    open={true}
                    paperClassName="store-info-content"
                    onRequestClose={this.props.handleClose}
                >
                    <span className="close-btn btn-cross" onClick={this.props.handleClose}>+</span>
                    <div className="title-head">
                    <h5>Store Configuration Detail</h5>
                    </div>
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="border">
                            StoreId : {storeDetail.storeId}
                        </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="border">
                            Store Name : {storeDetail.storeName}
                        </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="border">
                            Latitude : {storeDetail.latitude}
                             </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="border">
                            Longitude : {storeDetail.longitude}
                             </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="border">
                            Zone Type : {storeDetail.deliveryZone.type}
                            </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="border">
                            Radius In Meters : {storeDetail.deliveryZone.radiusInMeter}
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="border">
                            Wide Geofence In Meters : {storeDetail.wideGeofenceInMeters || ""}
                             </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="border">
                            Frequency Outside In Seconds : {storeDetail.frequencyOutsideInSecs || ""}
                             </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="border">
                            Frequency Inside In Seconds : {storeDetail.frequencyInsideInSecs || ""}
                            </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="border">
                            GMT Offset : {storeDetail.gmtOffset}
                            </div>
                        </div>
                        </div>
                    <div className="row">
                        <div className="col-sm-6">
                            <div className="border">
                           Availability:  {storeDetail.availability ? "True" : "False"}
                            </div>
                        </div>
                        <div className="col-sm-6">
                            <div className="border">
                            Lean Plum Variable : {storeDetail.leanplumAttribute || '--'}
                            </div>
                        </div>
                        </div>
                    <div className="row">
                    <div className="col-sm-12">
                        <div className="border">
                        Throttle Rate : {storeDetail.throttle || '--'}
                        </div>
                    </div>
                    </div>
                </Dialog>
            </div>
        )
    }
}
