import axios from 'axios';
import ENVIRONMENT_VARIABLES from '../environment.config';
import {
    IS_AUTHENTICATED,
    INVALID_USER,
    UNAUTHORIZED_USER,
    AUTHENTICATION_INPROGRESS,
    PASSWORD_CHANGE_SUCCESS,
    PASSWORD_CHANGE_NOT_SUCCESS,
    STORE_USER_AVATAR_UPLOAD_SUCCESS,
    FORGOT_PASSWORD_SUCCESS,
    FORGOT_PASSWORD_START,
    FORGOT_PASSWORD_ERROR,
    FORGOT_PASSWORD_COMPLETE,
    ERROR_UPLOAD_USER_AVATAR,
    CHECK_FORGOT_PASSWORD_SUCCESS,
    CHECK_FORGOT_PASSWORD_ERROR,
    RESET_PASSWORD_SUCCESS,
    RESET_PASSWORD_ERROR
} from '../constants/actionTypes';
// import GyGLog from '../Logging/GyGLog';

export const loginUser = (credentials) => {
    try{
        return (dispatch) => {
            const loginDetails = {
                "userName": credentials.email,
                "password": credentials.password
            };
            dispatch({type: AUTHENTICATION_INPROGRESS});
            axios.post(ENVIRONMENT_VARIABLES.API_URL + "/dds/login", loginDetails).then((response) => {
                if (response.status === 200) {
                    dispatch({
                        type: IS_AUTHENTICATED,
                        data: {accessToken: response.data.accessToken, userProfile: response.data.userProfile}
                    });
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: INVALID_USER, data: {error_msg: error.response.data.user_msg}});
                }
            });
        }
    }catch(error){
        // GyGLog.writeLog(GyGLog.eLogLevel.debug,"","Auth Action loginuser : " + error.message);
    }

};

export const loggedOut = () => {
    try{
        return (dispatch) => {
            localStorage.removeItem("accessToken");
            localStorage.removeItem("userProfile");
            dispatch({type: UNAUTHORIZED_USER});
        }
    }catch (error){
        // GyGLog.writeLog(GyGLog.eLogLevel.debug,"","Auth Action loggedout : " + error.message);
    }
};

export const changePassword = (changePasswordData) => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const changePasswordDetail = {
                "oldPassword": changePasswordData.currentPassword,
                "newPassword": changePasswordData.newPassword
            };
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/changePassword",
                data: changePasswordDetail,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: PASSWORD_CHANGE_SUCCESS, data: response.data});
                }
            }).catch((error) => {
                if (error.response.status === 400) {
                    dispatch({type: PASSWORD_CHANGE_NOT_SUCCESS, data: error.response.data});
                }
            });
        }
    }catch (error){
        // GyGLog.writeLog(GyGLog.eLogLevel.debug,"","Auth Action changePassword : " + error.message);
    }
};

export const uploadStoreUserAvatar = (fileToUpload) => {
    try{
        return (dispatch) => {
            let data = new FormData();
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const userProfile = JSON.parse(localStorage.getItem('userProfile'));
            data.append('storeUserAvatar', fileToUpload);
            data.append('userId', userProfile.userId);
            axios.post(ENVIRONMENT_VARIABLES.API_URL + "/dds/storeUserAvatar", data, {headers: {'Authorization': token}}).then((response) => {
                if (response.status === 200) {
                    dispatch({type: STORE_USER_AVATAR_UPLOAD_SUCCESS, data: response.data});
                }
            }).catch((error) => {
                dispatch({type:ERROR_UPLOAD_USER_AVATAR})
            });
        };
    }catch(error){
        // GyGLog.writeLog(GyGLog.eLogLevel.debug,"","Auth Action uploadStoreUserAvatar : " + error.message);
    }
};

export const sendMail = (forgotPassword) => {
    try{
        return (dispatch) => {
            dispatch({type:FORGOT_PASSWORD_START});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/forgotPassword",
                data: forgotPassword,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: FORGOT_PASSWORD_SUCCESS, data: {success: true,success_msg:response.data.message}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: FORGOT_PASSWORD_ERROR, data:{is_Error:true,error_msg:error.response.data.user_msg}});
                }
            });
        }
    }catch (error){
    }
};

export const checkForgotPassword = (token) => {
    try{
        return (dispatch) => {
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/checkResetPassword",
                data: {token:token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: CHECK_FORGOT_PASSWORD_SUCCESS, data: {status: response.data.status,message:response.data.message,userInfo:response.data.data}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: CHECK_FORGOT_PASSWORD_ERROR, data:{isErrorCheckPassword:true,errorMsgCheckPassword:error.response.data.user_msg}});
                }
            });
        }
    }catch (error){

    }
};

export const resetPassword = (resetPasswordData) => {
    try{
        return (dispatch) => {
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/resetPassword",
                data: {token:resetPasswordData.token,newPassword:resetPasswordData.newPassword}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: RESET_PASSWORD_SUCCESS, data: {status: response.data.status,message:response.data.message}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: RESET_PASSWORD_ERROR, data:{isErrorResetPassword:true,errorMsgResetPassword:error.response.data.user_msg}});
                }
            });
        }
    }catch (error){

    }
};