import axios from 'axios';

import ENVIRONMENT_VARIABLES from '../environment.config';
import {
    STORE_CONFIGURE_SUCCESS,
    ERROR_CONFIGURE_STORE,
    LOADING_ALL_STORES,
    GET_ALL_STORES,
    STORE_EDITED_SUCCESS,
    ERROR_EDITED_STORE,
    USER_CONFIGURE_SUCCESS,
    ERROR_USER_CONFIGURE_STORE,
    GET_ALL_USER_ROLES,
    ERROR_GET_USER_ROLES,
    GET_ALL_USERS,
    USER_EDITED_SUCCESS,
    ERROR_EDITING_USER,
    ERROR_GET_ALL_USERS,
    LOADING_USER,
    CHANGE_VALUE_ERROR
} from '../constants/actionTypes';
import {GyGLog} from '../Logging/GyGLog';

export const addStore = (storeConfigurationDetails) => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/storeConfig",
                data: storeConfigurationDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: STORE_CONFIGURE_SUCCESS, data: {newRecord: response.data}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: ERROR_CONFIGURE_STORE, data: error.response.data});
                }
            });
        }
    }catch(error){
        GyGLog('debug','DDS Log Store Configuration Action addStore'+error);
    }
};

export const editStore = (storeConfigurationDetails) => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/storeConfig",
                data: storeConfigurationDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: STORE_EDITED_SUCCESS, data: {editedRecord: response.data}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: ERROR_EDITED_STORE, data: error.response.data});
                }
            });
        }
    }catch(error){
        GyGLog('debug','DDS Log Store Configuration Action editStore'+error);
    }

};

export const getAllStores = () => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            // dispatch({type: LOADING_ALL_STORES, data: {loading: true}});
            axios.get(ENVIRONMENT_VARIABLES.API_URL + "/dds/getStores", {headers: {'Authorization': token}}).then((response) => {
                dispatch({type: GET_ALL_STORES, data: {allStores: response.data, loading: false}});
            }).catch((error) => {
                dispatch({type: LOADING_ALL_STORES, data: {loading: false}});
                if (error.message === "Network Error") {
                    // dispatch({type: NETWORK_ERROR});
                }
                else if ((error.response && error.response.status === 401) || (error.response && error.response.status === 403)) {
                    // dispatch({type: UNAUTHORIZED_USER});
                } else if (error.response && error.response.status === 404) {
                    // dispatch({type: NOT_FOUND})
                }
            });
        }
    }catch (error){
        GyGLog('debug','DDS Log Store Configuration Action getAllStores'+error);
    }
};

export const getAllRoles = () => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            dispatch({type: LOADING_ALL_STORES, data: {loading: true}});
            axios.get(ENVIRONMENT_VARIABLES.API_URL + "/dds/getStoreUserRoles", {headers: {'Authorization': token}}).then((response) => {
                dispatch({type: GET_ALL_USER_ROLES, data: {allRoles: response.data, loading: false}});
            }).catch((error) => {
                dispatch({type: LOADING_ALL_STORES, data: {loading: false}});
                if(error.response){
                    dispatch({type: ERROR_GET_USER_ROLES, data: error.response.data});
                }
            });
        }
    }catch (error){
        GyGLog('debug','DDS Log Store Configuration Action getAllRoles'+error);
    }
};

export const addStoreUser = (userConfigDetails) => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/registerUser",
                data: userConfigDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: USER_CONFIGURE_SUCCESS, data: {newRecord: response.data}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: ERROR_USER_CONFIGURE_STORE, data: error.response.data});
                }
            });
        }
    }catch (error){
        GyGLog('debug','DDS Log Store Configuration Action addStoreUser'+error);
    }
};

export const editUser = (userConfigDetails,userId) => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'PUT',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/updateUser/"+userId,
                data: userConfigDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                if (response.status === 200) {
                    dispatch({type: USER_EDITED_SUCCESS, data: {editedRecord: response.data}});
                }
            }).catch((error) => {
                if (error.response) {
                    dispatch({type: ERROR_EDITING_USER, data: error.response.data});
                }
            });
        }
    }catch (error){
        GyGLog('debug','DDS Log Store Configuration Action editUser'+error);
    }
};

export const getAllStoreUser = (storeId) => {
    try{
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            dispatch({type: LOADING_USER});
            axios.get(ENVIRONMENT_VARIABLES.API_URL + "/dds/getStoreUsers/"+storeId, {headers: {'Authorization': token}}).then((response) => {
                dispatch({type: GET_ALL_USERS, data: {allUsers: response.data}});
            }).catch((error) => {
                if(error.response){
                    dispatch({type:ERROR_GET_ALL_USERS,data:error.response.data});
                }
            });
        }
    }catch(error){
        GyGLog('debug','DDS Log Store Configuration Action getAllStoreUser'+error);
    }
};

export const changeErrorValue = () => {
    try{
        return (dispatch) => {
            dispatch({type: CHANGE_VALUE_ERROR});
        }
    }catch(error){
        GyGLog('debug','DDS Log Store Configuration Action changeErrorValue'+error);
    }
};