export const auth = require('./authAction');
export const DDSStartup = require('./DDSStartupAction');
export const storeConfiguration = require('./storeConfigurationAction');
export const Analytics = require('./AnalyticsAction');

export default{
    auth,
    DDSStartup,
    storeConfiguration,
    Analytics
}