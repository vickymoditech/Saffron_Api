import axios from 'axios';
import $ from 'jquery';

import ENVIRONMENT_VARIABLES from '../environment.config';
import {
    LOAD_DDS_DATA,
    LOAD_DDS_DATA_SUCCESS,
    DDS_STARTUP_DATA,
    NETWORK_ERROR,
    UNAUTHORIZED_USER,
    ORDER_DETAIL,
    INITIAL_ORDER_DETAIL,
    ORDER_NOT_FOUND,
    NOT_FOUND,
    RECENT_ORDERS,
    LOAD_RECENT_ORDERS,
    DATA_RECEIVED,
    LOAD_CHAT_DATA,
    LOAD_CHAT_DATA_SUCCESS,
    CHAT_STARTUP_DATA,
    CHAT_DETAIL,
    INITIAL_CHAT_DETAIL,
    CHAT_NOT_FOUND
} from '../constants/actionTypes';
import {GyGLog} from '../Logging/GyGLog';

export const getDDSStartup = (storeName) => {
    try {
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            if (storeName) {
                dispatch({type: LOAD_DDS_DATA});
                axios.get(ENVIRONMENT_VARIABLES.API_URL + "/dds/startup/" + storeName, {headers: {'Authorization': token}}).then((response) => {
                    if (response.status === 200) {
                        dispatch({type: DDS_STARTUP_DATA, data: response.data});
                    }
                }).catch((error) => {
                    if (error.message === "Network Error") {
                        dispatch({type: NETWORK_ERROR});
                    }
                    else if ((error.response && error.response.status === 401) || (error.response && error.response.status === 403)) {
                        dispatch({type: UNAUTHORIZED_USER});
                    } else if (error.response && error.response.status === 404) {
                        dispatch({type: NOT_FOUND})
                    }
                });
            } else {
                dispatch({type: UNAUTHORIZED_USER});
            }
        };
    } catch (error) {
        GyGLog('debug', 'DDS Log DDS Startup Action getDDSStartup' + error);
    }

};

export const getChatStartup = (storeId,storeName) => {
    try {
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            if (storeId) {
                dispatch({type: LOAD_CHAT_DATA});
                axios.get(ENVIRONMENT_VARIABLES.API_URL + "/dds/chatMessage/"+storeName, {headers: {'Authorization': token}}).then((response) => {
                    if (response.status === 200) {
                        dispatch({type: CHAT_STARTUP_DATA, data: response.data});
                    }
                }).catch((error) => {
                    dispatch({type: LOAD_CHAT_DATA_SUCCESS});
                });
            } else {
                dispatch({type: UNAUTHORIZED_USER});
            }
        };
    } catch (error) {
        GyGLog('debug', 'DDS Log DDS Startup Action getChatStartup' + error);
    }
};

export const initialOrderDetail = () => {
    return (dispatch) => {
        dispatch({type: INITIAL_ORDER_DETAIL});
    };
};

export const getOrderDetails = (orderNumber) => {
    try {
        return (dispatch) => {
            const data = {
                "orderNumber": orderNumber
            };

            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/getOrderDetails",
                data: data,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: ORDER_DETAIL, data: response.data})
            }).catch((error) => {
                dispatch({type: ORDER_NOT_FOUND})
            });
        };
    } catch (error) {
        GyGLog('debug', 'DDS Log DDS Startup Action getOrderDetails' + error);
    }
};

export const allRecentOrders = (storeName) => {
    try {
        return (dispatch) => {
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            dispatch({type: LOAD_RECENT_ORDERS});
            axios.get(ENVIRONMENT_VARIABLES.API_URL + "/dds/recentOrders/" + storeName, {headers: {'Authorization': token}}).then((response) => {
                if (response.status === 200) {
                    dispatch({type: RECENT_ORDERS, data: response.data});
                }
            }).catch((error) => {
                dispatch({type: DATA_RECEIVED});
                if (error.message === "Network Error") {
                    // dispatch({type: NETWORK_ERROR});
                }
                else if ((error.response && error.response.status === 401) || (error.response && error.response.status === 403)) {
                    // dispatch({type: UNAUTHORIZED_USER});
                } else if (error.response && error.response.status === 404) {
                    // dispatch({type: NOT_FOUND})
                }
            });
        };
    } catch (error) {
        GyGLog('debug', 'DDS Log DDS Startup Action allRecentOrders' + error);
    }
};

export const getChatDetails = (orderNumber) => {
    try {
        return (dispatch) => {
            const data = {
                "orderNumber": orderNumber
            };
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/chat",
                data: data,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: CHAT_DETAIL, data: response.data})
            }).catch((error) => {
                dispatch({type: CHAT_NOT_FOUND})
            });
        };
    } catch (error) {
        GyGLog('debug', 'DDS Log DDS Startup Action getDDSStartup' + error);
    }

};

export const getInitialChatDetails = () => {
    return (dispatch) => {
        dispatch({type: INITIAL_CHAT_DETAIL});
    };
};