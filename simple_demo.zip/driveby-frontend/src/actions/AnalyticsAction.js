import axios from 'axios';

import {
    GET_ANALYTICS_DATA,
    GET_ANALYTICS_DATA_SUCCESS,
    GET_ANALYTICS_DATA_ERROR,
    GET_ANALYTICS_DATA_ALL_STORE,
    GET_ANALYTICS_DATA_SUCCESS_ALL_STORE,
    GET_ANALYTICS_DATA_ERROR_ALL_STORE,
    GET_ANALYTICS_DATA_AVG_WAIT_TIME,
    GET_ANALYTICS_DATA_SUCCESS_AVG_WAIT_TIME,
    GET_ANALYTICS_DATA_ERROR_AVG_WAIT_TIME,
    GET_ANALYTICS_DATA_RATING,
    GET_ANALYTICS_DATA_SUCCESS_RATING,
    GET_ANALYTICS_DATA_ERROR_RATING,
    GET_ANALYTICS_DATA_TRANSPORT,
    GET_ANALYTICS_DATA_SUCCESS_TRANSPORT,
    GET_ANALYTICS_DATA_ERROR_TRANSPORT,
    GET_ANALYTICS_DATA_TICKET_STATS,
    GET_ANALYTICS_DATA_SUCCESS_TICKET_STATS,
    GET_ANALYTICS_DATA_ERROR_TICKET_STATS,
    GET_ANALYTICS_DATA_REQUEST_BY_HOURS,
    GET_ANALYTICS_DATA_SUCCESS_REQUEST_BY_HOURS,
    GET_ANALYTICS_DATA_ERROR_REQUEST_BY_HOURS,
    GET_ANALYTICS_DATA_REQUEST_LOCATION_TRACKING,
    GET_ANALYTICS_DATA_SUCCESS_REQUEST_LOCATION_TRACKING,
    GET_ANALYTICS_DATA_ERROR_REQUEST_LOCATION_TRACKING,
    GET_ANALYTICS_DATA_REREQUEST_ORDER,
    GET_ANALYTICS_DATA_SUCCESS_REREQUEST_ORDER,
    GET_ANALYTICS_DATA_ERROR_REREQUEST_ORDER,
    GET_ANALYTICS_DATA_CANCELLED_REQUESTS,
    GET_ANALYTICS_DATA_SUCCESS_CANCELLED_REQUESTS,
    GET_ANALYTICS_DATA_ERROR_CANCELLED_REQUESTS,
    GET_ANALYTICS_DATA_TRANSPORT_TYPE_BY_DATE,
    GET_ANALYTICS_DATA_SUCCESS_TRANSPORT_TYPE_BY_DATE,
    GET_ANALYTICS_DATA_ERROR_TRANSPORT_TYPE_BY_DATE,
    GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS,
    GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS,
    GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS,
    GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS_ALL_STORES,
    GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS_ALL_STORES,
    GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS_ALL_STORES
} from '../constants/actionTypes';
import ENVIRONMENT_VARIABLES from '../environment.config';

export const getDriveByOrderReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/storeCompletedCancelledRequests",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR})
            });
        }
    } catch (error) {

    }
};

export const getAllStoreDriveByOrderReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_ALL_STORE});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/allStoreCompletedCancelledRequests",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_ALL_STORE, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_ALL_STORE})
            });
        }
    } catch (error) {

    }
};

export const getAvgWaitTimeReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_AVG_WAIT_TIME});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/storeAvgWaitTime",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_AVG_WAIT_TIME, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_AVG_WAIT_TIME})
            });
        }
    } catch (error) {

    }
};

export const getRatingReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_RATING});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/storeAvgRating",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_RATING, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_RATING})
            });
        }
    } catch (error) {

    }
};

export const getTransportReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_TRANSPORT});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/transportType",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_TRANSPORT, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_TRANSPORT})
            });
        }
    } catch (error) {

    }
};

export const getTicketStatistics = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_TICKET_STATS});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/ticketStatistics",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_TICKET_STATS, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_TICKET_STATS})
            });
        }
    } catch (error) {

    }
};

export const getReportByHours = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_REQUEST_BY_HOURS});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/totalRequestsByHour",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_REQUEST_BY_HOURS, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_REQUEST_BY_HOURS})
            });
        }
    } catch (error) {

    }
};

export const getLocationTrackingReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_REQUEST_LOCATION_TRACKING});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/locationTracking",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_REQUEST_LOCATION_TRACKING, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_REQUEST_LOCATION_TRACKING})
            });
        }
    } catch (error) {

    }
};

export const getReRequestedOrderReport = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_REREQUEST_ORDER});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/reRequestedOrders",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_REREQUEST_ORDER, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_REREQUEST_ORDER})
            });
        }
    } catch (error) {

    }
};

export const getCancelledRequests = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_CANCELLED_REQUESTS});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/cancelRequests",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_CANCELLED_REQUESTS, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_CANCELLED_REQUESTS})
            });
        }
    } catch (error) {

    }
};

export const getTransportTypeByDate = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_TRANSPORT_TYPE_BY_DATE});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/transportTypeByDate",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_TRANSPORT_TYPE_BY_DATE, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_TRANSPORT_TYPE_BY_DATE})
            });
        }
    } catch (error) {

    }
};

export const getMostActiveUsers = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/mostActiveCustomers",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS})
            });
        }
    } catch (error) {

    }
};

export const getMostActiveUsersAllStore = (reportDetails) => {
    try {
        return (dispatch) => {
            dispatch({type: GET_ANALYTICS_DATA_MOST_ACTIVE_CUSTOMERS_ALL_STORES});
            const token = 'Bearer ' + localStorage.getItem('accessToken');
            const api = {
                method: 'post',
                url: ENVIRONMENT_VARIABLES.API_URL + "/dds/analytics/mostActiveCustomersForAllStore",
                data: reportDetails,
                headers: {'Authorization': token}
            };
            axios(api).then((response) => {
                dispatch({type: GET_ANALYTICS_DATA_SUCCESS_MOST_ACTIVE_CUSTOMERS_ALL_STORES, data: response.data})
            }).catch((error) => {
                dispatch({type: GET_ANALYTICS_DATA_ERROR_MOST_ACTIVE_CUSTOMERS_ALL_STORES})
            });
        }
    } catch (error) {

    }
};